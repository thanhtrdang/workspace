package io.i101.spark

import org.apache.spark.sql.SparkSession
import scala.io.Source.fromFile

/**
  * @author ${user.name}
  */
object App {

  //  def foo(x : Array[String]) = x.foldLeft("")((a,b) => a + b)
  //
  //  def main(args : Array[String]) {
  //    println( "Hello World!" )
  //    println("concat arguments = " + foo(args))
  //  }

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("GitHub push counter")
      .master("local[*]")
      .getOrCreate()

    val sc = spark.sparkContext

    val inputPath = "/Volumes/WDBACKUP/Big.Data/workspace/github-archive/*.json"
    val ghLog = spark.read.json(inputPath)

    val pushes = ghLog.filter("type = 'PushEvent'")
    val grouped = pushes.groupBy("actor.login").count
    val ordered = grouped.orderBy(grouped("count").desc)

    val empPath = "./src/main/resources/ghEmployees.txt"

    val employees = Set() ++ (
      for {
        line <- fromFile(empPath).getLines
      } yield line.trim
    )
    val bcEmployees = sc.broadcast(employees)

    import spark.implicits._
    //        import sqlContextspark.implicits._
    val isEmp = (user: String) => bcEmployees.value.contains(user)
    val isEmployee = spark.udf.register("SetContainsUdf", isEmp)
    val filtered = ordered.filter(isEmployee($"login"))
    filtered.show()

    println("DONE")
  }

}
