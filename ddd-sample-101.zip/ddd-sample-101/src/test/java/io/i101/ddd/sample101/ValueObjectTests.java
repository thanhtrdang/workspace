package io.i101.ddd.sample101;

import io.i101.ddd.sample101.domain.shared.DomainEventSupport;
import io.i101.ddd.sample101.domain.shared.ValueObjectSupport;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.junit.Test;

import java.time.Instant;

public class ValueObjectTests {
  @Test
  public void testCopy() {
    final DummyValueObject valueObject1 = new DummyValueObject("thanhdang", "p@w");
    final DummyValueObject valueObject2 = valueObject1.deepCopy();

    final DummyDomainEvent domainEvent1 = new DummyDomainEvent(Instant.now());
    final DummyDomainEvent domainEvent2 = domainEvent1.deepCopy();

    assert valueObject1.sameValueAs(valueObject2);
    assert domainEvent1.sameEventAs(domainEvent2);
  }
}

@RequiredArgsConstructor
class DummyValueObject extends ValueObjectSupport<DummyValueObject> {
  private final String username;
  private final String password;

  @Setter
  private String xxx;
}

@RequiredArgsConstructor
class DummyDomainEvent extends DomainEventSupport<DummyDomainEvent> {
  private final Instant time;

  @Setter
  private String xxx;
}
