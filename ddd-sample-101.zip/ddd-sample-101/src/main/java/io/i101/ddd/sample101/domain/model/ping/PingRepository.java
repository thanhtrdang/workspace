package io.i101.ddd.sample101.domain.model.ping;

import io.i101.ddd.sample101.domain.shared.Repository;

public interface PingRepository extends Repository<PingEntity, String> {
//  Mono<PingEntity> findEntity();
//  Flux<PingEntity> findAllEntity();
}
