package io.i101.ddd.sample101.domain.shared;

/**
 * A value object, as explained in the DDD book.
 */
public interface ValueObject<T> {
  boolean sameValueAs(T other);
}
