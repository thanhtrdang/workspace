package io.i101.ddd.sample101.domain.shared;

/**
 * An entity, as explained in the DDD book.
 *
 */
public interface Entity<T, ID> {
  ID identity();

  boolean sameIdentityAs(T other);
}
