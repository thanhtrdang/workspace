package io.i101.ddd.sample101.domain.model.ping;

import io.i101.ddd.sample101.domain.shared.ValueObjectSupport;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
@RequiredArgsConstructor
@NoArgsConstructor(force = true)
public class PingValueObject extends ValueObjectSupport<PingValueObject> {
  @Column(name = "email")
  @Getter
  private final String value;

  public String localPart() {
    return part(0);
  }

  public String domain() {
    return part(1);
  }

  private String part(final int index) {
    return value.split("@")[index];
  }
}
