package io.i101.ddd.sample101.domain.shared;

/**
 * A specification, as explained in the DDD book.
 *
 * Override isSatisfiedBy only, never override AND, OR, NOT.
 */
@FunctionalInterface
public interface Specification<T> {
  boolean isSatisfiedBy(T obj);

  default Specification<T> and(Specification<T> other) {
    return obj -> isSatisfiedBy(obj) && other.isSatisfiedBy(obj);
  }

  default Specification<T> or(Specification<T> other) {
    return obj -> isSatisfiedBy(obj) || other.isSatisfiedBy(obj);
  }

  default Specification<T> not() {
    return obj -> !isSatisfiedBy(obj);
  }
}
