package io.i101.ddd.sample101.domain.shared;

import java.io.Serializable;

import static org.apache.commons.lang3.builder.EqualsBuilder.reflectionEquals;
import static org.apache.commons.lang3.builder.HashCodeBuilder.reflectionHashCode;

public abstract class DomainEventSupport<T extends DomainEvent> implements DomainEvent<T>, Copyable, Serializable {
  @Override
  public boolean sameEventAs(T other) {
    return null != other && reflectionEquals(this, other, false);
  }

  @Override
  public final boolean equals(final Object other) {
    if (this == other) return true;
    if (other == null || getClass() != other.getClass()) return false;

    return sameEventAs((T) other);
  }

  @Override
  public final int hashCode() {
    return reflectionHashCode(this, false);
  }
}
