package io.i101.ddd.sample101.domain.model.ping;

import io.i101.ddd.sample101.domain.shared.EntitySupport;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "PING_TBL")
@RequiredArgsConstructor
@NoArgsConstructor(force = true)
public class PingEntity extends EntitySupport<PingEntity, String> {
  @Id
  private final String id;

  @Column
  private final String name;

  @Column
  private final Integer age;

  @Embedded
  @Getter
  private final PingValueObject email;

  @Override
  public String identity() {
    return id;
  }

}
