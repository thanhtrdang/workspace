package io.i101.ddd.sample101.interfaces;

import io.i101.ddd.sample101.domain.model.ping.PingEntity;
import io.i101.ddd.sample101.domain.model.ping.PingRepository;
import io.i101.ddd.sample101.domain.model.ping.PingValueObject;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
@RequiredArgsConstructor
public class PingController {
  private final PingRepository pingRepository;

  @GetMapping("/ping/find")
  public Mono<PingEntity> find() {
    return Mono.justOrEmpty(pingRepository.findById("8888-0000").getOrNull());
  }

  @GetMapping("/ping/store")
  public Mono<PingValueObject> store() {
    final PingValueObject pingValueObject = new PingValueObject("thanh@gmail.com");
    final PingEntity pingEntity = new PingEntity("8888-0000", "Thanh", 30, pingValueObject);

    final PingValueObject xxx = pingRepository.save(pingEntity).getEmail().deepCopy();

    return Mono.justOrEmpty(xxx);
  }
}
