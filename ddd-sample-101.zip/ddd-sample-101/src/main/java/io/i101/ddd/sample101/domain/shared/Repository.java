package io.i101.ddd.sample101.domain.shared;

import io.vavr.control.Option;
import org.springframework.data.repository.NoRepositoryBean;

import java.io.Serializable;

//TODO
// Integrate to Spring JPA tightly.
// May refactor to POJO later.
//public interface Repository<T extends Entity, ID> {
//  Option<T> find(ID id);
//  T store(T entity);
//}

@NoRepositoryBean
public interface Repository<T extends Entity, ID extends Serializable>
  extends org.springframework.data.repository.Repository<T, ID> {
  Option<T> findById(ID id);
  <S extends T> S save(S entity);
}
