package io.i101.ddd.sample101.domain.shared;

import java.io.Serializable;

import static org.apache.commons.lang3.builder.EqualsBuilder.reflectionEquals;
import static org.apache.commons.lang3.builder.HashCodeBuilder.reflectionHashCode;

public abstract class ValueObjectSupport<T extends ValueObject> implements ValueObject<T>, Copyable, Serializable {
  @Override
  public final boolean sameValueAs(T other) {
    return null != other && reflectionEquals(this, other, false);
  }

  @Override
  public final boolean equals(final Object other) {
    if (this == other) return true;
    if (other == null || getClass() != other.getClass()) return false;

    return sameValueAs((T) other);
  }

  @Override
  public final int hashCode() {
    return reflectionHashCode(this, false);
  }
}
