package io.i101.ddd.sample101.domain.shared;

import com.rits.cloning.Cloner;

interface Copyable {
  Cloner _cloner = Cloner.standard();
  default <T extends Copyable> T deepCopy() {
    return (T) _cloner.deepClone(this);
  }
}
