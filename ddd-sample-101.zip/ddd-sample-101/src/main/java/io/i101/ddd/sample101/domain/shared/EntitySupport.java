package io.i101.ddd.sample101.domain.shared;

import java.io.Serializable;

public abstract class EntitySupport<T extends Entity<T, ID>, ID extends Serializable> implements Entity<T, ID>, Serializable {
  @Override
  public final boolean sameIdentityAs(T other) {
    return null != other && identity().equals(other.identity());
  }

  @Override
  public final boolean equals(final Object other) {
    if (this == other) return true;
    if (other == null || getClass() != other.getClass()) return false;

    return sameIdentityAs((T) other);
  }

  @Override
  public final int hashCode() {
    return identity().hashCode();
  }
}
