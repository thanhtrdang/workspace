> https://spring.io/guides/gs/testing-web/
>
> @DirtiesContext: application context is cached between tests
>
> mvn test -Dtest="CamelKafkaEndpointTests#testKafka"
>
> https://start.camunda.com/
>
> https://www.baeldung.com/spring-boot-h2-database (h2 access)
>
> Camunda weather https://www.youtube.com/watch?v=gFY1UuiCVl4&list=PLJG25HlmvsOUnCziyJBWzcNh7RM5quTmv&index=6
>
> jar tvf target/workflow-101.jar | rg -i scala