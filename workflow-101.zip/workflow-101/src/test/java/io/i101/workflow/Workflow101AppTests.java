package io.i101.workflow;

import io.restassured.RestAssured;
import io.restassured.module.mockmvc.RestAssuredMockMvc;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.test.spring.junit5.CamelSpringBootTest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.web.context.WebApplicationContext;

import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

@Slf4j
@ActiveProfiles("test")
@Sql("/test_data.sql")
@CamelSpringBootTest
@SpringBootTest(webEnvironment = RANDOM_PORT,
    properties = {
        "camunda.bpm.generate-unique-process-engine-name=true",
        // this is only needed if a SpringBootProcessApplication is used for the test
        "camunda.bpm.generate-unique-process-application-name=true",
        "spring.datasource.generate-unique-name=true",
        // additional properties...
    }
)
public abstract class Workflow101AppTests {
    @LocalServerPort
    private int testPort;
    @Autowired
    private WebApplicationContext testContext;

    @BeforeEach
    private void setup() {
        // in rest-assured's log: port is always hard-coded 8080
        RestAssured.port = testPort;
        RestAssuredMockMvc.webAppContextSetup(testContext);

        LOG.info("Test port: {}", testPort);

        customSetup(testContext);
    }

    @AfterEach
    private void teardown() {
        RestAssured.reset();

        customTeardown(testContext);
    }

    protected void customSetup(final WebApplicationContext testContext) {
    }

    protected void customTeardown(final WebApplicationContext testContext) {
    }
}
