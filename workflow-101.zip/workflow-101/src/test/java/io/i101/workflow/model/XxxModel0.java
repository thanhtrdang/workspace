package io.i101.workflow.model;

import lombok.Value;
import lombok.experimental.FieldNameConstants;

@Value
@FieldNameConstants
public class XxxModel0 {
    String firstName;
    int age;
}
