package io.i101.workflow.endpoint;

import io.i101.workflow.Workflow101AppTests;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.FluentProducerTemplate;
import org.apache.camel.builder.NotifyBuilder;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import static java.util.concurrent.TimeUnit.SECONDS;
import static org.junit.jupiter.api.Assertions.assertTrue;

@Slf4j
public class CamelKafkaEndpointTests extends Workflow101AppTests {
    @Value("${camel.kafka.from}")
    private String kafkaFrom;

    @Value("${camel.kafka.to}")
    private String kafkaTo;

    @Autowired
    private FluentProducerTemplate camelTemplate;

    @Test
    public void testKafka() {
        camelTemplate
                .withBody("Something in the way...")
                .to(kafkaFrom)
                .send();

        final boolean wasDone = new NotifyBuilder(camelTemplate.getCamelContext())
                .from(kafkaFrom)
                .whenDone(1)
                .create()
                .matches(2, SECONDS);

        assertTrue(wasDone);
    }
}
