package io.i101.workflow.endpoint;

import io.i101.workflow.Workflow101AppTests;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.FluentProducerTemplate;
import org.apache.camel.builder.NotifyBuilder;
import org.assertj.core.util.Files;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.WebApplicationContext;

import java.io.File;

import static java.nio.charset.StandardCharsets.UTF_8;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.apache.camel.Exchange.FILE_NAME;
import static org.apache.camel.util.FileUtil.removeDir;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@Slf4j
public class Camel101EndpointTests extends Workflow101AppTests {
    @Autowired
    private FluentProducerTemplate camelTemplate;

    @Test
    public void testFileTransfer_outbox() throws Exception {
        camelTemplate
                .withHeader(FILE_NAME, "hi_there.json")
                .withBody("{\"xxx\":\"one more time\"}")
                .to("file://target/inbox")
                .send();

        final boolean wasDone = new NotifyBuilder(camelTemplate.getCamelContext())
                .from("file://target/inbox")
                .whenDone(1)
                .create()
                .matches(2, SECONDS);
        assertTrue(wasDone);

        final File outboxFile = new File("target/outbox/hi_there.json");
        assertTrue(outboxFile.exists());

        final String outboxContent = Files.contentOf(outboxFile, UTF_8);
        assertEquals("{\"xxx\":\"one more time\"}", outboxContent);
    }

    @Test
    public void testFileTransfer_junkbox() throws Exception {
        camelTemplate
                .withHeader(FILE_NAME, "hi_there.txt")
                .withBody("Hi, there.. I'm XXX.")
                .to("file://target/inbox")
                .send();

        SECONDS.sleep(2);

        final File junkboxFile = new File("target/junkbox/hi_there.txt");
        final String junkboxContent = Files.contentOf(junkboxFile, UTF_8);

        assertTrue(junkboxFile.exists());
        assertEquals("Hi, there.. I'm XXX.", junkboxContent);
    }

    @Override
    protected void customTeardown(final WebApplicationContext testContext) {
        removeDir(new File("target/inbox"));
        removeDir(new File("target/outbox"));
        removeDir(new File("target/junkbox"));
    }
}
