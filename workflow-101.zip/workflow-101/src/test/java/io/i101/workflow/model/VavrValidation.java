package io.i101.workflow.model;

import io.vavr.collection.Map;
import io.vavr.collection.Set;
import io.vavr.control.Validation;

@FunctionalInterface
public interface VavrValidation<V> {
    Validation<Map<String, Set<String>>, V> validate(V value);
}
