package io.i101.workflow.service;

import io.i101.workflow.Workflow101AppTests;
import io.vavr.collection.List;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.camunda.bpm.engine.variable.Variables;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@Slf4j
public class CamundaServiceTests extends Workflow101AppTests {
    @Autowired
    private CamundaService camundaService;

    @Test
    public void testStartPaymentProcess() {
        val rejected = Map.<String, Object>of(
            "amount", 1001,
            "item", "item-x"
        );

        val approved1 = Map.<String, Object>of(
            "amount", 1001,
            "item", "item-xyz"
        );
        val approved2 = Map.<String, Object>of(
            "amount", 1002,
            "item", "item-xyz"
        );

//        List.of(rejected, approved1, approved2)
        List.of(rejected)
            .forEach(vars -> camundaService.startPaymentProcess(vars));

        assertTrue(true);
    }

    @Test
    public void testEvaluateDesiredDish() {
        val vars = Variables.createVariables()
            .putValue("season", "Spring")
            .putValue("guestCount", 10);

        val desiredDish = camundaService.evaluateDesiredDish(vars);

        assertEquals("Stew", desiredDish);
    }

    @Test
    public void testEvaluatePaymentApproval() {
        val xyzVars = Variables.createVariables()
            .putValue("item", "item-xyz");
        val abcVars = Variables.createVariables()
            .putValue("item", "item-abc");

        val xyzT = camundaService.evaluatePaymentApproval(xyzVars);
        val xyzF = camundaService.evaluatePaymentApproval(abcVars);

        assertTrue(xyzT);
        assertFalse(xyzF);
    }

    @Test
    public void testStartWeatherProcess() {
        camundaService.startWeatherProcess(Map.of());

        assertTrue(true);
    }
}
