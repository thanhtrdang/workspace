package io.i101.workflow.model;

import io.vavr.Tuple;
import io.vavr.Tuple2;
import io.vavr.collection.HashSet;
import io.vavr.collection.Map;
import io.vavr.collection.Set;
import io.vavr.control.Option;
import io.vavr.control.Validation;
import lombok.NoArgsConstructor;

import java.util.function.Function;

import static io.i101.workflow.model.XxxModel0.Fields.AGE;
import static io.i101.workflow.model.XxxModel0.Fields.FIRST_NAME;
import static lombok.AccessLevel.PRIVATE;
import static org.apache.commons.lang3.StringUtils.isAlphanumeric;

@NoArgsConstructor(access = PRIVATE)
public final class VavrValidation0 implements VavrValidation<XxxModel0> {
    public static final VavrValidation0 VAVR_MODEL0_VALIDATION = new VavrValidation0();

    @Override
    public Validation<Map<String, Set<String>>, XxxModel0> validate(XxxModel0 value) {
        return Validation
            .combine(validateName(value.getFirstName()), validateAge(value.getAge()))
            .ap(XxxModel0::new)
            .mapError(errors -> errors.toMap(Function.identity()));
    }

    private Validation<Tuple2<String, Set<String>>, String> validateName(String name) {
        return Option
            .when(isAlphanumeric(name), () -> name.trim())
            .toValidation(() -> Tuple.of(FIRST_NAME, HashSet.of("Name should be Alphanumeric.")));
    }

    private Validation<Tuple2<String, Set<String>>, Integer> validateAge(int age) {
        return Option
            .when(18 <= age && age < 100, () -> age)
            .toValidation(() -> Tuple.of(AGE, HashSet.of("18 <= age < 100.")));
    }
}
