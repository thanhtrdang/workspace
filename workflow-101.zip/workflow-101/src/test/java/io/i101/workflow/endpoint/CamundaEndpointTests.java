package io.i101.workflow.endpoint;

import io.i101.workflow.Workflow101AppTests;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

@Slf4j
public class CamundaEndpointTests extends Workflow101AppTests {
    @Autowired
    private CamundaEndpoint camundaEndpoint;

    @Test
    public void testCamunda() {
        LOG.info("DONE.");
    }
}
