package io.i101.workflow.model;

import io.vavr.collection.Map;
import io.vavr.collection.Set;
import io.vavr.control.Validation;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;

import static io.i101.workflow.model.VavrValidation0.VAVR_MODEL0_VALIDATION;

@Slf4j
public class VavrTests {
    @Test
    public void testVarv() {
        final XxxModel0 john13 = new XxxModel0("John", 13);
        final XxxModel0 john23 = new XxxModel0("John", 23);

        final Validation<Map<String, Set<String>>, XxxModel0> result13 = VAVR_MODEL0_VALIDATION.validate(john13);
        final Validation<Map<String, Set<String>>, XxxModel0> result23 = VAVR_MODEL0_VALIDATION.validate(john23);

        LOG.info("DONE");
    }
}
