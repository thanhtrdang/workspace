package io.i101.workflow;

import lombok.val;
import org.junit.jupiter.api.Test;
import scala.Option;
import scala.util.Either;
import scala.util.Try;

public class ScalaTests {
    @Test
    public void testOption() {
        val none = Option.empty();
        val some = Option.apply("xxx");
        val none0 = Option.apply(null);

        System.out.println(none);
        System.out.println(some);
        System.out.println(none0);
    }

    @Test
    public void testEither() {
        val left = Either.cond(false, () -> "", () -> 1);
        val right = Either.cond(true, () -> "xxx", () -> 0);

        System.out.println(left);
        System.out.println(right);
    }

    @Test
    public void testTry() {
        val nok = Try.apply(() -> 2 / 0);
        val ok = Try.apply(() -> 13);

        System.out.println(nok);
        System.out.println(ok);
    }
}
