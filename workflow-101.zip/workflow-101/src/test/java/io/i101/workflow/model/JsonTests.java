package io.i101.workflow.model;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;

import java.io.File;

@Slf4j
public class JsonTests {
    @Test
    public void testJson0() throws Exception {
        final File jsonFile = new File("target/test-classes/test_data-0.json");

//        final JsonMapper jsonMapper = new JsonMapper();
//        final JsonNode jsonNode = jsonMapper.readTree(jsonFile);

        final DocumentContext jsonObject = JsonPath.parse(jsonFile);


        LOG.info("DONE.");
    }
}
