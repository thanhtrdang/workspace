package io.i101.workflow.endpoint;

import io.i101.workflow.Workflow101AppTests;
import io.i101.workflow.repository.IndexRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.context.WebApplicationContext;

import static io.i101.workflow.model.IndexModel.Fields.*;
import static io.restassured.module.mockmvc.RestAssuredMockMvc.get;
import static io.restassured.module.mockmvc.RestAssuredMockMvc.given;
import static org.hamcrest.Matchers.emptyOrNullString;
import static org.hamcrest.Matchers.is;

public class IndexEndpointTests extends Workflow101AppTests {
    // @MockBean
    // private IndexService indexService;

    @Autowired
    private IndexRepository indexRepository;

    @Test
    public void test_idx() {
        // @formatter:off
        get("/").
        then()
            .status(HttpStatus.OK)
            .body(is("It works."))
        ;
        // @formatter:on
    }

    @Test
    public void test_index() {
        // @formatter:off
        given()
            .log().all().
        when()
            .get("/index").
        then()
            .log().body()
            .status(HttpStatus.OK)
            .body(NAME, is("WF"))
            .body(VERSION, is(2))
            .body(XXX_NAME, emptyOrNullString())
        ;
        // @formatter:on
    }

    @Override
    protected void customSetup(WebApplicationContext testContext) {
        // indexRepository.saveAll(List.of(
        // builder().name("WF").version(11).build(),
        // builder().name("WF").version(12).build(),
        // builder().name("WF").version(13).build()
        // ));

        // Mockito
        // .when(indexService.idx())
        // .thenReturn("It works.")
        // ;
        //
        // Mockito
        // .when(indexService.index())
        // .thenReturn(new IndexModel("xxx", "WF", 1))
        // ;
    }
}
