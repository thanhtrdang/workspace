TRUNCATE TABLE index_tbl;

INSERT INTO index_tbl (id, name, version)
VALUES (1, 'WF', 1);
INSERT INTO index_tbl (id, name, version)
VALUES (2, 'WF', 2);
INSERT INTO index_tbl (id, name, version)
VALUES (3, 'WF', 3);
