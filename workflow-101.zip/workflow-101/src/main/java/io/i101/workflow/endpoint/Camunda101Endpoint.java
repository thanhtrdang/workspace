package io.i101.workflow.endpoint;

import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.Map;

import static org.apache.commons.lang3.RandomUtils.nextBoolean;

@Slf4j
@RestController
@RequestMapping("/camunda-101")
public class Camunda101Endpoint {
    @Autowired
    private RuntimeService runtimeService;

    @Autowired
    private TaskService taskService;

    @PostMapping("/user-task/{processId}")
    public String triggerDummyUserTask(@PathVariable final String processId) {
        LOG.info("START complete task for processId: {}", processId);

        val taskList = taskService
            .createTaskQuery()
            .processInstanceId(processId)
            .taskAssignee("xxx_user")
            .active()
            .list();

        taskList
            .forEach(task -> {
                taskService.complete(task.getId(), Map.of("payment_rejected_nok", "rejected"));
                LOG.info(
                    "END taskName: {}, taskId: {}",
                    task.getName(), task.getId()
                );
            });

        return taskList
            .stream()
            .findFirst()
            .map(task -> "Complete task at " + Instant.now())
            .orElse("No task for processId: " + processId);
    }

    @PostMapping("/receive-task/{processId}")
    public String triggerReceiveTask(@PathVariable final String processId) {
        LOG.info("START receive message for processId: {}", processId);

        runtimeService
            .createMessageCorrelation("dummy_receive_task_message")
            .processInstanceId(processId)
            .setVariable("payment_received_ok", "received")
            .correlate();

        LOG.info("END receive message for processId: {}", processId);

        return "";
    }

    @PostMapping("/message_event/{processId}")
    public String triggerMessage(@PathVariable final String processId) {
        LOG.info("START receive message for processId: {}", processId);

        runtimeService
            .createMessageCorrelation("UsidorAndChuntArriveMessage")
            .processInstanceId(processId)
//            .setVariable("payment_received_ok", "received")
            .correlate();

        LOG.info("END receive message for processId: {}", processId);

        return "";
    }

    @PostMapping("/conditional_event/{processId}")
    public String triggerConditionalEvent(@PathVariable final String processId) {
        val darkLordAttacks = nextBoolean();

        LOG.info("START conditional event for processId: {}, darkLordAttacks: {}", processId, darkLordAttacks);

//        runtimeService
//            .createConditionEvaluation()
//            .processDefinitionId(processId)
//            .setVariable("payment_received_ok", "received")
//            .evaluateStartConditions();
        runtimeService.setVariable(processId, "darkLordAttacks", darkLordAttacks);

        LOG.info("END conditional event for processId: {}", processId);

        return Instant.now().toString();
    }

}

// http POST http://localhost:9090/camunda-101/user-task/{processId}
