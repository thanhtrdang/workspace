package io.i101.workflow.repository;

import io.i101.workflow.model.IndexModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IndexRepository extends JpaRepository<IndexModel, Integer> {
}
