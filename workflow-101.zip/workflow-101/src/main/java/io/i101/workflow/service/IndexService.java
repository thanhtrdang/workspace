package io.i101.workflow.service;

import io.i101.workflow.model.IndexModel;
import io.i101.workflow.repository.IndexRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class IndexService {
    @Autowired
    private IndexRepository indexRepository;

    public String idx() {
        return "It works.";
    }

    public IndexModel index() {
        return indexRepository.findById(2).orElse(null);
    }
}
