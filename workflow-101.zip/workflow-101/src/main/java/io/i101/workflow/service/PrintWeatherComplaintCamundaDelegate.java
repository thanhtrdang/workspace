package io.i101.workflow.service;

import io.vavr.collection.List;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

import static org.apache.commons.lang3.RandomStringUtils.randomPrint;
import static org.apache.commons.lang3.StringUtils.SPACE;


@Slf4j
@Component
public class PrintWeatherComplaintCamundaDelegate implements JavaDelegate {
    @Override
    public void execute(DelegateExecution execution) throws Exception {
        val weatherComplaint = List
            .of("f**k", randomPrint(13))
            .mkString(SPACE);

        LOG.info("Weather complaint: {}", weatherComplaint);

        execution.setVariable("weatherComplaint", weatherComplaint);
    }
}
