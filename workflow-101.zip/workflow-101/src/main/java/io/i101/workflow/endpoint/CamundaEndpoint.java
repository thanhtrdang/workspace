package io.i101.workflow.endpoint;

import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.spring.boot.starter.event.PostDeployEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class CamundaEndpoint {
    @Autowired
    private RuntimeService runtimeService;

    @EventListener
    private void processPostDeploy(final PostDeployEvent event) {
//        final Map<String, Object> vars = Map.of(
//            "amount", 1001,
//            "item", "item-x",
//            "approved", false
//        );
//        final ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("payment-retrieval", vars);

        LOG.info("Post Deploy {}", event);
    }
}
