package io.i101.workflow.service;

import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

import static org.apache.commons.lang3.RandomUtils.nextBoolean;

@Slf4j
@Component
public class CheckWeatherCamundaDelegate implements JavaDelegate {
    @Override
    public void execute(DelegateExecution execution) throws Exception {
        val isWeatherOk = nextBoolean();

        LOG.info("Weather is ok? {}", isWeatherOk);

        execution.setVariable("isWeatherOk", isWeatherOk);
    }
}
