package io.i101.workflow.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.i101.workflow.service.CamundaSubVar;
import io.i101.workflow.service.CamundaVar;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

import static org.apache.commons.lang3.RandomStringUtils.randomAlphanumeric;
import static org.apache.commons.lang3.RandomUtils.nextInt;

@Slf4j
@Component
public class ChargeCreditCardCamundaDelegate implements JavaDelegate {
    private static final TypeReference<Map<String, Object>> XXX_VAR_TYPE = new TypeReference<>() {
    };

    @Autowired
    private ObjectMapper jsonMapper;

    @Override
    public void execute(DelegateExecution execution) throws Exception {
        val xxxVar = CamundaVar
            .builder()
            .varName("xxxVar")
            .varAge(nextInt())
            .map(Map.of("k1", "v1", "k2", nextInt()))
            .subVar(CamundaSubVar
                .builder()
                .subMap(Map.of("subkey1", "subval1", "subkey2", randomAlphanumeric(13)))
                .subVarName("xxxSubVar")
                .build()
            )
            .build();

        LOG.info("SET XXX_VAR => {}", xxxVar);
        execution.setVariable("XXX_VAR", xxxVar, execution.getCurrentActivityId());
//        execution.setVariables(Map.of("XXX_VAR", xxxVar));
//        execution.setVariable("XXX_VAR", xxxVar);
    }
}
