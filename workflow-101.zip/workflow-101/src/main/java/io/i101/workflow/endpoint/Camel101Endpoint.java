package io.i101.workflow.endpoint;

import org.apache.camel.builder.RouteBuilder;
import org.apache.commons.text.StringSubstitutor;
import org.springframework.stereotype.Component;

import java.util.Map;

import static org.apache.camel.component.file.FileConstants.FILE_NAME;

@Component
public class Camel101Endpoint extends RouteBuilder {
    @Override
    public void configure() throws Exception {
        fileTransfer();
    }

    // @formatter:off
    private void fileTransfer() {
        from("file://target/inbox")
            .log("==> File received: ${header." + FILE_NAME + "}")
            .filter(exchange -> true)
            .choice()
                .when(header(FILE_NAME).endsWith(".json"))
                    .to("file://target/outbox")
                .otherwise()
                    .to("file://target/junkbox")
            .end()
        ;
    }
    // @formatter:on

    private String interpolate(final String message, final Map<String, String> params) {
        return new StringSubstitutor(params).replace(message);
    }

}
