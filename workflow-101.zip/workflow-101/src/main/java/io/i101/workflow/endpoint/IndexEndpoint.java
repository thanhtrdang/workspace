package io.i101.workflow.endpoint;

import io.i101.workflow.model.IndexModel;
import io.i101.workflow.service.IndexService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class IndexEndpoint {
    @Autowired
    private IndexService indexService;

    @GetMapping("/")
    public String idx() {
        return indexService.idx();
    }

    @GetMapping("/index")
    public IndexModel index() {
        return indexService.index();
    }
}
