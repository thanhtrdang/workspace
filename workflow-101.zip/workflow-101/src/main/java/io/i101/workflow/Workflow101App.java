package io.i101.workflow;

import lombok.extern.slf4j.Slf4j;
import org.camunda.bpm.spring.boot.starter.annotation.EnableProcessApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@Slf4j
@SpringBootApplication
@EnableProcessApplication
public class Workflow101App implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(Workflow101App.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        // final ExternalTaskClient camundaTaskClient = ExternalTaskClient
        // .create()
        // .baseUrl("http://localhost:9090/engine-rest")
        // .asyncResponseTimeout(10000) // long polling timeout
        // .build();
        //
        //
        // camundaTaskClient.subscribe("charge-card")
        // .lockDuration(1000) // the default lock duration is 20 seconds, but you can
        // override this
        // .handler((externalTask, externalTaskService) -> {
        // // Put your business logic here
        //
        // // Get a process variable
        // String item = externalTask.getVariable("item");
        // Integer amount = externalTask.getVariable("amount");
        //
        // LOG.info("Charging credit card with an amount of '" + amount + "'€ for the
        // item '" + item + "'...");
        //
        // try {
        // TimeUnit.SECONDS.sleep(2);
        //
        // LOG.info("DONE - Finish payment. Thank you!");
        // } catch (Exception e) {
        // LOG.warn("Failed !!!", e);
        // }
        //
        // // Complete the task
        // externalTaskService.complete(externalTask);
        // })
        // .open();
    }
}
