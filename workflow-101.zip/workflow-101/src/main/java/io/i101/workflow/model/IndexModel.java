package io.i101.workflow.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.FieldNameConstants;

import static jakarta.persistence.GenerationType.AUTO;

@Data
@Builder
@FieldNameConstants
@Entity
@Table(name = "index_tbl")
public class IndexModel {
    @Id
    @GeneratedValue(strategy = AUTO)
    private Integer id;
    private String name;
    private int version;
    private String xxxName;
}
