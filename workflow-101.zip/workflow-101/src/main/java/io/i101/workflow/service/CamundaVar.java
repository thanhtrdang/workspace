package io.i101.workflow.service;

import lombok.Builder;
import lombok.Value;
import lombok.experimental.FieldNameConstants;

import java.io.Serial;
import java.io.Serializable;
import java.util.Map;

@Value
@Builder(toBuilder = true)
@FieldNameConstants
public class CamundaVar implements Serializable {
    @Serial
    private static final long serialVersionUID = 76809298252246072L;

    String varName;
    int varAge;
    Map<String, Object> map;
    CamundaSubVar subVar;
}

@Value
@Builder(toBuilder = true)
@FieldNameConstants
class CamundaSubVar implements Serializable {
    @Serial
    private static final long serialVersionUID = -3066470579237331447L;

    String subVarName;
    Map<String, String> subMap;
}
