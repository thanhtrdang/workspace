package io.i101.workflow.endpoint;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CamelKafkaEndpoint extends RouteBuilder {
    @Value("${camel.kafka.from}")
    private String kafkaFrom;

    @Value("${camel.kafka.to}")
    private String kafkaTo;

    @Override
    public void configure() throws Exception {
        kafkaXXX();
    }

    private void kafkaXXX() {
        from(kafkaFrom)
            .log("==> Kafka: ${body}")
            .to(kafkaTo);
    }
}
