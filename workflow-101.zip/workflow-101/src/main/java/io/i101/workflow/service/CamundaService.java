package io.i101.workflow.service;

import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.camunda.bpm.engine.DecisionService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.spring.boot.starter.event.PostDeployEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.util.Map;

@Slf4j
@Component
public class CamundaService {
    @Autowired
    private RuntimeService runtimeService;

    @Autowired
    private DecisionService decisionService;

    @Autowired
    private ProcessEngine processEngine;

    @EventListener
    private void processPostDeploy(final PostDeployEvent event) {
        LOG.info("Post Deploy {}", event);
    }

    public void startPaymentProcess(final Map<String, Object> vars) {
        val processInstance = runtimeService.startProcessInstanceByKey("payment_retrieval_process", vars);

        LOG.info("Started payment: {}", processInstance.getProcessInstanceId());
    }

    public String evaluateDesiredDish(final Map<String, Object> vars) {
        return decisionService
            .evaluateDecisionTableByKey("dish_decision", vars)
            .getSingleEntry();
    }

    public boolean evaluatePaymentApproval(final Map<String, Object> vars) {
        return decisionService
            .evaluateDecisionTableByKey("approve_payment_0", vars)
            .getSingleEntry();
    }

    public void startWeatherProcess(final Map<String, Object> vars) {
        val processInstance = runtimeService.startProcessInstanceByKey("weather_process", vars);

        LOG.info("Started weather: {}", processInstance.getProcessInstanceId());
    }
}
