package io.i101.rx.file;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.concurrent.CountDownLatch;

@SpringBootApplication
public class RxFileApplication {
	public static void main(String[] args) {
		SpringApplication.run(RxFileApplication.class, args);

		boolean x = (String a, String b) -> a.equalsIgnoreCase(b);

		try {
			new CountDownLatch(1).await();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
