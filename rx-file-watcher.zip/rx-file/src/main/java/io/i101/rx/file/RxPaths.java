package io.i101.rx.file;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.HashMap;
import java.util.Map;

import static java.nio.file.LinkOption.NOFOLLOW_LINKS;
import static java.nio.file.StandardWatchEventKinds.*;

@Slf4j
public class RxPaths {
  private RxPaths() {
    throw new UnsupportedOperationException("Please use factory methods instead of.");
  }

  /**
   * Creates an observable that watches the given directory and all its subdirectories. Directories
   * that are created after subscription are watched, too.
   *
   * @param path Root directory to be watched
   * @return Observable that emits an event for each filesystem event.
   * @throws IOException
   */
  public static Observable<WatchEvent<Path>> watchRecursive(final Path path) throws IOException {
    final boolean recursive = true;
    return new RxPaths.ObservableFactory(path, recursive).create();
  }

  /**
   * Creates an observable that watches the given path but not its subdirectories.
   *
   * @param path Path to be watched
   * @return Observable that emits an event for each filesystem event.
   * @throws IOException
   */
  public static Observable<WatchEvent<Path>> watchNonRecursive(final Path path) throws IOException {
    final boolean recursive = false;
    return new RxPaths.ObservableFactory(path, recursive).create();
  }

  private static class ObservableFactory {
    private static final Long FILE_WAIT = 10000L; // milliseconds

    private final WatchService watcher;
    private final Map<WatchKey, Path> directoriesByKey = new HashMap<>();
    private final Path directory;
    private final boolean recursive;

    private final Map<Path, Long> expirationTimes = new HashMap<>();


    private ObservableFactory(final Path path, final boolean recursive) throws IOException {
      final FileSystem fileSystem = path.getFileSystem();
      watcher = fileSystem.newWatchService();
      directory = path;
      this.recursive = recursive;
    }

    private Observable<WatchEvent<Path>> create() {
      return Observable.create(subscriber -> {
        boolean errorFree = true;
        try {
          if (recursive) {
            registerAll(directory);
          } else {
            register(directory);
          }
        } catch (IOException exception) {
          subscriber.onError(exception);
          errorFree = false;
        }
        while (errorFree && !subscriber.isDisposed()) {
          final WatchKey key;
          try {
            key = watcher.take();
          } catch (InterruptedException exception) {
            if (!subscriber.isDisposed()) {
              subscriber.onError(exception);
            }
            errorFree = false;
            break;
          }
          final Path dir = directoriesByKey.get(key);
          for (final WatchEvent<?> event : key.pollEvents()) {
            final WatchEvent<Path> pathEvent = cast(event);

            // TBD - provide example of how OVERFLOW event is handled
            if (event.kind() == OVERFLOW) {
              log.warn("Ignore event OVERFLOW {}", event.context());
              continue;
            }

            subscribeOnNext(subscriber, pathEvent);
            registerNewDirectory(subscriber, dir, pathEvent);
          }
          // reset key and remove from set if directory is no longer accessible
          boolean valid = key.reset();
          if (!valid) {
            directoriesByKey.remove(key);
            // nothing to be watched
            if (directoriesByKey.isEmpty()) {
              break;
            }
          }
        }
        if (errorFree) {
          subscriber.onComplete();
        }
      });
    }

    private void handleExpiredWaitTimes(Long currentTime) {
      // Start import for files for which the expiration time has passed
      for (Map.Entry<Path, Long> entry : expirationTimes.entrySet()) {
        if (entry.getValue() <= currentTime) {
          log.debug("expired " + entry);
          // do something with the file
          expirationTimes.remove(entry.getKey());
        }
      }
    }

    @SuppressWarnings("unchecked")
    private <T> WatchEvent<T> cast(WatchEvent<?> event) {
      return (WatchEvent<T>) event;
    }

    private void subscribeOnNext(final ObservableEmitter<WatchEvent<Path>> subscriber, final WatchEvent<Path> event) throws Exception {
      if (!Files.isHidden(event.context())) {
        subscriber.onNext(event);
      }
    }

    /**
     * Register the rootDirectory, and all its sub-directories.
     */
    private void registerAll(final Path rootDirectory) throws IOException {
      Files.walkFileTree(rootDirectory, new SimpleFileVisitor<Path>() {
        @Override
        public FileVisitResult preVisitDirectory(final Path dir, final BasicFileAttributes attrs)
          throws IOException {
          register(dir);
          return FileVisitResult.CONTINUE;
        }
      });
    }

    private void register(final Path dir) throws IOException {
      if (!Files.isHidden(dir)) {
        final WatchKey key = dir.register(watcher, ENTRY_CREATE, ENTRY_DELETE, ENTRY_MODIFY);
        directoriesByKey.put(key, dir);
      }
    }

    // register newly created directory to watching in recursive mode
    private void registerNewDirectory(
      final ObservableEmitter<WatchEvent<Path>> subscriber,
      final Path dir,
      final WatchEvent<Path> event) {
      final WatchEvent.Kind<Path> kind = event.kind();
      if (recursive && kind.equals(ENTRY_CREATE)) {
        final Path name = event.context();
        final Path child = dir.resolve(name);
        try {
          if (Files.isDirectory(child, NOFOLLOW_LINKS)) {
            registerAll(child);
          }
        } catch (final IOException exception) {
          subscriber.onError(exception);
        }
      }
    }
  }
}
