package io.i101.rx.file;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.FileTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import static java.nio.file.LinkOption.NOFOLLOW_LINKS;
import static java.nio.file.StandardWatchEventKinds.*;

@Slf4j
@Component
public class PolledPathWatcher {
  private static final long PATH_WAIT = 60000L; // milliseconds

  private final Map<Path, Long> expirationTimes = new ConcurrentHashMap<>();
  private final Map<WatchKey, Path> keys = new HashMap<>();

  @PostConstruct
  private void init() throws Exception {
    final Path watchableDir = Paths.get("/Volumes/STRONTIUM/Workspaces/tmp");
    final WatchService watchService = watchableDir.getFileSystem().newWatchService();
    register(watchService, watchableDir);

    for (; ; ) {
      //Retrieves and removes next watch key, waiting if none are present.
      WatchKey watchKey = watchService.take();

      for (; ; ) {
        long currentTime = System.currentTimeMillis();

        if (watchKey != null)
          handleWatchEvents(watchKey);

        handleExpiredWaitTimes(currentTime);

        // If there are no files left stop polling and block on .take()
        if (expirationTimes.isEmpty())
          break;

        //        long minExpiration = min(expirationTimes.values());
//        long minExpiration = expirationTimes.values().stream().max(Long::compareTo).get();
//        long timeout = minExpiration - currentTime;
//        log.info("timeout: " + timeout);

        watchKey = watchService.poll(PATH_WAIT, TimeUnit.MILLISECONDS);
      }
    }
  }

  private <T> WatchEvent<T> cast(WatchEvent<?> event) {
    return (WatchEvent<T>) event;
  }

  private void register(final WatchService watchService, final Path dir) throws IOException {
    if (!Files.isHidden(dir)) {
      final WatchKey key = dir.register(watchService, ENTRY_CREATE, ENTRY_DELETE, ENTRY_MODIFY);
      keys.put(key, dir);
    }
  }

  private void handleExpiredWaitTimes(Long currentTime) {
    // Start import for files for which the expiration time has passed
    for (Map.Entry<Path, Long> entry : expirationTimes.entrySet()) {
      if (entry.getValue() <= currentTime) {
        log.info("expired " + entry);
        // do something with the file
        expirationTimes.remove(entry.getKey());
      }
    }
  }

  private void handleWatchEvents(WatchKey watchKey) throws IOException {
    List<WatchEvent<?>> events = watchKey.pollEvents();
    for (WatchEvent<?> event : events) {
      handleWatchEvent(event, keys.get(watchKey));
    }
    // reset watch key to allow the key to be reported again by the watch service
    boolean valid = watchKey.reset();

    if (!valid) {
      keys.remove(watchKey);
    }

  }

  private void handleWatchEvent(WatchEvent<?> event, Path dir) throws IOException {
    WatchEvent.Kind<?> kind = event.kind();

    WatchEvent<Path> ev = cast(event);
    Path name = ev.context();
    Path child = dir.resolve(name);

    if (kind == ENTRY_MODIFY || kind == ENTRY_CREATE) {
      // Update modified time
      FileTime lastModified = Files.getLastModifiedTime(child, NOFOLLOW_LINKS);
      expirationTimes.put(name, lastModified.toMillis() + PATH_WAIT);
    }

    if (kind == ENTRY_DELETE) {
      expirationTimes.remove(name);
    }
  }
}
