package io.i101.rx.file;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.schedulers.Schedulers;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.nio.file.*;

import static java.nio.file.StandardWatchEventKinds.*;

@Component
@Slf4j
public class RxFileWatcher101 {
//  @PostConstruct
//  public void init() throws Exception {
////    final Path path = Paths.get("/Volumes/STRONTIUM/Workspaces/tmp");
////    final FileSystem fileSystem = path.getFileSystem();
////
////    final Flowable<WatchEvent<?>> flowable1 = createFlowable(fileSystem, path);
////    final Flowable<WatchEvent<?>> flowable2 = createFlowable(fileSystem, path);
////
////    flowable1
////      .subscribeOn(Schedulers.computation(), false)
////      .subscribe(watchEvent -> {
////        log.info("{} - {}", 1, watchEvent.context());
////      });
////
////    flowable2
////      .subscribeOn(Schedulers.computation(), false)
////      .subscribe(watchEvent -> {
////        log.info("{} - {}", 2, watchEvent.context());
////      });
//
//
//    final Flowable<WatchEvent<?>> watchEventFlowable = PathFlowables
//      .watchRecursive(Paths.get("/Volumes/STRONTIUM/Workspaces/tmp"))
//      .parallel()
//      .runOn(Schedulers.computation())
//      .filter(watchEvent -> {
//        final Path path = (Path) watchEvent.context();
//        return !path.toFile().isHidden();
//      })
//      .sequential();
//
////    Flowable.zip(
////      watchEventFlowable.map(watchEvent -> {
////        log.info("=====> {} =====>", 1);
////        final Path path = (Path) watchEvent.context();
////
////        try {
////          final boolean renamed = path.toFile().renameTo(Paths.get(path.toString() + ".xxx").toFile());
////
////          log.info("{} - Rename file -> {}", renamed, path.toAbsolutePath());
////        } catch (Exception ex) {
////          log.error("Can't rename file {}", path.toAbsolutePath());
////        }
////
////        log.info("{} - {} - {}", watchEvent.kind().name(), watchEvent.count(), path.toAbsolutePath());
////
////        log.info("<===== {} <=====", 1);
////
////        return watchEvent;
////      }),
////      watchEventFlowable.map(watchEvent -> {
////        log.info("=====> {} =====>", 2);
////
////        final Path path = (Path) watchEvent.context();
////        log.info("{} - {} - {}", watchEvent.kind().name(), watchEvent.count(), path.toAbsolutePath());
////
////        log.info("<===== {} <=====", 2);
////
////        return watchEvent;
////      }),
////      (watchEvent1, watchEvent2) -> {
////        return "DONE";
////      })
////      .subscribe(s -> log.info("subscribe -> {}", s));
//
//
//    watchEventFlowable
//      .subscribeOn(Schedulers.computation(), false)
//      .subscribe(watchEvent -> {
//        log.info("=====> {} =====>", 1);
//        final Path path = (Path) watchEvent.context();
//
//        try {
//          final boolean renamed = path.toFile().renameTo(Paths.get(path.toString() + ".xxx").toFile());
//
//          log.info("{} - Rename file -> {}", renamed, path.toAbsolutePath());
//        } catch (Exception ex) {
//          log.error("Can't rename file {}", path.toAbsolutePath());
//        }
//
//        log.info("{} - {} - {}", watchEvent.kind().name(), watchEvent.count(), path.toAbsolutePath());
//
//        log.info("<===== {} <=====", 1);
//      });
//
//    watchEventFlowable
//      .subscribeOn(Schedulers.computation(), false)
//      .subscribe(watchEvent -> {
//        log.info("=====> {} =====>", 2);
//
//        final Path path = (Path) watchEvent.context();
//        log.info("{} - {} - {}", watchEvent.kind().name(), watchEvent.count(), path.toAbsolutePath());
//
//        log.info("<===== {} <=====", 2);
//      });
//  }
//
//
////  private Flowable<WatchEvent<?>> createFlowable(FileSystem fs, Path path) {
////
////    return Flowable.create(subscriber -> {
////
////      WatchService watcher = fs.newWatchService();
////
////      subscriber.setCancellable(() -> watcher.close());
////
////      boolean error = false;
////      WatchKey key;
////      try {
////
////        key = path.register(watcher, ENTRY_CREATE, ENTRY_DELETE, ENTRY_MODIFY);
////      }
////      catch (IOException e) {
////        subscriber.onError(e);
////        error = true;
////      }
////
////      while (!error) {
////        key = watcher.take();
////
////        for (final WatchEvent<?> event : key.pollEvents()) {
////          subscriber.onNext(event);
////        }
////
////        key.reset();
////      }
////
////    }, BackpressureStrategy.BUFFER);
////
////  }
}
