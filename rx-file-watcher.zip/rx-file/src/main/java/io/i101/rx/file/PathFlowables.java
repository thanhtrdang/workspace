package io.i101.rx.file;

import de.helmbold.rxfilewatcher.PathObservables;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.Observable;

import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.HashMap;
import java.util.Map;

import static java.nio.file.LinkOption.NOFOLLOW_LINKS;
import static java.nio.file.StandardWatchEventKinds.*;

public final class PathFlowables {
  private PathFlowables() {}

  /**
   * Creates an observable that watches the given directory and all its subdirectories. Directories
   * that are created after subscription are watched, too.
   * @param path Root directory to be watched
   * @return Observable that emits an event for each filesystem event.
   * @throws IOException
   */
  public static Flowable<WatchEvent<?>> watchRecursive(final Path path) throws IOException {
    final boolean recursive = true;
    return new PathFlowables.FlowableFactory(path, recursive).create();
  }

  /**
   * Creates an observable that watches the given path but not its subdirectories.
   * @param path Path to be watched
   * @return Observable that emits an event for each filesystem event.
   * @throws IOException
   */
  public static Flowable<WatchEvent<?>> watchNonRecursive(final Path path) throws IOException {
    final boolean recursive = false;
    return new PathFlowables.FlowableFactory(path, recursive).create();
  }

  private static class FlowableFactory {
    private final WatchService watcher;
    private final Map<WatchKey, Path> directoriesByKey = new HashMap<>();
    private final Path directory;
    private final boolean recursive;

    private FlowableFactory(final Path path, final boolean recursive) throws IOException {
      watcher = path.getFileSystem().newWatchService();
      directory = path;
      this.recursive = recursive;
    }

    private Flowable<WatchEvent<?>> create() {
      return Flowable.create(emitter -> {
        boolean errorFree = true;
        try {
          if (recursive) {
            registerAll(directory);
          } else {
            register(directory);
          }
        } catch (IOException exception) {
          emitter.onError(exception);
          errorFree = false;
        }
        while (errorFree && !emitter.isCancelled()) {
          final WatchKey key;
          try {
            key = watcher.take();
          } catch (InterruptedException exception) {
            if (!emitter.isCancelled()) {
              emitter.onError(exception);
            }
            errorFree = false;
            break;
          }
          final Path dir = directoriesByKey.get(key);
          for (final WatchEvent<?> event : key.pollEvents()) {
            emitter.onNext(event);
            registerNewDirectory(emitter, dir, event);
          }
          // reset key and remove from set if directory is no longer accessible
          boolean valid = key.reset();
          if (!valid) {
            directoriesByKey.remove(key);
            // nothing to be watched
            if (directoriesByKey.isEmpty()) {
              break;
            }
          }
        }
        if (errorFree) {
          emitter.onComplete();
        }
      }, BackpressureStrategy.BUFFER);
    }

    /**
     * Register the rootDirectory, and all its sub-directories.
     */
    private void registerAll(final Path rootDirectory) throws IOException {
      Files.walkFileTree(rootDirectory, new SimpleFileVisitor<Path>() {
        @Override
        public FileVisitResult preVisitDirectory(final Path dir, final BasicFileAttributes attrs)
          throws IOException {
          register(dir);
          return FileVisitResult.CONTINUE;
        }
      });
    }

    private void register(final Path dir) throws IOException {
      final WatchKey key = dir.register(watcher, ENTRY_CREATE, ENTRY_DELETE, ENTRY_MODIFY);
      directoriesByKey.put(key, dir);
    }

    // register newly created directory to watching in recursive mode
    private void registerNewDirectory(final FlowableEmitter<WatchEvent<?>> emitter,
                                      final Path dir,
                                      final WatchEvent<?> event) {
      final WatchEvent.Kind<?> kind = event.kind();
      if (recursive && kind.equals(ENTRY_CREATE)) {
        // Context for directory entry event is the file name of entry
        @SuppressWarnings("unchecked")
        final WatchEvent<Path> eventWithPath = (WatchEvent<Path>) event;
        final Path name = eventWithPath.context();
        final Path child = dir.resolve(name);
        try {
          if (Files.isDirectory(child, NOFOLLOW_LINKS)) {
            registerAll(child);
          }
        } catch (final IOException exception) {
          emitter.onError(exception);
        }
      }
    }
  }
}
