package io.i101.rx.file;

import de.helmbold.rxfilewatcher.PathObservables;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

import static java.util.concurrent.TimeUnit.SECONDS;

@Slf4j
@Component
public class ObservableWatcher {
//  @PostConstruct
  public void init() throws Exception {
    final Path watchableDir = Paths.get("/Volumes/STRONTIUM/Workspaces/tmp");

    PathObservables
      .watchRecursive(watchableDir)
      .filter(watchEvent -> {
        final Path path = (Path) watchEvent.context();
        return !Files.isHidden(path);
      })
//      .delay(5, SECONDS)
      .distinctUntilChanged()
      .subscribe(watchEvent -> {
        final Path path = (Path) watchEvent.context();
        log.info("{} - {} - {}", watchEvent.kind().name(), watchEvent.count(), path.toAbsolutePath());
      });
  }
}
