package io.i101.rx.file;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.nio.file.Path;
import java.nio.file.Paths;

@Slf4j
@Component
public class RxPathWatcher {
//  @PostConstruct
  public void init() throws Exception {
    final Path watchableDir = Paths.get("/Volumes/STRONTIUM/Workspaces/tmp");

    RxPaths
      .watchRecursive(watchableDir)
//      .filter(watchEvent -> {
//        final Path path = (Path) watchEvent.context();
//        return !Files.isHidden(path);
//      })
      .subscribe(watchEvent -> {
        final Path path = (Path) watchEvent.context();
        log.info("{} - {} - {}", watchEvent.kind().name(), watchEvent.count(), path.toAbsolutePath());
      });
  }
}
