package io.i101.rx.rx101;

import io.reactivex.Flowable;
import io.reactivex.Scheduler;
import io.reactivex.schedulers.Schedulers;
import io.vavr.control.Try;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Slf4j
@SpringBootApplication
public class Rx101Application implements CommandLineRunner {
  public static void main(String[] args) {
    SpringApplication.run(Rx101Application.class, args);
  }

  @Override
  public void run(final String... args) {
//		final Flowable<String> rxFlowable = Flowable
//			.<Integer>generate(emitter -> {
//				int count = 0;
//				for (; ;) {
//					Try.run(() -> Thread.sleep(200));
//					emitter.onNext(count);
//					count = count + 1;
//				}
//			})
//			.map(count -> "Flowable-" + count)
//			.share();


//    final Flowable<String> rxFlowable = Flowable
//      .generate(() -> 11, (state, emitter) -> {
//        Try.run(() -> Thread.sleep(200));
//        emitter.onNext(state);
//        return state + 1;
//      })
//      .map(count -> "Flowable-" + count)
//      .share();

//		final Flowable<String> rxFlowable = Flowable
//			.<Integer>create(emitter -> {
//				int count = 0;
//				while (!emitter.isCancelled() && count < 20) {
//					emitter.onNext(count);
//					count = count + 1;
//				}
//			}, BackpressureStrategy.BUFFER)
//			.map(count -> "Flowable-" + count)
//			.share();

//    final Flowable<String> rxFlowable = Flowable
//      .interval(1, TimeUnit.SECONDS)
//      .map(count -> "Flowable-" + count)
//      .share();

//    final PublishSubject<String> rx = PublishSubject
//      .create(emitter -> {
//
//      })
//      .map(count -> "Flowable-" + count)
//      .share();


//    final Flowable<String> rxFlowable = Flowable
//      .just(32, 22, 43, 3423, 55, 66)
//      .map(count -> "Flowable-" + count)
//      .share();

//		final ConnectableFlowable<String> rxFlowable = ConnectableFlowable
//			.<Integer>create(emitter -> {
//				int count = 0;
//				while (!emitter.isCancelled()) {
//          Try.run(() -> Thread.sleep(1 000));
//					emitter.onNext(count);
//					count = count + 1;
//				}
//			}, BackpressureStrategy.BUFFER)
//			.map(count -> "Flowable-" + count)
//      .publish();
//
//		rxFlowable
//			.observeOn(Schedulers.computation())
//			.map(s -> {
////				Try.run(() -> Thread.sleep(4000));
//				return s;
//			})
//      .subscribe(s -> log.info("Subscribe-1 => {}", s));
//
//		rxFlowable
//			.observeOn(Schedulers.computation())
//			.map(s -> {
////				Try.run(() -> Thread.sleep(2500));
//				return s;
//			})
//			.subscribe(s -> log.info("Subscribe-2 => {}", s));
//
//    rxFlowable.connect();
//
//    Try.run(() -> new CountDownLatch(1).await());


    final CountDownLatch countDownLatch = new CountDownLatch(1);
//    System.setProperty("rx2.computation-threads", "3");

    final ExecutorService mainExecutor  = Executors.newFixedThreadPool(4);
    final ExecutorService subExecutor   = Executors.newFixedThreadPool(2);

    final Scheduler mainScheduler = Schedulers.from(mainExecutor);
    final Scheduler subScheduler  = Schedulers.from(subExecutor);

    Flowable
      .fromArray("Dang", "Trung", "Thanh", "Bon", "Be", "Han")
      .parallel()
      .runOn(mainScheduler)
      .map(name -> {
        log.info("<{}> Main - Thread - {}", name, Thread.currentThread().getName());
        Try.run(() -> Thread.sleep(name.length() * 1000));
        return name;
      })
      .flatMap(name -> {
        if (name.length() == 2) {
          return Flowable
            .fromArray("Tuong", "Lam", "Hehe")
            .parallel()
            .runOn(subScheduler)
            .map(subname -> {
              final String xName = name + "-xxx-" + subname;
              log.info("[{}] Sub - Thread - {}", xName, Thread.currentThread().getName());
              Try.run(() -> Thread.sleep(subname.length() * 1000));

              return xName;
            })
            .sequential();
//          return Flowable.empty();
        } else {
          return Flowable.just(name);
        }
      })
      .sequential()
      .observeOn(mainScheduler)
      .subscribe(
        name -> log.info("/Subscribe/ -> {}", name),
        throwable -> log.error("Err->", throwable),
        () -> {
          log.info("DONE");
          countDownLatch.countDown();
          mainExecutor.shutdownNow();
          subExecutor.shutdownNow();
        }
      );

    Try.run(() -> countDownLatch.await());
//    Try.run(() -> Thread.sleep(60_000));
  }
}
