import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { createSerializer } from 'enzyme-to-json';

configure({ adapter: new Adapter() });
expect.addSnapshotSerializer(createSerializer({ mode: 'deep' }));


// https://facebook.github.io/jest/docs/en/configuration.html
// https://github.com/adriantoine/enzyme-to-json
// https://stackoverflow.com/questions/46627353/where-should-the-enzyme-setup-file-be-written
// https://github.com/cypress-io/cypress
// http://phantomjs.org/
// https://www.joecolantonio.com/2016/06/14/top-8-essential-javascript-automation-frameworks/
// http://www.nightmarejs.org/
// DEBUG
// https://stackoverflow.com/questions/50790804/the-debug-type-is-not-recognized-type-node
// https://facebook.github.io/jest/docs/en/troubleshooting.html
/*
  Step 1: node --inspect-brk node_modules/.bin/jest --runInBand --setupTestFrameworkScriptFile=./test-setup.js
  Step 2: launch.json
    {
      "type": "node",
      "request": "attach",
      "name": "Debug Jest Tests",
      "port": 9229
    }
  Step 3: set breakpoints and F5 to debug

  OR
  launch.json (Jest only)
    {
      "name": "Debug Jest Tests",
      "type": "node",
      "request": "launch",
      "runtimeArgs": [
        "--inspect-brk",
        "${workspaceRoot}/node_modules/.bin/jest",
        "--runInBand",
        "--setupTestFrameworkScriptFile=${workspaceRoot}/test-setup.js"
      ],
      "console": "integratedTerminal",
      "internalConsoleOptions": "neverOpen"
    }

  ==> OR
  launch.json (Jest for create-react-app)
    {
      "name": "Jest Tests",
      "type": "node",
      "request": "launch",
      "runtimeExecutable": "${workspaceRoot}/node_modules/.bin/react-app-rewired",
      "args": ["test", "--runInBand", "--no-cache", "--env=jsdom"],
      "cwd": "${workspaceRoot}",
      "protocol": "inspector",
      "console": "integratedTerminal",
      "internalConsoleOptions": "neverOpen"
    }
*/
