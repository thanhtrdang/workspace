const path = require('path');
const rewireStyledComponents = require('react-app-rewire-styled-components');

module.exports = {
  webpack(config, env) {
    config.resolve.modules.unshift(path.resolve('./src'));

    config = rewireStyledComponents(config, env);

    return config;
  },
  jest(config) {
    // if (!config.testPathIgnorePatterns) {
    //   config.testPathIgnorePatterns = [];
    // }
    // if (!process.env.RUN_COMPONENT_TESTS) {
    //   config.testPathIgnorePatterns.push('<rootDir>/src/component/**/*.test.jsx');
    // }
    // if (!process.env.RUN_REDUCER_TESTS) {
    //   config.testPathIgnorePatterns.push('<rootDir>/src/component/**/*.test.jsx');
    // }
    config.setupTestFrameworkScriptFile = '<rootDir>/test-setup.js';

    return config;
  },
};

// https://github.com/react-boilerplate/react-boilerplate
// https://github.com/benmosher/eslint-plugin-import/tree/master/resolvers/node
// https://github.com/withspectrum/react-app-rewire-styled-components
