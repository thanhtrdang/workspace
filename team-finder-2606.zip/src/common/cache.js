// https://github.com/pazguille/offline-first
// https://github.com/localForage/localForage
// https://github.com/Level
// https://blog.reactnativecoach.com/the-definitive-guide-to-redux-persist-84738167975
// https://github.com/rt2zz/redux-persist


// localforage.config({
//   name: 'TeamFinder',
//   version: '1.0.1',
//   storeName: 'root', // Should be alphanumeric, with underscores.
//   description: 'TeamFinder cache level 2',
// });

// export default {
//   setPlayer: async (key, value) => localforage.setItem(`player.${key}`, value),
//   getPlayer: async key => localforage.getItem(`player.${key}`),
// };

import { persistCombineReducers, persistStore } from 'redux-persist';
import localforage from 'localforage';
// import storage from 'redux-persist/lib/storage';

let persistor;
// persistor is used for PersistGate
// see https://github.com/rt2zz/redux-persist/blob/master/docs/PersistGate.md
export const getPersistor = () => persistor;

// rematch plugin
const reactNavigationPlugin = (config = {}) => {
  // merge config with common config options
  const mergedConfig = {
    key: 'root',
    storage: localforage,
    serialize: false,
    ...config,
  };
  return {
    config: {
      // pass in merged config as first param of persistCombineReducers
      redux: {
        combineReducers: persistCombineReducers.bind(null, mergedConfig),
      },
    },
    onStoreCreated(store) {
      // run persist store once store is available
      persistor = persistStore(store);
    },
  };
};

export default reactNavigationPlugin;
