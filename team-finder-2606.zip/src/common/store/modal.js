const modal = {
  state: {
    isOpen: false,
    currentId: '',
  },
  reducers: {
    toggle: (state, payload) => ({
      isOpen: !state.isOpen,
      currentId: !state.isOpen ? payload : '',
    }),
  },
};

export default modal;
