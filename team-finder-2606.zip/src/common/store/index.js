// http://milworm.github.io/react-progress-2/example.html
import { init } from '@rematch/core';
// import { loadingBarReducer } from 'react-redux-loading-bar';
import createRematchPersist from 'common/cache';
import modal from './modal';
import notification from './notification';
import player from './player';

const persistPlugin = createRematchPersist({
  // whitelist: ['notification', 'player'],
  // throttle: 5000,
  version: 1,
});

const store = init({
  name: 'root',
  models: {
    modal,
    notification,
    player,
  },
  plugins: [persistPlugin],
  // redux: {
  //   reducers: {
  //     loadingBar: loadingBarReducer,
  //   },
  // },
});

export default store;
