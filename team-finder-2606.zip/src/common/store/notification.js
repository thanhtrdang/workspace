import { lensProp, over, add } from 'ramda';

const countLens = lensProp('count');
const countPayload = payload => add(payload);
const countInc = (state, payload) => over(countLens, countPayload(payload))(state);
// (state, payload) => state

const notification = {
  state: {
    count: 0,
    l1: {
      l2: {
        v1: 'val1',
        // v2: 'val2',
        v3: 'val3',
      },
    },
  },
  reducers: {
    notify: countInc,
  },
};

export default notification;
