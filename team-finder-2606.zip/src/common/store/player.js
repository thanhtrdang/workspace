import { lensProp, over, add } from 'ramda';

const countLens = lensProp('count');
const countPayload = payload => add(payload);
const countInc = (state, payload) => over(countLens, countPayload(payload))(state);


const player = {
  state: {
    count: 0,
  },
  reducers: {
    play: countInc,
    logX: (state, payload) => {
      const newState = state.update('count', count => count + payload);

      // console.log(`XXX-${JSON.stringify(newState.toJS())}`);

      return newState;
    },
  },
  effects: {
    async playX(payload, rootState) {
      // let playerXXX = await cache.getPlayer('player-xxx');
      // if (!playerXXX) {
      //   const response = await fetch('http://jsonplaceholder.typicode.com/users');
      //   playerXXX = await response.json();
      //   cache.setPlayer('player-xxx', playerXXX);
      // }

      // this.logX(playerXXX.length);
    },
  },
};

export default player;
