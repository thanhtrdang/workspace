import { normalize } from 'polished';
import { injectGlobal, css } from 'styled-components';

/*
  https://github.com/FullHuman/purgecss

  normalize

  margin(m)-[top(t) | right(r) | bottom(b) | left(l) | horizontal(h|x) | vertical(v|y)]
  padding(p)-[...]
  size(s)-[(min|max-)width(w)|(min|max-)height(h)]
  border(b)
  color(c)
  background(bg)

  layout
    size
    position
    flexbox
    z-index
  typography
    color
    font
      family
      size
      weight
  background
    attachment
    color
    position
    repeat
    size
  border
    color
    style
    width
    radius
  spacing
    margin
    padding
  sizing
    width
    height
    min|max
  state
    hover|enabled|disabled


  @font-face (DIN 2014)
  font {
    hairline: 100
    thin
    light
    normal
    medium
    semibold
    bold
    extrabold
    black: 900

    xs: .75rem
    sm: .875rem
    base: 1rem
    lg: 1.125rem
    xl: 1.25rem
    2xl: 1.5rem
    ...
  }


  color: {
    'transparent': 'transparent',

    // named
    'black': '#22292f',
    'white': '#ffffff',

    // functional
    'primary': 'xxx',
    'secondary': 'xxx',
    'brand': 'xxx',

    // variant, color palette
    'light': 'xxx',
    'dark': 'xxx',
    'darker': 'xxx',
  }

  text: text/headline

  screens: {
    'sm': '576px',
    'md': '768px',
    'lg': '992px',
    'xl': '1200px'
  }
  screens: {
    'tablet': '576px',
    // => @media (min-width: 576px) { ... }

    'laptop': '992px',
    // => @media (min-width: 992px) { ... }

    'desktop': '1200px',
    // => @media (min-width: 1200px) { ... }
  },

  state hover: focus: active: inactive:

*/
export default () => injectGlobal`
  ${normalize()}

  @import url("https://use.typekit.net/ipo1mfi.css");

  body {
    font-family: 'din-2014';
    padding: 0;
    background-color: #202020;
    color: #aaa;
    a {
      color: white;
      text-decoration: none;
    }
    button {
      color: white;
    }
  }
`;

export const theme = {
  //background: `radial-gradient(#475047, #272721)`,
  background: `radial-gradient(ellipse at right, #272721, transparent),
              radial-gradient(ellipse at top, #465048, transparent);`,
  font: {
    headline: {
      primary: css`
        font-size: 45px;
        font-weight: 600;
        color: rgba(255, 255, 255, 100);
        text-shadow: 0px 2px 10px rgba(0, 0, 0, 0.5);
      `,
      secondary: css`
        font-size: 22px;
        font-weight: 400;
        color: rgba(255, 255, 255, 100);
        text-shadow: 0px 2px 10px rgba(0, 0, 0, 0.5);
      `,
      teriary: css`
        font-size: 24px;
        font-weight: normal;
        color: rgba(255, 255, 255, 100);
        text-shadow: 0px 2px 10px rgba(0, 0, 0, 0.5);
      `,
      quaternary: css`
        font-size: 14px;
        font-weight: bold;
        color: rgba(255, 255, 255, 100);
      `,
    },
    text: {
      primary: css`
        font-size: 14px;
        font-weight: normal;
        color: rgba(255, 255, 255, 100);
      `,
      secondary: css`
        font-size: 12px;
        font-weight: normal;
        color: rgba(255, 255, 255, 70);
      `,
      tertiary: css`
        font-size: 12px;
        font-weight: bold;
        color: rgba(255, 135, 90, 100);
      `,
      link: css`
        font-size: 12px;
        font-weight: normal;
        color: rgba(255, 135, 90, 100);
      `,
    },
  },
  color: {

  },

  header: {
    background: '#202020',
  },
  footer: {
    background: '#202020',
  },
  text: {
    color: 'white',
  },
};

const xxx = {
  screen: {
    // mobile:tablet:laptop:desktop:tv
    // sm:md:lg:xl
  },
  color: {

  },
  font: {
    size: {
      xs: '.75rem', // ~12px
      sm: '.875rem', // ~14px
      base: '1rem', // ~16px
      lg: '1.125rem', // ~18px
      xl: '1.25rem', // ~20px
      x2l: '1.5rem', // ~24px
      x3l: '3rem', // ~48px
    },
    weight: {
      hairline: 100,
      thin: 200,
      light: 300,
      normal: 400,
      medium: 500,
      semibold: 600,
      bold: 700,
      extrabold: 800,
      black: 900,
    },
  },
  size: {
    width: {

    },
    height: {

    },
  },
};
