// https://github.com/FortAwesome/Font-Awesome/tree/master/advanced-options/use-with-node-js
// https://github.com/gilbarbara/logos
// https://github.com/svg/svgo
// https://stackoverflow.com/questions/50332064/make-a-collection-of-svg-files-into-something-like-fontawesomes-js
// (search faSomeObjectName, https://stackoverflow.com/users/4642871/mwilkerson)

import { config, library } from '@fortawesome/fontawesome';
import {
  facebook,
  discord,
  firstblood,
  teamfinder,
  radio,
  chatBubble,
  team,
} from 'component/icon';

export default () => {
  config.defaultPrefix = 'tf';

  library.add(
    facebook,
    discord,
    firstblood,
    teamfinder,
    radio,
    chatBubble,
    team,
  );
};
