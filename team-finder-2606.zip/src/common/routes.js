import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

import { Layout } from 'component';
import {
  Home,
  Signin,
  Signup,
  ResetPassword,
  Profile,

  PlayerListing,

  TeamListing,
  CreateTeam,
  EditTeam,

  AccountManagement,
  GameManagement,
  BannerManagement,

  NotFound,
} from 'page';

const routes = [
  {
    exact: true,
    path: '/',
    page: Home,
    title: 'Home',
    isHome: true,
  },

  {
    path: '/signin',
    page: Signin,
    title: 'Sign in',
  },
  {
    path: '/signup',
    page: Signup,
    title: 'Sign up',
  },
  {
    path: '/reset-password',
    page: ResetPassword,
    title: 'Reset password',
  },
  {
    path: '/profile',
    page: Profile,
    sidebar: true,
    title: 'Profile',
  },

  {
    path: '/player',
    page: PlayerListing,
    sidebar: true,
    title: 'Player Listing',
  },

  {
    exact: true,
    path: '/team',
    page: TeamListing,
    sidebar: true,
    title: 'Team Listing',
  },
  {
    path: '/team/create',
    page: CreateTeam,
    title: 'Create new team',
  },
  {
    path: '/team/edit',
    page: EditTeam,
    sidebar: true,
    title: 'Edit my team',
  },

  {
    path: '/admin/account',
    page: AccountManagement,
    sidebar: true,
    title: 'Account management',
  },
  {
    path: '/admin/game',
    page: GameManagement,
    sidebar: true,
    title: 'Game management',
    breadcrumb: 'Game management',
  },
  {
    path: '/admin/banner',
    page: BannerManagement,
    sidebar: true,
    title: 'Banner management',
  },

  {
    page: NotFound,
    status: 404,
    title: 'Ops!!! Not found',
  },
];

export default () => (
  <Router>
    <Switch>
      {routes.map(route => (
        <Route
          key={Math.random()}
          {...route}
          component={() => (
            <Layout {...route}>
              <route.page />
            </Layout>
          )}
        />
      ))}
    </Switch>
  </Router>
);
