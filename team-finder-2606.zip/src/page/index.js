import Home from './Home';

import Signin from './account/Signin';
import Signup from './account/Signup';
import ResetPassword from './account/ResetPassword';
import Profile from './account/Profile';

import PlayerListing from './player/PlayerListing';

import TeamListing from './team/TeamListing';
import CreateTeam from './team/CreateTeam';
import EditTeam from './team/EditTeam';

import AccountManagement from './admin/AccountManagement';
import GameManagement from './admin/GameManagement';
import BannerManagement from './admin/BannerManagement';

import NotFound from './NotFound';

export {
  Home,

  Signin,
  Signup,
  ResetPassword,
  Profile,

  PlayerListing,

  TeamListing,
  CreateTeam,
  EditTeam,

  AccountManagement,
  GameManagement,
  BannerManagement,

  NotFound,
};
