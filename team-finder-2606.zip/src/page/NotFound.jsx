import React from 'react';

const NotFound = () => (
  <div>
    404 page
  </div>
);

export default NotFound;
