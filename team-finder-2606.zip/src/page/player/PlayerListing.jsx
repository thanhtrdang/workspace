import React from 'react';
import { connect } from 'react-redux';
import styled from 'styled-components';
import FontAwesome from '@fortawesome/react-fontawesome';

import { Modal, Button, Tag } from 'component';
import { ModalConfigs } from 'component/modal/Modal';

const {
  SignupModal: SignupModalConfig,
  ResetPasswordModal: ResetPasswordModalConfig,
} = ModalConfigs;

const StyledPlayerListing = styled.div`
  /* height: 500px; */
`;

const PlayerListing = ({
  count, notify, playerCount, play, toggleModal,
}) => (
  <StyledPlayerListing>
    <Button
      border
      onClick={() => {
        notify(2);
      }}
    >
        Notification-{count}
    </Button>
    <Button
      gradient
      width="150px"
      height="36px"
      onClick={() => {
        play(3);
      }}
    >
      <FontAwesome icon="team" /> Player-{playerCount}
    </Button>
    <Button onClick={() => toggleModal(SignupModalConfig.id)}>
      Sign Up
    </Button>
    <Button onClick={() => toggleModal(ResetPasswordModalConfig.id)}>
      Reset Password
    </Button>
    <Button background="#4064AC">
        Background-XXX
    </Button>
    <Tag
      title="Team"
      onEdit={() => console.log('XXX-Tag-Edit')}
      onRemove={() => console.log('XXX-Tag-Remove')}
    />
    <Tag title="Readonly" />
    <Modal key={SignupModalConfig.id} {...SignupModalConfig}>
      Modal Content SignupModalConfig
    </Modal>
    <Modal key={ResetPasswordModalConfig.id} {...ResetPasswordModalConfig}>
      Modal Content ResetPasswordModal
    </Modal>
  </StyledPlayerListing>
);

// export default PlayerListing;

export default connect(
  state => ({
    count: state.notification.count,
    playerCount: state.player.count,
  }),
  dispatch => ({
    notify: dispatch.notification.notify,
    play: dispatch.player.play,
    toggleModal: dispatch.modal.toggle,
  }),
)(PlayerListing);
