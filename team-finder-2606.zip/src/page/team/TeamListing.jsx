import React from 'react';
import { connect } from 'react-redux';
import styled from 'styled-components';
import FontAwesome from '@fortawesome/react-fontawesome';

import { Modal, Button, Tag } from 'component';
import { ModalConfigs } from 'component/modal/Modal';

const {
  SignupModal: SignupModalConfig,
  ResetPasswordModal: ResetPasswordModalConfig,
} = ModalConfigs;

const StyledTeamListing = styled.div`
  /* height: 500px; */
`;

const TeamListing = ({
  count, notify, playerCount, play, toggleModal,
}) => (
  <StyledTeamListing>
    <Button
      border
      onClick={() => {
        notify(2);
      }}
    >
        Notification-{count}
    </Button>
    <Button
      gradient
      height="36px"
      onClick={() => {
        play(3);
      }}
    >
      <FontAwesome icon="facebook" /> Player-{playerCount}
    </Button>
    <Button onClick={() => toggleModal(SignupModalConfig.id)}>
      Sign Up
    </Button>
    <Button onClick={() => toggleModal(ResetPasswordModalConfig.id)}>
      Reset Password
    </Button>
    <Button background="#4064AC">
        Background-XXX
    </Button>
    <Tag
      title="Team"
      onEdit={() => console.log('XXX-Tag-Edit')}
      onRemove={() => console.log('XXX-Tag-Remove')}
    />
    <Tag title="Readonly" />
    <Modal key={SignupModalConfig.id} {...SignupModalConfig}>
      Modal Content SignupModalConfig
    </Modal>
    <Modal key={ResetPasswordModalConfig.id} {...ResetPasswordModalConfig}>
      Modal Content ResetPasswordModal
    </Modal>
  </StyledTeamListing>
);

export default connect(
  state => ({
    // count: state.notification.count,
    // playerCount: state.player.count,
  }),
  dispatch => ({
    // notify: dispatch.notification.notify,
    // play: dispatch.player.play,
    toggleModal: dispatch.modal.toggle,
  }),
)(TeamListing);
