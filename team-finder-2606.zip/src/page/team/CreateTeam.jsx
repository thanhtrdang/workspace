import React from 'react';

const CreateTeam = () => (
  <div>
    CreateTeam page
  </div>
);

export default CreateTeam;
