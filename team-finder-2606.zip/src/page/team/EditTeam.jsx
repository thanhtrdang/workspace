import React from 'react';

const EditTeam = () => (
  <div>
    EditTeam page
  </div>
);

export default EditTeam;
