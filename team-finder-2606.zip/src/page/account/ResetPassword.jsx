import React from 'react';

const ResetPassword = () => (
  <div>
    ResetPassword page
  </div>
);

export default ResetPassword;
