import React from 'react';

const Signin = () => (
  <div>
    Signin page
  </div>
);

export default Signin;
