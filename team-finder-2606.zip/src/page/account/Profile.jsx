import React from 'react';

const Profile = () => (
  <div>
    Profile page
  </div>
);

export default Profile;
