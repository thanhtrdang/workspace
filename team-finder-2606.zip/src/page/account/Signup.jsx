import React from 'react';

const Signup = () => (
  <div>
    Signup page
  </div>
);

export default Signup;
