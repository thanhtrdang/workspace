import React from 'react';
import styled, { css } from 'styled-components';
import Coverflow from 'component/coverflow/Coverflow';
import StarterPack from 'component/starter-pack/StarterPack';

const width = window.innerWidth * 0.65;
const height = window.innerHeight * 0.37;
const imgUrl = 'https://raw.githubusercontent.com/WXLKaylee/coverflow-reactjs/master/example/';

const cssHome = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  width: calc(100vw - 60px);
`;

const StyledTitle = styled.p`
    ${({ theme }) => theme.font.headline.primary};
    margin-bottom: 0;
`;

const StyledSubTitle = styled.p`
    ${({ theme }) => theme.font.headline.teriary};
`;

const jsxHome = ({ className }) => (
  <div className={className}>
    <StyledTitle>
      CHOOSE YOUR REALM
    </StyledTitle>
    <StyledSubTitle>
      Find your teammates, join the team in your game and level up!
    </StyledSubTitle>
    <Coverflow
      width={width}
      height={height}
      displayQuantityOfSide={2}
      navigation
      enableHeading={false}
      active={0}
    >
      <img draggable="false" src={`${imgUrl}/1.jpeg`} alt="" data-action="#" />
      <img draggable="false" src={`${imgUrl}/3.jpeg`} alt="" data-action="#" />
      <img draggable="false" src="http://math.rice.edu/~mjf8/ag/icons/icon3.gif" alt="" data-action="#" />
      <img draggable="false" src={`${imgUrl}/2.jpeg`} alt="" data-action="#" />
      <img draggable="false" src={`${imgUrl}/1.jpeg`} alt="DOTA" data-action="#" />
      <img draggable="false" src={`${imgUrl}/1.jpeg`} alt="" data-action="#" />
      <img draggable="false" src={`${imgUrl}/1.jpeg`} alt="" data-action="#" />
      <img draggable="false" src={`${imgUrl}/1.jpeg`} alt="" data-action="#" />
      <img draggable="false" src={`${imgUrl}/1.jpeg`} alt="" data-action="#" />
    </Coverflow>
    <StarterPack />
  </div>
);

export default styled(jsxHome)`${cssHome}`;
