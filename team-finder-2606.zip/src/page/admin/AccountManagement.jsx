import React from 'react';

const AccountManagement = () => (
  <div>
    AccountManagement page
  </div>
);

export default AccountManagement;
