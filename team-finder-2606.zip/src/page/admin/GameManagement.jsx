import React from 'react';

const GameManagement = () => (
  <div>
    GameManagement page
  </div>
);

export default GameManagement;
