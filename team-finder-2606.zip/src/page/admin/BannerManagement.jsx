import React from 'react';

const BannerManagement = () => (
  <div>
    BannerManagement page
  </div>
);

export default BannerManagement;
