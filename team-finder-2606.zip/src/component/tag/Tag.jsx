// @ts-check
import React from 'react';
import styled, { css } from 'styled-components';

const cssRemoveButton = css`
  height: 36px;
  width: 30px;
  background: transparent;
  outline: none;
  border: none;
  color: inherit;
`;
const cssEditButton = css`
  height: 36px;
  width: 30px;
  background: transparent;
  outline: none;
  border: none;
  color: inherit;
`;
const jsxButton = ({ className, children, ...props }) => (
  <button className={className} {...props}>{children}</button>
);
const RemoveButton = styled(jsxButton)`${cssRemoveButton}`;
const EditButton = styled(jsxButton)`${cssEditButton}`;

const cssTag = css`
  border-radius: 4px;
  height: 36px;
  display: inline-flex;
  background: #363636;
  align-items: center;
  color: #fff;
  padding: 0px 10px;
`;
const jsxTag = ({
  className, title, onEdit, onRemove,
}) => (
  <div className={className}>
    <span>{title}</span>
    {onEdit && <EditButton onClick={onEdit}>E</EditButton>}
    {onRemove && <RemoveButton onClick={onRemove}>x</RemoveButton>}
  </div>
);

const Tag = styled(jsxTag)`${cssTag}`;

export default Tag;
