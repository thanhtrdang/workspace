import styled from 'styled-components';

const Text = styled.span`
  ${p => p.theme.font.text[p.font]}
`;

const Headline = styled.span`
  ${p => p.theme.font.headline[p.font]}
`;

export {
  Text,
  Headline,
};

/*
  Text {
    color:
      named | functional | variant

    style:
      default (normal)
      uppercase | lowercase | capitalize | none (text-transform)
      italic | underline | line-through | bold | none (text-decoration)

    font:
      family: sans(default) | serif | mono // cursive | fantasy
      size:
      weight:

  }

  css font: https://www.w3schools.com/css/css_font.asp
  em vs. rem: https://webdesign.tutsplus.com/tutorials/comprehensive-guide-when-to-use-em-vs-rem--cms-23984
  (element vs. root element)
*/
