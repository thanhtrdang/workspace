import React from 'react';
import styled, { css } from 'styled-components';
import { prop } from 'ramda';
import FontAwesome from '@fortawesome/react-fontawesome';
import { Text, Headline } from 'component';

const cssCenterLink = css`
  margin: 0 20px;
  ${p => p.theme.font.text.primary}
`;
const jsxCenterLink = ({ className, icon, title }) => (
  <span className={className}>
    <FontAwesome icon={icon} /> {title} <sup>™</sup>
  </span>
);
const CenterLink = styled(jsxCenterLink)`${cssCenterLink}`;

const cssRightLink = css`
  margin-left: 20px;
  ${p => p.theme.font.text.secondary}
`;
const jsxRightLink = ({ className, to, title }) => (
  <a className={className} href={to}>
    {title}
  </a>
);
const RightLink = styled(jsxRightLink)`${cssRightLink}`;

const cssFooter = css`
  height: 70px;
  padding: 0px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  background-color: ${prop('theme.header.background')};
`;

const jsxFooter = ({ className }) => (
  <div className={className}>
    <div>
      <Text font="secondary">© 2018 Firstblood</Text>
    </div>
    <div>
      <CenterLink icon="firstblood" title="FIRSTBLOOD" />
      <CenterLink icon="teamfinder" title="TEAMFINDER" />
    </div>
    <div>
      <RightLink to="/terms-agreements" title="Terms &amp; Agreements" />
      <RightLink to="/privacy-policy" title="Privacy Policy" />
    </div>
  </div>
);


const Footer = styled(jsxFooter)`${cssFooter}`;

export default Footer;
