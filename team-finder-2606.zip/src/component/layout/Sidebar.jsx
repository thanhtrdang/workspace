import React from 'react';
import styled from 'styled-components';

const StyledSidebar = styled.div`
  margin-right: 30px;
  min-width: 200px;
  background: #242626;
  border-radius: 4px;
`;

const Sidebar = () => (
  <StyledSidebar>
    Sidebar
  </StyledSidebar>
);

export default Sidebar;
