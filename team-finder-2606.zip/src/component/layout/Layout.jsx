import React from 'react';
import { connect } from 'react-redux';
import { Helmet } from 'react-helmet';
// import LoadingBar from 'react-redux-loading-bar';
import styled from 'styled-components';
import Header from './Header';
import Sidebar from './Sidebar';
import Footer from './Footer';

const StyledContent = styled.div`
  background: ${({ isHome }) => (isHome ? 'transparent' : '#242626')};
  min-height: calc(100vh - 2 * (70px + 30px));
  border-radius: 4px;
`;

const StyledMain = styled.div`
  display: flex;
  justify-content: start;
  background: ${({ theme }) => theme.background};
  padding: 30px;
`;
const StyledBreadcrumb = styled.div`
  font-size: 1rem;
  font-weight: bold;
  margin-bottom: 20px;
  text-transform: uppercase;
`;

const Main = ({
  sidebar, breadcrumb, content, isHome,
}) => (
  <StyledMain>
    {sidebar && <Sidebar />}
    <div>
      {breadcrumb && <StyledBreadcrumb>{breadcrumb}</StyledBreadcrumb>}
      <StyledContent isHome={isHome}>{content}</StyledContent>
    </div>
  </StyledMain>
);

const StyledLayout = styled.div`
  display: flex;
  flex-direction: column;
  filter: ${({ isModalOpen }) => (isModalOpen ? 'blur(5px)' : '')};
`;

const Layout = ({
  title, sidebar, breadcrumb, children, isHome, isModalOpen,
}) => (
  <StyledLayout isModalOpen={isModalOpen}>
    <Helmet>
      <title>{`Team Finder - ${title}`}</title>
    </Helmet>
    {/* <LoadingBar style={{ backgroundColor: 'blue', height: '5px' }} /> */}
    <Header title={title} />
    <Main sidebar={sidebar} breadcrumb={breadcrumb} content={children} isHome={isHome} />
    <Footer />
  </StyledLayout>
);

export default connect(state => ({ isModalOpen: state.modal.isOpen }))(Layout);
