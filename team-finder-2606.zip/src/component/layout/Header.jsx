import React from 'react';
import { connect } from 'react-redux';
import styled, { css } from 'styled-components';
import { NavLink } from 'react-router-dom';
import FontAwesome from '@fortawesome/react-fontawesome';
import { Button } from '..';

const cssLeft = css`
  display: inline-flex;
  justify-content: flex-start;
  align-items: center;
  ${p => p.theme.font.headline.secondary}
  font-size: 20px;
`;
const jsxLeft = ({ className, children }) => (
  <div className={className}>{children}</div>
);
const Left = styled(jsxLeft)`${cssLeft}`;

const cssNavLink = css`
  margin: 0px 20px;

  ${p => p.theme.font.text.primary}

  &.active {
    border-bottom: 2px solid white;
  }
  &:hover {
    border-bottom: 2px solid white;
  }
`;
const NavItem = styled(NavLink)`${cssNavLink}`;


const cssRightIcons = css`
  display: flex;
  justify-content: center;
  align-items: center;
`;
const jsxRightIcons = ({ className }) => (
  <div className={className}>
    <FontAwesome icon="radio" style={{ fontSize: '1.5rem', opacity: 0.7 }} />
    <FontAwesome icon="chat-bubble" style={{ fontSize: '1.0rem', margin: '0 20px', opacity: 0.7 }} />
  </div>
);
const RightIcons = styled(jsxRightIcons)`${cssRightIcons}`;

const cssRightButtons = css`
  display: flex;
  justify-content: center;
  align-items: center;
`;
const jsxRightButtons = ({ className }) => (
  <div className={className}>
    <Button border width="120px" style={{ margin: '0 10px' }}>
      LOG IN
    </Button>
    <Button gradient width="120px">
      SIGN UP
    </Button>
  </div>
);
const Right = styled.div`
  display: inline-flex;
  justify-content: flex-end;
  align-items: center;
`;

const RightButtons = connect(
  state => ({
    count: state.notification.count,
  }),
  dispatch => ({
    notify: dispatch.notification.notify,
  }),
)(styled(jsxRightButtons)`${cssRightButtons}`);

const cssHeader = css`
  height: 70px;
  padding: 0px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: ${({ theme }) => theme.header.background};
`;
const jsxHeader = ({ className }) => (
  <div className={className}>
    <Left>
      <FontAwesome icon="teamfinder" style={{ color: 'green', paddingRight: '10px' }} />
      TEAMFINDER
      <sup>™</sup>
    </Left>
    <div>
      <NavItem exact to="/">HOME</NavItem>
      <NavItem to="/player">PLAYERS</NavItem>
      <NavItem to="/team">TEAMS</NavItem>
    </div>
    <Right>
      <RightIcons />
      <RightButtons />
    </Right>
  </div>
);

const Header = styled(jsxHeader)`${cssHeader}`;
export default Header;
