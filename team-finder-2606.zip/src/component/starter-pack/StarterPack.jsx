import React from 'react';
import { Button } from 'component';
import styled from 'styled-components';
import FontAwesome from '@fortawesome/react-fontawesome';

const StyledPack = styled.div`
    text-align: center;
`;

const StyledPackButton = styled.div`
    padding-top: 0.5em;
    padding-bottom: 0.5em;
`;

const StyledAnotherLogin = styled.div`
    ${({ theme }) => theme.font.text.link};
    color: #aaa;
`;

const StyledSoloIcon = styled.i`
    background: url('icons/solo.svg') no-repeat center 3px;
    background-size: 21px 21px;
    width: 30px;
    height: 30px;
    margin-right: 0.5em;
`;

const StyledTeamIcon = styled.i`
    background: url('icons/team.svg') no-repeat left 4px;
    background-size: 30px 30px;
    width: 30px;
    height: 30px;
    margin-right: 1em;
`;

const StyledDiscordIcon = styled.i`
    background: url('icons/discord.svg') no-repeat left 4px;
    background-size: 30px 30px;
    width: 30px;
    height: 30px;
    margin-right: 1em;
`;

export default class StarterPack extends React.Component {
    render() {
        return(
            <StyledPack>
              <StyledPackButton>
                <Button gradient medium>
                <StyledSoloIcon></StyledSoloIcon>
                CHECK DOTA2 PLAYERS
                </Button>
                <Button gradient medium>
                  <StyledTeamIcon />
                  CHECK DOTA2 TEAMS
                </Button>
              </StyledPackButton>
              <div>
                <p>
                  or signup
                </p>
              </div>
              <StyledPackButton>
                <Button medium>
                  <StyledDiscordIcon></StyledDiscordIcon>
                  CONTINUE WITH DISCORD
                </Button>
              </StyledPackButton>
              <StyledAnotherLogin>
                <p>
                  Continue with another login
                </p>
              </StyledAnotherLogin>
            </StyledPack>
        )
    }
}
