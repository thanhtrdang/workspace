/* eslint-disable */
/*
 * React Coverflow
 */
import styled from "styled-components";
import React, { Component } from "react";
import PropTypes from "prop-types";
import ReactDOM from "react-dom";
import CoverItem from "./CoverItem";
import Hotkeys from 'react-hot-keys';

let MOUSE = {
  move: false,
  down: false,
  startX: 0,
  startY: 0
};

let TOUCH = {
  move: false,
  lastX: 0,
  sign: 0,
  lastMove: 0
};

let TRANSITIONS = [
  "transitionend",
  "oTransitionEnd",
  "otransitionend",
  "MSTransitionEnd",
  "webkitTransitionEnd"
];

let HandleAnimationState = function() {
  this.removePointerEvents();
};

const StyledContainer = styled.div`
  text-align: center;
  margin: auto;
  width: ${props => props.style.width};
  height: ${props => props.style.height};
  position: relative;
  display: flex;
  padding-bottom: 1em;
`;

const StyledCoverContainer = styled.div`
  position: relative;
  margin: auto;
  width: 86%;
  height: 90%;
`;

const StyledCoverBox = styled.div`
  position: relative;
  margin: auto;
  overflow: hidden;
  display: block;
  width: 100%;
  height: 100%;
`;

const StyledCoverList = styled.div`
  position: relative;
  height: 100%;
  width: 100%;
  display: flex;
  justify-content: center;
  // margin: auto;
  transform-style: preserve-3d;
`;

const StyledPreContainer = styled.div`
  width: 7%;
  height: 80%;
  // text-align: right;
  // float: right;
  justify-content: flex-end;
  display: flex;
`;

const StyledNextContainer = styled.div`
  width: 7%;
  height: 80%;
  // text-align: left;
  // float: left;
  justify-content: flex-start;
  display: flex;
`;

const StyledPreArrow = styled.div`
  float: right;
  text-align: right;
  // text-align: center;
  justify-content: center;
  position: absolute;
  top: 39%;
  cursor: pointer;
  display: block;
`;

const StyledNextArrow = styled.div`
  justify-content: center;
  position: absolute;
  top: 39%;
  cursor: pointer;
  display: block;
`;

const StyledNavigationButton = styled.button`
  background: transparent;
  border: none;
  font-family: 'din-2014';
  font-size: 50px;
  text-shadow: 0px 2px 10px rgba(0, 0, 0, 0.5);
`;

export default class Coverflow extends Component {
  /**
   * Life cycle events
   */
  constructor(props) {
    super(props);
    this.state = {
      current: this.center(),
      move: 0,
      width: this.props.width || "auto",
      height: this.props.height || "auto"
    };
  }

  static propTypes = {
    children: PropTypes.node.isRequired,
    displayQuantityOfSide: PropTypes.number.isRequired,
    navigation: PropTypes.bool,
    enableHeading: PropTypes.bool,
    enableScroll: PropTypes.bool,
    clickable: PropTypes.bool,
    currentCoverScale: PropTypes.number,
    active: PropTypes.number,
    media: PropTypes.object,
    infiniteScroll: PropTypes.bool
  };

  static defaultProps = {
    navigation: false,
    enableHeading: true,
    enableScroll: true,
    clickable: true,
    currentCoverScale: 1.5,
    media: {},
    infiniteScroll: false
  };

  componentDidMount() {
    this.updateDimensions();
    let length = React.Children.count(this.props.children);
    console.log(this.state);
    let current = this.state;

    TRANSITIONS.forEach(event => {
      for (let i = 0; i < length; i++) {
        // let figureID = `figure_${i}`;
        // this.refs[figureID].addEventListener(
        //   event,
        //   HandleAnimationState.bind(this)
        // );
      }
    });

    const eventListener = window && window.addEventListener;

    if (eventListener) {
      window.addEventListener("resize", this.updateDimensions.bind(this));
    }
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.active !== nextProps.active) {
      this.updateDimensions(nextProps.active);
    }
  }

  componentWillUnmount() {
    let length = React.Children.count(this.props.children);

    TRANSITIONS.forEach(event => {
      for (let i = 0; i < length; i++) {
        // let figureID = `figure_${i}`;
        // this.refs[figureID].removeEventListener(
        //   event,
        //   HandleAnimationState.bind(this)
        // );
      }
    });
  }

  updateDimensions(active) {
    const { displayQuantityOfSide } = this.props;
    let length = React.Children.count(this.props.children);
    let center = this.center();
    let state = {
      width: ReactDOM.findDOMNode(this).offsetWidth,
      height: ReactDOM.findDOMNode(this).offsetHeight
    };

    let baseWidth = this.coverBaseWidth();
    let activeImg = typeof active === "number" ? active : this.props.active;
    if (typeof active === "number" && ~~active < length) {
      activeImg = ~~active;
      let move = 0;
      move = baseWidth * (center - activeImg);

      state = Object.assign({}, state, {
        current: active,
        move
      });
    }
    this.setState(state);
  }

  render() {
    const { enableScroll, navigation, infiniteScroll, media } = this.props;
    const { width, height, current } = this.state;
    let renderPrevBtn = infiniteScroll ? true : current > 0;
    let renderNextBtn = infiniteScroll
      ? true
      : current < this.props.children.length - 1;
    let slideWidth = this.coverBaseWidth() * this.props.currentCoverScale;
    return (
      <Hotkeys
        keyName="f,j"
        onKeyDown={this.onKeyDown.bind(this)}
      >
        <StyledContainer  style={{ width: `${width}px`, height: `${height}px` }}>
          <StyledPreContainer>
            <StyledPreArrow>
              {renderPrevBtn && (
                <StyledNavigationButton onClick={this.handlePrevCover.bind(this)}>{"<"}</StyledNavigationButton>
              )}
            </StyledPreArrow>
          </StyledPreContainer>
          <StyledCoverContainer>
            <StyledCoverBox>
              <StyledCoverList>{this.renderCoverList()}</StyledCoverList>
            </StyledCoverBox>
          </StyledCoverContainer>
          <StyledNextContainer>
            <StyledNextArrow>
              {renderNextBtn && (
                <StyledNavigationButton onClick={this.handleNextCover.bind(this)}>{">"}</StyledNavigationButton>
              )}
            </StyledNextArrow>
          </StyledNextContainer>
        </StyledContainer>
      </Hotkeys>
    );
  }

  onKeyDown(keyName, e, handle) {
    if (keyName === 'f' && this.hasNext()) {
      this.handleNextCover();
    } else if (keyName === 'j' && this.hasPrevious()) {
      this.handlePrevCover();
    }
  }

  /**
   * Private methods
   */
  center() {
    let length = React.Children.count(this.props.children);
    return Math.floor(length / 2);
  }

  coverBaseWidth() {
    const { displayQuantityOfSide } = this.props;
    const { width } = this.state;
    return width / (displayQuantityOfSide * 2.5 + 1);
  }

  handleCoverStyle(index, current) {
    const { displayQuantityOfSide } = this.props;
    const { width } = this.state;
    let style = {};
    let baseWidth = this.coverBaseWidth();
    let length = React.Children.count(this.props.children);
    let offset = length % 2 === 0 ? -width / 12 : 0;
    let scale = this.props.currentCoverScale - 0.2 * Math.abs(current - index);
    // Handle opacity
    let depth = displayQuantityOfSide - Math.abs(current - index);
    let opacity = 1 - 0.2 * Math.abs(current - index);
    // Handle translateX
    if (index === current) {
      style["width"] = `${baseWidth}px`;
      style["transform"] = `translateX(${this.state.move +
        offset}px)  scale(${scale}`;
      style["zIndex"] = `${10 - depth}`;
      style["opacity"] = opacity;
      style["boxShadow"] = `0px 0px 10px rgb(235, 70, 29)`;
      style["border"] = `1px solid rgb(235, 70, 29)`;
    } else if (index < current) {
      // Left side
      style["width"] = `${baseWidth}px`;
      style["transform"] = `translateX(${this.state.move +
        offset}px) rotateY(0deg) scale(${scale})`;
      style["zIndex"] = `-${Math.abs(current - index)}`;
      style["opacity"] = opacity;
    } else if (index > current) {
      // Right side
      style["width"] = `${baseWidth}px`;
      style["transform"] = ` translateX(${this.state.move +
        offset}px) rotateY(0deg) scale(${scale})`;
      style["zIndex"] = `-${Math.abs(current - index)}`;
      style["opacity"] = opacity;
    }
    return style;
  }

  renderCoverList = () => {
    const { enableHeading, displayQuantityOfSide } = this.props;
    const { current } = this.state;
    let figureNodes = React.Children.map(
      this.props.children,
      (child, index) => {
        let figureElement = React.cloneElement(child);
        let style = this.handleCoverStyle(index, current);
        let distance = Math.abs(current - index);
        let isCurrent = current === index;
        return (
          <CoverItem
            key={index}
            style={style}
            image={figureElement}
            isShow={distance <= displayQuantityOfSide ? true : false}
            onMouseDown={isCurrent ? this.handleMouseDown.bind(this) : ""}
            onMouseLeave={isCurrent ? this.handleMouseLeave.bind(this) : ""}
            onMouseMove={isCurrent ? this.handleMouseMove.bind(this) : ""}
            onClick={
              !isCurrent && distance <= displayQuantityOfSide
                ? e => {
                    this.handleCoverItemClick(index, e);
                  }
                : ""
            }
          />
        );
      }
    );
    return figureNodes;
  };

  removePointerEvents() {
    // this.refs.stage.style["pointerEvents"] = "auto";
  }

  hasPrevious = () => {
    return this.state.current - 1 >= 0;
  };

  hasNext = e => {
    return this.state.current + 1 < this.props.children.length;
  };

  handleCoverItemClick = (index, e) => {
    e.preventDefault();
    MOUSE.down = false;
    // this.refs.stage.style["pointerEvents"] = "none";
    const { displayQuantityOfSide } = this.props;
    const { width } = this.state;
    let baseWidth = this.coverBaseWidth();
    let distance = this.center() - index;
    let move = distance * baseWidth;
    this.setState({ current: index, move });
    this.removePointerEvents();
  };

  handleMouseMove = e => {
    e.preventDefault();
    if (!MOUSE.move) MOUSE.move = true;
  };

  handleMouseDown = e => {
    e.preventDefault();
    MOUSE.down = true;
    MOUSE.startX = e.screenX;
    MOUSE.startY = e.screenY;
  };

  handleMouseLeave = e => {
    e.preventDefault();
    let endX = e.screenX;
    let endY = e.screenY;

    if (MOUSE.down && MOUSE.move) {
      MOUSE.down = false;
      MOUSE.move = false;
      if (MOUSE.startX < endX && this.hasPrevious()) {
        this.handlePrevCover();
      } else if (MOUSE.startX > endX && this.hasNext()) {
        this.handleNextCover();
      }
    } else {
      MOUSE.down = false;
      MOUSE.move = false;
    }
  };

  handlePrevCover = e => {
    if (e != null) {
      e.preventDefault();
    }
    const { displayQuantityOfSide, infiniteScroll } = this.props;
    const { width } = this.state;
    let { current } = this.state;
    let baseWidth = this.coverBaseWidth();
    let distance =
      this.center() -
      (current - 1 < 0 ? this.props.children.length - 1 : current - 1);
    let move = distance * baseWidth;

    if (current - 1 >= 0) {
      this.setState({ current: current - 1, move });
      TOUCH.lastMove = move;
    }
    if (current - 1 < 0 && infiniteScroll) {
      this.setState({ current: this.props.children.length - 1, move });
      TOUCH.lastMove = move;
    }
  };

  handleNextCover = e => {
    if (e != null) {
      e.preventDefault();
    }
    const { displayQuantityOfSide, infiniteScroll } = this.props;
    const { width } = this.state;
    let { current } = this.state;
    let baseWidth = this.coverBaseWidth();
    let distance =
      this.center() -
      (current + 1 >= this.props.children.length ? 0 : current + 1);
    let move = distance * baseWidth;

    if (current + 1 < this.props.children.length) {
      this.setState({ current: current + 1, move });
      TOUCH.lastMove = move;
    }
    if (current + 1 >= this.props.children.length && infiniteScroll) {
      this.setState({ current: 0, move });
      TOUCH.lastMove = move;
    }
  };

  handleWheel(e) {
    let delta =
      Math.abs(e.deltaY) === 125
        ? e.deltaY * -120
        : e.deltaY < 0
          ? -600000
          : 600000;
    let count = Math.ceil(Math.abs(delta) / 120);

    if (count > 0) {
      const sign = Math.abs(delta) / delta;
      let func = null;

      if (sign > 0 && this.hasPrevious()) {
        e.preventDefault();
        func = this.handlePrevCover();
      } else if (sign < 0 && this.hasNext()) {
        e.preventDefault();
        func = this.handleNextCover();
      }

      if (typeof func === "function") {
        for (let i = 0; i < count; i++) func();
      }
    }
  }

  handleTouchStart(e) {
    TOUCH.lastX = e.nativeEvent.touches[0].clientX;
    TOUCH.lastMove = this.state.move;
  }

  handleTouchMove(e) {
    e.preventDefault();
    const { displayQuantityOfSide } = this.props;
    const { width } = this.state;

    let clientX = e.nativeEvent.touches[0].clientX;
    let lastX = TOUCH.lastX;
    let baseWidth = this.coverBaseWidth();
    let move = clientX - lastX;
    let totalMove = TOUCH.lastMove - move;
    let sign = Math.abs(move) / move;

    if (Math.abs(totalMove) >= baseWidth) {
      let fn = null;
      if (sign > 0) {
        fn = this.handlePrevCover();
      } else if (sign < 0) {
        fn = this.handleNextCover();
      }
      if (typeof fn === "function") {
        fn();
      }
    }
  }
}
