// @ts-check
import React from 'react';
import styled from 'styled-components';
import defaultCoverflow from 'asset/teamfinder-logo.svg';

const StyledContainer = styled.div`
  display: block;
  position: relative;
  margin: 0;
  padding: 0;
  flex: 0 0 auto;
  transition: transform 600ms ease;
  backface-visibility: hidden;
  z-index: 9;
  align-self: center;
  border-radius: 5px;
`;

const StyledImageContent = styled.div`
  height: 80%;
  width: 100%;
  display: block;
  position: relative;
  margin: 0;
  padding: 0;
  flex: 0 0 auto;
  backface-visibility: hidden;
  // z-index: 9;
  align-self: center;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
`;

const StyledLabel = styled.div`
  margin: 0;
  background: transparent;
  color: #fff;
  text-align: center;
  position: relative;
  bottom: 0;
  left: 0;
  right: 0;
  font-size: 0.8em;
  // display: flex;
`;

const StyledImage = styled.img`
  display: block;
  width: 100%;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
  background: ${props => props.placeholder};
`;

const handleImageLoaded = (e, url) => {
  e.target.src = url;
};

const CoverItem = ({
  index,
  style,
  image,
  isShow,
  onMouseDown,
  onMouseLeave,
  onMouseMove,
  onClick,
}) => (
  <StyledContainer style={style}>
    <StyledImageContent
      placeholder={`url("${defaultCoverflow}")`}
      key={index}
      onMouseDown={onMouseDown}
      onMouseLeave={onMouseLeave}
      onMouseMove={onMouseMove}
      onClick={onClick}
    >
      {isShow && (
        <StyledImage
          src={defaultCoverflow}
          placeholder={`url("${defaultCoverflow}")`}
          onLoad={e => handleImageLoaded(e, image.props.src)}
        />
      )}
    </StyledImageContent>
    {false && isShow && <StyledLabel>{image.props.alt}</StyledLabel>}
  </StyledContainer>
);

export default CoverItem;
