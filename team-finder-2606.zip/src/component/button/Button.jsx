// @ts-check
import React from 'react';
import styled, { css } from 'styled-components';
import classNames from 'classnames';
import { lighten } from 'polished';

// border, gradient, color
// icon
// status: enabled/disabled
const cssButton = css`
  border-radius: 4px;
  padding: 0em 1em;
  /* margin: 1em 1em; */
  outline: none;
  text-transform: uppercase;
  font-weight: bold;
  font-size: 0.8rem;
  background: ${({ background }) => background || '#6F86CF'};
  border: none;
  min-width: 100px;
  min-height: 35px;
  width: ${({ width }) => width};
  height: ${({ height }) => height};
  display: inline-flex;
  justify-content: center;
  align-items: center;
  padding-left: 20px;
  padding-right: 20px;
  font-family: 'din-2014';

  &:hover {
    background: ${({ background }) => lighten(0.1, background || '#6F86CF')};
  }

  &.border {
    border: 1px solid white;
    background: #202020;
  }

  &.gradient {
    background: linear-gradient(180deg, #FF875A 0%, #E42652 100%);
  }

  &.medium {
    width: 298px;
    height: 42px;
    font-size: 1.05rem;
    font-weight: 500;
    margin-left: 0.8rem;
    margin-right: 0.8rem;
  }
`;

const jsxButton = ({
  className, border, gradient, medium, children, ...props
}) => (
  <button className={classNames(className, { border, gradient, medium })} {...props}>{children}</button>
);

const Button = styled(jsxButton)`${cssButton}`;

export default Button;
