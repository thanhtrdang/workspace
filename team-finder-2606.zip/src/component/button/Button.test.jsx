import React from 'react';
import { shallow } from 'enzyme';
import json from 'enzyme-to-json';
import 'jest-styled-components';

import Button from './Button';

describe('Button', () => {
  it('Title', () => {
    const button = shallow(<Button>Hey, you</Button>);
    expect(json(button)).toHaveStyleRule('font-weight', 'bold');
  });
});
