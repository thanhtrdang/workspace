// http://arianv.com/post/use-default-hocs-for-component-logic/
import React from 'react';
import { connect } from 'react-redux';
import ReactModal from 'react-modal';
import styled from 'styled-components';

ReactModal.setAppElement('#root');
ReactModal.defaultStyles.overlay.backgroundColor = 'none';

const ModalConfigs = {
  SigninModal: {
    id: 'bhkjhsdfds',
    name: 'SigninModal',
    title: 'Login to Teamfinder',
  },
  SignupModal: {
    id: 'uoiuoiuoiuo',
    name: 'SignupModal',
    title: 'Register a new Teamfinder account',
  },
  ResetPasswordModal: {
    id: 'xusdfdsfds',
    name: 'ResetPasswordModal',
    title: 'Reset my Teamfinder password',
  },
};

const Content = styled.div`
  width: 75%;
`;

const Title = styled.h4`
  color: black;
`;

const Modal = ({
  id, isOpen, currentId, title, children, toggleModal,
}) => (
  <ReactModal
    isOpen={isOpen && id === currentId}
    onRequestClose={() => toggleModal(id)}
  >
    <Content>
      <Title>{title}</Title>
      <div>{children}</div>
      <div>Already have an account? <a href="/signin">Log in</a></div>
    </Content>
  </ReactModal>
);

export { ModalConfigs };
export default connect(
  state => ({
    isOpen: state.modal.isOpen,
    currentId: state.modal.currentId,
  }),
  dispatch => ({
    toggleModal: dispatch.modal.toggle,
  }),
)(Modal);
