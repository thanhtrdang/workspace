// @ts-check
import React from 'react';
import ReactDOM from 'react-dom';
import { Provider as ReduxProvider } from 'react-redux';
import { ThemeProvider } from 'styled-components';
import { PersistGate } from 'redux-persist/integration/react';

import Router from './common/routes';
import store from './common/store';
import { getPersistor } from './common/cache';
import configIcon from './common/icon';
import normalizeCSS, { theme } from './common/style';

import registerServiceWorker from './registerServiceWorker';

normalizeCSS();
configIcon();

ReactDOM.render(
  <ReduxProvider store={store}>
    <PersistGate persistor={getPersistor()}>
      <ThemeProvider theme={theme}>
        <Router />
      </ThemeProvider>
    </PersistGate>
  </ReduxProvider>,
  document.getElementById('root'),
);

registerServiceWorker();
