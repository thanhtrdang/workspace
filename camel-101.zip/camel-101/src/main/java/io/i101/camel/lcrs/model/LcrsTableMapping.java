package io.i101.camel.lcrs.model;

import io.vavr.collection.HashSet;
import io.vavr.collection.Set;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.trimToEmpty;

@RequiredArgsConstructor
@Getter
public enum LcrsTableMapping {
  UNSUPPORTED(EMPTY, EMPTY, EMPTY),
  NSFR_TIME_BAND(EMPTY, EMPTY, EMPTY),
  NSFR_DIMENSION_RESULT(EMPTY, EMPTY, EMPTY),
  NSFR_TIME_SEGMENT_RESULT(EMPTY, EMPTY, EMPTY),
  NSFR_TIME_T_LR(EMPTY, EMPTY, EMPTY),
  NSFR_TIME_T_LR_BUFFER(EMPTY, EMPTY, EMPTY);

  private final String lcrsTableName;
  private final String impalaTableName;
  private final String impalaViewName;

  private static final Set<LcrsTableMapping> SUPPORTED_MAPPINGS = HashSet
    .of(LcrsTableMapping.values())
    .filter(LcrsTableMapping::isSupported);

  public static final Set<String> NSFR_TABLES = SUPPORTED_MAPPINGS.map(LcrsTableMapping::nsfrTableName);
  public static final Set<String> LCRS_TABLES = SUPPORTED_MAPPINGS.map(LcrsTableMapping::lcrsTableName);

  public static LcrsTableMapping mapNsfrTableName(final String nsfrTableName) {
    final String uppercaseNsfrTableName = trimToEmpty(nsfrTableName).toLowerCase();

    return SUPPORTED_MAPPINGS
      .find(mapping -> mapping.nsfrTableName().equals(uppercaseNsfrTableName))
      .getOrElse(UNSUPPORTED);
  }

  public static LcrsTableMapping mapLcrsTableName(final String lcrsTableName) {
    final String uppercaseLcrsTableName = trimToEmpty(lcrsTableName).toLowerCase();

    return SUPPORTED_MAPPINGS
      .find(mapping -> mapping.lcrsTableName.equals(uppercaseLcrsTableName))
      .getOrElse(UNSUPPORTED);
  }

  public String nsfrTableName() {
    return name();
  }

  public boolean isSupported() {
    return !isUnsupported();
  }

  public boolean isUnsupported() {
    return equals(UNSUPPORTED);
  }

}
