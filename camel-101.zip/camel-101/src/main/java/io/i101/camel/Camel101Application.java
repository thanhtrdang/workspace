package io.i101.camel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Camel101Application {
  public static void main(String[] args) {
    SpringApplication.run(Camel101Application.class, args);
  }
}
