package io.i101.camel.lcrs.model;

import lombok.Value;

@Value
public class LcrsRetryCount {
  public static final LcrsRetryCount ZERO_RETRY_COUNT = new LcrsRetryCount(0, 0);

  private final int countRows;
  private final int insertCsv;

  private LcrsRetryCount(final int countRows, final int insertCsv) {
    this.countRows = countRows > 0 ? countRows : 0;
    this.insertCsv = insertCsv > 0 ? insertCsv : 0;
  }

  public LcrsRetryCount retryCountRows(final int count) {
    if (count > 0) {
      return new LcrsRetryCount(countRows + count, insertCsv);
    } else {
      return this;
    }
  }

  public LcrsRetryCount retryInsertCsv(final int count) {
    if (count > 0) {
      return new LcrsRetryCount(countRows, insertCsv + count);
    } else {
      return this;
    }
  }
}
