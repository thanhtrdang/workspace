package io.i101.camel.lcrs.model;

import lombok.Value;

import java.util.Date;

import static io.i101.camel.lcrs.model.LcrsRetryCount.ZERO_RETRY_COUNT;

@Value
public class LcrsModel {
  // May configured externally later.
  private static final String DEFAULT_CREATED_BY = "LCRS";

  private final LcrsToken token;
  private final LcrsCsv csv;

  private final LcrsNsfrLogic nsfrLogic;
  private final Date createdDate;

  private final LcrsRetryCount retryCount;

  private LcrsModel(final LcrsToken token, final int retryCountRows) {
    this.token = token;
    csv = null;
    nsfrLogic = null;
    createdDate = new Date();
    retryCount = ZERO_RETRY_COUNT.retryCountRows(retryCountRows);
  }

  public static LcrsModel valid(final LcrsToken token, final int countRows, final LcrsCsv csv, final LcrsNsfrLogic nsfrLogic) {
    final LcrsRetryCount retryCount = ZERO_RETRY_COUNT.retryCountRows(countRows);

    return null;

//    return new LcrsModel(token, Option.of(csv), retryCount, Option.of(nsfrLogic));
  }


  public static LcrsModel invalid(final LcrsToken token, final int retryCountRows) {
    return new LcrsModel(token, retryCountRows);
  }

  public LcrsModel invalid(final int retryInsertCsv) {
//    final LcrsRetryCount retryCount = ZERO_RETRY_COUNT.retryInsertCsv(retryInsertCsv);

    return new LcrsModel(this.token, retryInsertCsv);
  }

}
