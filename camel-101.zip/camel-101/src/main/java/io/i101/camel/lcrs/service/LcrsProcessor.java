package io.i101.camel.lcrs.service;

import io.i101.camel.lcrs.model.LcrsModel;
import io.i101.camel.lcrs.model.LcrsToken;
import io.vavr.control.Try;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

import static org.apache.camel.Exchange.FILE_PATH;

@Slf4j
@Component
public class LcrsProcessor {
  @Autowired
  private LcrsLogger lcrsLogger;

  public LcrsToken transformToTokenFile(final Exchange exchange) {
    final Message messageIn = exchange.getIn();

    final String tokenPath = messageIn.getHeader(FILE_PATH, String.class);
    final String tokenContent = messageIn.getBody(String.class);

    return LcrsToken.build(tokenPath, tokenContent);
  }

  @SneakyThrows
  public LcrsModel transformToLcrsModel(final LcrsToken token, final int retryCountRows) {
    TimeUnit.SECONDS.sleep(2);

    return LcrsModel.invalid(token, retryCountRows);

//    if (token.isValid()) {
//      final Option<LcrsNsfrLogic> nsfrLogic = LcrsNsfrLogic.mapToken(token);
//
//    }
//
//    return null;
  }

  @SneakyThrows
  public LcrsModel insertCsvData(final LcrsModel model, final int retryInsertCsvRetry) {
    TimeUnit.SECONDS.sleep(2);

    return model.invalid(retryInsertCsvRetry);
  }

  public LcrsModel processFinally(final LcrsModel model) {
    Try
      .run(() -> {
        LcrsToken.removeFromCache(model.token());
        lcrsLogger.logCsvStatus(model);
        lcrsLogger.sendEmail(model);
      })
      .onFailure(throwable -> log.error("{}", throwable));

    return model;
  }
}
