package io.i101.camel.lcrs.model;

import io.vavr.control.Try;
import lombok.Builder;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;

import java.util.StringJoiner;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.apache.commons.codec.digest.DigestUtils.md2Hex;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.trimToEmpty;

/**
 * Token sample:
 * R_CFL_TIME_SEGMENT|RK_20180131_1010|145343
 * tableName|RK_timekey_workspaceId|rowCount
 */
@Slf4j
@Builder(toBuilder = true)
@Value
public class LcrsToken {
  private static final Pattern RK_PATTERN = Pattern.compile("RK_([0-9]{8})_([0-9]{4})");
  private static final String[] EMPTY_REGION_KEY = new String[]{EMPTY, EMPTY};
  private static final LcrsToken EMPTY_TOKEN = empty();

  private static final ConcurrentMap<String, Boolean> cache = new ConcurrentHashMap<>();

  private final String filePath;
  private final String content;

  private final String tableName;
  private final String timekey;
  private final String workspaceId;
  private final long rowCount;

  private final boolean isValid;

  private static LcrsToken empty() {
    return LcrsToken
      .builder()
      .filePath(EMPTY)
      .content(EMPTY)
      .tableName(EMPTY)
      .timekey(EMPTY)
      .workspaceId(EMPTY)
      .rowCount(0)
      .isValid(false)
      .build();
  }

  private static LcrsToken plain(final String filePath, final String content) {
    return EMPTY_TOKEN
      .toBuilder()
      .filePath(filePath)
      .content(content)
      .build();
  }

  private static LcrsToken parse(final String filePath, final String content) {
    final String[] tokenParts = trimToEmpty(content).split("\\|");

    final String tableName = trimToEmpty(tokenParts[0]);

    final String regionKey = trimToEmpty(tokenParts[1]);
    final String[] regionKeyParts = transformRegionKey(regionKey);

    final String timekey = transformTimekey(regionKeyParts[0]);
    final String workspaceId = regionKeyParts[1];
    final long rowCount = Long.valueOf(trimToEmpty(tokenParts[2]));
    final boolean isValid = validate(tableName, timekey, workspaceId, rowCount);

    return LcrsToken
      .builder()
      .filePath(filePath)
      .content(content)
      .tableName(tableName)
      .timekey(timekey)
      .workspaceId(workspaceId)
      .rowCount(rowCount)
      .isValid(isValid)
      .build();
  }

  public static LcrsToken build(final String filePath, final String content) {
    return Try
      .of(() -> parse(filePath, content))
      .onFailure(throwable -> log.error("Incorrect token [path={}, content={}] {}", filePath, content, throwable))
      .getOrElse(plain(filePath, content));
  }

  /**
   * regionKey -> [timekey, workspaceId]
   *
   * @param regionKey RK_20180131_0101
   * @return [timekey, workspaceId]
   */
  private static String[] transformRegionKey(final String regionKey) {
    final Matcher rkMatcher = RK_PATTERN.matcher(regionKey);

    if (rkMatcher.find()) {
      final String timekey = rkMatcher.group(1);
      final String workspaceId = rkMatcher.group(2);

      return new String[]{timekey, workspaceId};
    } else {
      return EMPTY_REGION_KEY;
    }
  }

  /**
   * yyyyMMdd -> yyyy-MM-dd
   *
   * @param timekey 20180131
   * @return 2018-01-31
   */
  private static String transformTimekey(final String timekey) {
    final String year = timekey.substring(0, 4);
    final String month = timekey.substring(4, 6);
    final String day = timekey.substring(6, 8);

    final StringJoiner timekeyJoiner = new StringJoiner("-")
      .add(year)
      .add(month)
      .add(day);

    return timekeyJoiner.toString();
  }

  private static boolean validate(final String tableName, final String timekey, final String workspaceId, final long rowCount) {
    return !(tableName.isEmpty()
      || timekey.isEmpty()
      || workspaceId.isEmpty()
      || rowCount <= 0);
  }

  public String partitionKey() {
    return timekey + workspaceId;
  }

  public String generatePlainId() {
    return md2Hex(filePath + content);
  }

  public static boolean cacheIfAbsent(final LcrsToken token) {
    final String plainId = token.generatePlainId();

    return cache.putIfAbsent(plainId, true) == null;
  }

  public static void removeFromCache(final LcrsToken token) {
    final String plainId = token.generatePlainId();

    cache.remove(plainId);
  }
}
