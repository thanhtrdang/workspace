package io.i101.camel.lcrs.model;

import lombok.Value;

@Value
public class LcrsCsv {
  private final String filePath;
  private final String checksum;
  private final long rowCount;
  private final boolean isValid;

  
}
