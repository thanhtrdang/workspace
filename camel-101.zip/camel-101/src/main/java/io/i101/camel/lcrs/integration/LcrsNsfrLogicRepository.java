package io.i101.camel.lcrs.integration;

import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

import static java.util.Collections.emptyList;

@Component
public class LcrsNsfrLogicRepository {
  public List<Map<String, String>> loadNsfrLogics() {
    return emptyList();
  }
}
