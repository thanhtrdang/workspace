package io.i101.camel.lcrs.service;

import io.i101.camel.lcrs.model.LcrsModel;
import io.i101.camel.lcrs.model.LcrsToken;
import io.vavr.control.Try;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class LcrsLogger {
  public void logTokenStatus(final LcrsToken token) {
    Try
      .run(() -> {
        log.info("LcrsToken {}", token);
        TimeUnit.SECONDS.sleep(1);
      })
      .onFailure(throwable -> {
        log.error("{}", throwable);
      });
  }

  public void logCsvStatus(final LcrsModel model) {
    Try
      .run(() -> {
        log.info("LcrsModel {}", model);
        TimeUnit.SECONDS.sleep(2);
      })
      .onFailure(throwable -> {
        log.error("{}", throwable);
      });
  }

  public void sendEmail(final LcrsModel model) {
    Try
      .run(() -> {
        TimeUnit.SECONDS.sleep(2);
      })
      .onFailure(throwable -> {
        log.error("{}", throwable);
      });
  }
}
