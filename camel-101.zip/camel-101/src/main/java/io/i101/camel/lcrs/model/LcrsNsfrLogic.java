package io.i101.camel.lcrs.model;

import io.vavr.collection.HashSet;
import io.vavr.collection.Set;
import io.vavr.control.Option;
import lombok.Data;
import lombok.Synchronized;

import java.util.List;
import java.util.Map;

import static io.vavr.collection.HashSet.empty;
import static java.lang.String.format;
import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.trimToEmpty;

@Data
public class LcrsNsfrLogic {
  private static final String REFRESH_LOGIC_TEMPLATE = "ALTER TABLE %s RECOVER PARTITIONS";
  private static final String COUNT_LOGIC_TEMPLATE = "SELECT count(*) FROM %s";

  private static Set<LcrsNsfrLogic> cache = empty();

  private final String tableName;
  private final String workspaceId;
  private final String regulator;
  private final String logic;

  private final LcrsTableMapping mapping;
  private final String refreshLogic;
  private final String countLogic;

  private LcrsNsfrLogic(final Map<String, String> record) {
    this.tableName = trimToEmpty(record.get("table_name"));
    this.workspaceId = trimToEmpty(record.get("workspace_id"));
    this.regulator = trimToEmpty(record.get("regulator"));
    this.logic = trimToEmpty(record.get("logic"));

    mapping = LcrsTableMapping.mapNsfrTableName(this.tableName);
    if (mapping.isSupported()) {
      refreshLogic = format(REFRESH_LOGIC_TEMPLATE, mapping.impalaTableName());
      countLogic = format(COUNT_LOGIC_TEMPLATE, mapping.impalaTableName());
    } else {
      refreshLogic = EMPTY;
      countLogic = EMPTY;
    }
  }

  /**
   * Build only once at the startup, load logics from MariaDB.
   */
  @Synchronized
  public static void buildCache(final List<Map<String, String>> nsfrLogics) {
    if (cache.isEmpty()) {
      cache = HashSet
        .ofAll(nsfrLogics)
        .map(LcrsNsfrLogic::new)
        .filter(logic -> logic.mapping.isSupported());
    }
  }

  public static Option<LcrsNsfrLogic> mapToken(final LcrsToken token) {
    return cache
      .find(nsfrLogic ->
        nsfrLogic.tableName.equalsIgnoreCase(token.tableName()) && nsfrLogic.workspaceId.equalsIgnoreCase(token.workspaceId())
      );
  }
}
