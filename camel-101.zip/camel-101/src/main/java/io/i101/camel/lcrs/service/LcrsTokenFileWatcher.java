package io.i101.camel.lcrs.service;

import io.i101.camel.lcrs.integration.LcrsNsfrLogicRepository;
import io.i101.camel.lcrs.model.LcrsModel;
import io.i101.camel.lcrs.model.LcrsNsfrLogic;
import io.i101.camel.lcrs.model.LcrsToken;
import io.reactivex.Flowable;
import io.reactivex.schedulers.Schedulers;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.reactive.streams.api.CamelReactiveStreams;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Map;

@Component
public class LcrsTokenFileWatcher extends RouteBuilder {
  @Value("${lcrs.max-retries:3}")
  private int maxRetries;
  @Value("${lcrs.retry-delay:6}")
  private int retryDelay;

  @Autowired
  private LcrsProcessor lcrsProcessor;
  @Autowired
  private LcrsLogger lcrsLogger;
  @Autowired
  private LcrsNsfrLogicRepository lcrsNsfrLogicRepository;

  @PostConstruct
  private void init() {
    final List<Map<String, String>> nsfrLogics = lcrsNsfrLogicRepository.loadNsfrLogics();
    LcrsNsfrLogic.buildCache(nsfrLogics);
  }

  @Override
  public void configure() {
    final Publisher<Exchange> tokenFilePublisher = CamelReactiveStreams
      .get(getContext())
      .from("{{lcrs.inbound}}");

    final Flowable<LcrsToken> rxToken = Flowable
      .defer(() -> tokenFilePublisher)
      .map(lcrsProcessor::transformToTokenFile);

    logTokenStatus(rxToken);
    processToken(rxToken);
  }

  private void logTokenStatus(final Flowable<LcrsToken> rxToken) {
    rxToken
      .observeOn(Schedulers.computation())
      .subscribe(lcrsLogger::logTokenStatus);
  }

  private void processToken(final Flowable<LcrsToken> rxToken) {
    rxToken
      .filter(LcrsToken::cacheIfAbsent)
      .parallel()
      .runOn(Schedulers.computation())
      .flatMap(this::rxProcessToken)
      .flatMap(this::rxProcessCsv)
      .map(lcrsProcessor::processFinally)
      .sequential()
      .subscribe(model -> log.info("FINALLY - {}", model));
  }

  private Flowable<LcrsModel> rxProcessToken(final LcrsToken token) {
    final LcrsRetryDelay retryDelayHandler = new LcrsRetryDelay(maxRetries, retryDelay);

    return Flowable
      .fromCallable(() -> lcrsProcessor.transformToLcrsModel(token, retryDelayHandler.retryCount()))
      .retryWhen(retryDelayHandler::apply)
      .doOnError(throwable ->
        log.error("ERROR Transform token to LcrsModel with [retryCount={}]", retryDelayHandler.retryCount(), throwable)
      )
      .onErrorReturn(throwable -> LcrsModel.invalid(token, retryDelayHandler.retryCount()));
  }

  private Flowable<LcrsModel> rxProcessCsv(final LcrsModel model) {
    final LcrsRetryDelay retryDelayHandler = new LcrsRetryDelay(maxRetries, retryDelay);

    return Flowable
      .fromCallable(() -> lcrsProcessor.insertCsvData(model, retryDelayHandler.retryCount()))
      .retryWhen(retryDelayHandler::apply)
      .doOnError(throwable ->
        log.error("ERROR Insert CSV data with [retryCount={}]", retryDelayHandler.retryCount(), throwable)
      )
      .onErrorReturn(throwable -> model.invalid(retryDelayHandler.retryCount()));
  }

}
