package io.i101.camel.lcrs.service;

import io.reactivex.Flowable;
import lombok.Getter;

import java.util.concurrent.TimeUnit;
import java.util.function.Function;

public class LcrsRetryDelay implements Function<Flowable<? extends Throwable>, Flowable<?>> {
  private final int maxRetries;
  private final int retryDelay;

  @Getter
  private int retryCount;

  public LcrsRetryDelay(final int maxRetries, final int retryDelay) {
    this.maxRetries = maxRetries > 0 ? maxRetries : 0;
    this.retryDelay = retryDelay > 0 ? retryDelay : 0;
    this.retryCount = 0;
  }

  @Override
  public Flowable<?> apply(final Flowable<? extends Throwable> retries) {
    return retries.flatMap(throwable -> {
      if (retryCount < maxRetries) {
        retryCount = retryCount + 1;
        return Flowable.timer(retryDelay, TimeUnit.SECONDS);
      } else {
        return Flowable.error(throwable);
      }
    });
  }
}
