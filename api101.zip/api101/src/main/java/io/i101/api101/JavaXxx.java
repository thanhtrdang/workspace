package io.i101.api101;

import lombok.Value;

@Value
public class JavaXxx {
    String name;
}
