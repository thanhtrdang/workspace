package io.i101.spring;

import lombok.Data;

@Data
public class JavaXxx {
    private String name;
}
