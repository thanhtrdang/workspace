package io.i101.spring.model

import org.springframework.data.annotation.CreatedBy
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.annotation.LastModifiedBy
import org.springframework.data.annotation.LastModifiedDate
import java.time.Instant

data class AuditMetadata(
    @CreatedBy val createdBy: String,
    @CreatedDate val createdAt: Instant,
    @LastModifiedBy val updatedBy: String,
    @LastModifiedDate val updatedAt: Instant
) {
    companion object {
        fun createdBy(user: String): AuditMetadata = AuditMetadata(
            user, Instant.now(), user, Instant.now()
        )
    }

    fun updatedBy(user: String): AuditMetadata = copy(updatedBy = user, updatedAt = Instant.now())
}
