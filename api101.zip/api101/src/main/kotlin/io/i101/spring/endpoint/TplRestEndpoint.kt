package io.i101.spring.endpoint

import io.i101.spring.model.AuditMetadata
import io.i101.spring.model.QTplModel
import io.i101.spring.model.TplModel
import io.i101.spring.repository.TplRepository
import io.i101.spring.service.TplService
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RestController
import reactor.core.publisher.Flux
import kotlin.random.Random.Default.nextInt

@RestController
class TplRestEndpoint(private val tplService: TplService, private val tplRepository: TplRepository) {
    @GetMapping("/tpl0")
    fun find0(): Flux<TplModel> {
        val TPL = QTplModel.tplModel

        val id = TPL.id.ne("62f34c4adea5d57705a8e8b5")
        val name = TPL.name.likeIgnoreCase("xxx")

        val sortByFileId = Comparator<TplModel> { tpl1, tpl2 -> tpl1.fileId.compareTo(tpl2.fileId) }
            .reversed()

        return tplRepository
            .findAll(id.and(name))
            .sort(sortByFileId)
            .skip(0)
            .take(5)
    }

    @GetMapping("/tpl1")
    suspend fun find1(): String {
        val name = tplService.validateName("  XXX ")

        return name.toString()
    }

    @PostMapping("/tpl0")
    suspend fun store(): TplModel? {
        val tpl = TplModel(
            name = "xxx",
            fileId = "fId-${nextInt(5, 100)}",
            audit = AuditMetadata.createdBy("thanh")
        )

        return tplService.store(tpl)
    }
}
