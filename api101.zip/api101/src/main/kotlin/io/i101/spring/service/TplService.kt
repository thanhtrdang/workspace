package io.i101.spring.service

import arrow.core.*
import arrow.core.continuations.either
import io.i101.spring.model.AuditMetadata
import io.i101.spring.model.TplModel
import io.i101.spring.model.ValidationError
import io.i101.spring.repository.TplRepository
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.firstOrNull
import org.springframework.stereotype.Service

@Service
class TplService(private val tplRepository: TplRepository) {
    fun validate(tpl: TplModel): ValidatedNel<Map<String, List<String>>, TplModel> {
        val nameValidated = Either
            .conditionally(
                tpl.name.isNotBlank(),
                { ValidationError("Name", "Name is required.", tpl.name) },
                { tpl.name.trim() }
            )
            .flatMap { name -> Either.Right(name) }
            .toValidatedNel()

        val fileIdValidated = Either
            .conditionally(
                tpl.fileId.trim().isNotEmpty(),
                { ValidationError("FileId", "FileId is required.", tpl.fileId) },
                { tpl.fileId.trim() }
            )
            .toValidatedNel()


        nameValidated
            .zip(fileIdValidated) { name, fileId ->
                TplModel(
                    name = name, fileId = fileId,
                    audit = AuditMetadata.createdBy("thanh")
                )
            }

        TODO()
    }

    suspend fun store(tpl: TplModel): TplModel? {
        return tplRepository.save(tpl)
    }

    suspend fun validateName(name: String): ValidatedNel<ValidationError<String>, String> {
        val nameOrError = either {
            val requiredName = validateRequiredName(name).bind()
            val uniqueName = validateUniqueName(requiredName).bind()

            uniqueName
        }

        return ValidatedNel.fromEither(nameOrError)
    }

    fun validateRequiredName(name: String): ValidatedNel<ValidationError<String>, String> =
        when (name.isNotBlank()) {
            true -> ValidatedNel.validNel(name.trim())
            else -> ValidatedNel.invalidNel(ValidationError("Name", "Name is required.", name))
        }

    suspend fun validateUniqueName(name: String, id: String = ""): ValidatedNel<ValidationError<String>, String> {
        val existed = tplRepository
            .findByNameIgnoreCase(name)
            .filter { it.id != id }
            .firstOrNull()
            .toOption()

        return when (existed.isEmpty()) {
            true -> ValidatedNel.validNel(name)
            else -> ValidatedNel.invalidNel(ValidationError("Name", "Name is existed.", name))
        }
    }

}
