package io.i101.spring.config

import io.swagger.v3.oas.models.OpenAPI
import io.swagger.v3.oas.models.info.Info
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration

@Configuration
class SpringDocConfig {
    @Bean
    fun openAPI(@Value("\${springdoc.version}") appVersion: String): OpenAPI {
        val info = Info().version(appVersion)

        return OpenAPI().info(info)
    }
}
