package io.i101.spring.endpoint

import io.i101.spring.JavaXxx
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController
import java.time.Instant
import kotlin.system.measureTimeMillis

@RestController
class IndexRestEndpoint {
    @GetMapping("/index0")
    fun index0(): String {
        val time = measureTimeMillis {
//            val s: Sequence<Int> = sequence {
//                for (i in 1..3) {
//                    Thread.sleep(100) // pretend we are computing it
//                    yield(i) // yield next value
//                }
//            }

            val f: Flow<Int> = flow {
                for (i in 1..3) {
                    delay(100) // pretend we are doing something useful here
                    emit(i) // emit next value
                }
            }
        }

        println("Time: $time ms.")

        return Instant.now().toString()
    }

    @GetMapping("/index1")
    suspend fun index1(): String {
//        delay(1000)

        val javaXxx = JavaXxx()
        javaXxx.name = "Dummy Java name"

        println("Use Java in Kotlin: $javaXxx")

        return Instant.now().toString()
    }
}
