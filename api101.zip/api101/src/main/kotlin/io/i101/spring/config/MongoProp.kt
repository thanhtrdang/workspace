package io.i101.spring.config

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.boot.context.properties.ConstructorBinding
import org.springframework.context.annotation.DependsOn

@ConstructorBinding
@DependsOn(MongoProp.MONGO_DEV_SERVER_BEAN)
@ConfigurationProperties("spring.data.mongodb")
data class MongoProp(val uri: String, val database: String) {
    companion object {
        const val MONGO_DEV_SERVER_BEAN = "mongo-dev-server"
    }
}
