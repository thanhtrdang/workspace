package io.i101.spring.repository

import io.i101.spring.model.DocModel
import org.springframework.data.querydsl.ReactiveQuerydslPredicateExecutor
import org.springframework.data.repository.kotlin.CoroutineSortingRepository
import org.springframework.stereotype.Repository

@Repository
interface DocRepository : CoroutineSortingRepository<DocModel, String>, ReactiveQuerydslPredicateExecutor<DocModel> {
}
