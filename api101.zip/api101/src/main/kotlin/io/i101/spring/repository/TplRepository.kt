package io.i101.spring.repository

import io.i101.spring.model.TplModel
import kotlinx.coroutines.flow.Flow
import org.springframework.data.querydsl.ReactiveQuerydslPredicateExecutor
import org.springframework.data.repository.kotlin.CoroutineSortingRepository
import org.springframework.stereotype.Repository

@Repository
interface TplRepository : CoroutineSortingRepository<TplModel, String>, ReactiveQuerydslPredicateExecutor<TplModel> {
    fun findByNameIgnoreCase(name: String): Flow<TplModel>
}
