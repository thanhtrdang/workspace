package io.i101.spring.model

data class ValidationError<T>(val path: String, val error: String, val value: T)
