package io.i101.spring.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document

@Document
data class DocModel(
    @Id val id: String? = null,
    val tplId: String,
    val fileId: String,
    val audit: AuditMetadata
)
