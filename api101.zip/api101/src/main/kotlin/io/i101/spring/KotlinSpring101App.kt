package io.i101.spring

import io.i101.spring.config.MongoProp
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.context.annotation.Bean

@SpringBootApplication
class KotlinSpring101App {
    @Bean(MongoProp.MONGO_DEV_SERVER_BEAN)
    fun dummyMongoDevServer() = Any()
}

fun main(args: Array<String>) {
    runApplication<KotlinSpring101App>(*args)
}
