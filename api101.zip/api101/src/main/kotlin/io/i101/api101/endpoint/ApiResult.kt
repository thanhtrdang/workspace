package io.i101.api101.endpoint

import com.fasterxml.jackson.annotation.JsonInclude
import com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL
import org.springframework.http.HttpStatus
import java.time.LocalDateTime

data class ApiResult<T>(
    val timestamp: LocalDateTime = LocalDateTime.now(),
    val code: String, // same as `status` by default.
    val message: String,
//    val error: String,
//    val status: Int,
//    val path: String,
//    val requestId: String,
//    --- Spring-Boot's properties ---

    val isOk: Boolean,
    @JsonInclude(NON_NULL)
    val data: T? = null
) {
    companion object {
        fun <T> ok(message: String = HttpStatus.OK.reasonPhrase, data: T? = null): ApiResult<T> = ApiResult(
            code = "${HttpStatus.OK.value()}",
            message = message,
            isOk = true,
            data = data
        )

        fun <T> nok4xx(
            code: String = "${HttpStatus.BAD_REQUEST.value()}",
            message: String,
            data: T? = null
        ): ApiResult<T> = ApiResult(
            code = code,
            message = message,
            isOk = false,
            data = data
        )

        fun <T> nok5xx(
            code: String = "${HttpStatus.INTERNAL_SERVER_ERROR.value()}",
            message: String,
            data: T? = null
        ): ApiResult<T> = ApiResult(
            code = code,
            message = message,
            isOk = false,
            data = data
        )
    }
}
