package io.i101.api101.model

import org.springframework.http.MediaType
import org.springframework.http.MediaType.*

enum class FileType(val contentType: String) {
    PDF(APPLICATION_PDF_VALUE),
    PNG(IMAGE_PNG_VALUE),
    JPEG(IMAGE_JPEG_VALUE);

    companion object {
        val DEFAULT = MediaType.APPLICATION_OCTET_STREAM

        fun all(delimiter: String = " / "): String = FILE_TYPES.keys.joinToString(delimiter) { it.lowercase() }

        fun isSupported(contentType: String): Boolean = FILE_TYPES.containsValue(contentType)

        fun isUnsupported(contentType: String): Boolean = !FileType.isSupported(contentType)
    }
}

private val FILE_TYPES = FileType.values().associate { it.name to it.contentType }
