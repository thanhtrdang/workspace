package io.i101.api101.endpoint

import arrow.core.Either
import io.i101.api101.lib.JwtUtil
import org.springframework.security.core.Authentication
import org.springframework.security.core.GrantedAuthority
import org.springframework.security.core.annotation.AuthenticationPrincipal
import org.springframework.security.core.authority.SimpleGrantedAuthority
import org.springframework.security.core.userdetails.UserDetails
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RestController

@RestController
class LoginEndpoint(private val jwtUtil: JwtUtil) {
    @PostMapping("/login")
    fun login(@RequestBody login: LoginRequest): String? = Either
        .conditionally(
            login.username.isNotBlank() && login.password.isNotBlank(),
            { null },
            { jwtUtil.generateToken(User(login.username, login.password, listOf(Group.USER))) }
        )
        .orNull()

// @AuthenticationPrincipal auth: Mono<Authentication>
// ServerRequest.principal()
// ReactiveSecurityContextHolder.getContext()

    @GetMapping("/profile")
    fun profile(@AuthenticationPrincipal auth: Authentication): Map<String, Any> = mapOf(
        "username" to auth.principal,
        "groups" to auth.authorities.map { it.authority }
    )
}

enum class Group {
    USER, ADMIN;
}

data class User(
    private val _username: String,
    private val _password: String,
    private val _groups: List<Group> = listOf(),
    private val _enabled: Boolean = true
) :
    UserDetails {
    override fun getAuthorities(): List<GrantedAuthority> {
        return _groups.map { SimpleGrantedAuthority(it.name) }
    }

    override fun getPassword(): String {
        return _password
    }

    override fun getUsername(): String {
        return _username
    }

    override fun isAccountNonExpired(): Boolean {
        return false
    }

    override fun isAccountNonLocked(): Boolean {
        return false
    }

    override fun isCredentialsNonExpired(): Boolean {
        return false
    }

    override fun isEnabled(): Boolean {
        return _enabled
    }

}

data class LoginRequest(val username: String, val password: String)