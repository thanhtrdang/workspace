package io.i101.api101.model

data class FileMetadata(
    val checksum: String,
    val contentLength: Long,
    val refId: String? = null,
    val url: String? = null,
    val createdBy: String = "Unknown"
)
