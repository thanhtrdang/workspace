package io.i101.api101.repository

import arrow.core.Option
import arrow.core.getOrElse
import com.mongodb.client.gridfs.model.GridFSFile
import io.i101.api101.model.FileDownload
import io.i101.api101.model.FileMetadata
import io.i101.api101.model.FileType
import org.bson.types.ObjectId
import org.springframework.data.mongodb.core.query.Criteria.where
import org.springframework.data.mongodb.core.query.Query.query
import org.springframework.data.mongodb.core.query.isEqualTo
import org.springframework.data.mongodb.gridfs.ReactiveGridFsTemplate
import org.springframework.http.ContentDisposition
import org.springframework.http.MediaType
import org.springframework.http.codec.multipart.FilePart
import org.springframework.stereotype.Component
import reactor.core.publisher.Mono

@Component
class FileRepository(private val gridFsTemplate: ReactiveGridFsTemplate) {
    fun find(fileId: String): Mono<GridFSFile> =
        gridFsTemplate.findOne(query(where("_id").isEqualTo(fileId)))


    fun download(fileId: String): Mono<FileDownload> = find(fileId)
        .flatMap { file ->
            gridFsTemplate
                .getResource(file)
                .map { resource ->
                    val contentType = Option
                        .fromNullable(file.metadata?.getString("_contentType"))// GridFsResource.CONTENT_TYPE_FIELD
                        .flatMap { contentType ->
                            Option.catch { MediaType.parseMediaType(contentType) }
                        }
                        .getOrElse { FileType.DEFAULT }

                    val contentDisposition = ContentDisposition
                        .attachment()
                        .filename(resource.filename)
                        .build()

                    FileDownload(contentType, contentDisposition, resource.downloadStream)
                }
        }


    fun upload(filePartRx: Mono<FilePart>, metadataRx: Mono<FileMetadata>): Mono<String> = Mono
        .zip(filePartRx, metadataRx)
        .flatMap {
            val filePart = it.t1
            val metadata = it.t2
            val contentType = filePart.headers().contentType?.toString()

            gridFsTemplate
                .store(
                    filePart.content(),
                    filePart.filename(),
                    contentType,
                    metadata
                )
                .map(ObjectId::toHexString)
        }

}

// files are equal if
// (file name, file size) | checksum
