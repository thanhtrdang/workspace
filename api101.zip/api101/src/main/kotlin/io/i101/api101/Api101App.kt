package io.i101.api101

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Api101App

fun main(args: Array<String>) {
    runApplication<Api101App>(*args)
}
