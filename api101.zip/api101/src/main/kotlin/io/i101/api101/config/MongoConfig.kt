package io.i101.api101.config

import com.mongodb.reactivestreams.client.MongoClient
import com.mongodb.reactivestreams.client.MongoClients
import io.i101.api101.repository.Api101Repository
import mu.KotlinLogging
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.DependsOn
import org.springframework.data.mongodb.ReactiveMongoDatabaseFactory
import org.springframework.data.mongodb.config.AbstractReactiveMongoConfiguration
import org.springframework.data.mongodb.core.convert.DefaultMongoTypeMapper
import org.springframework.data.mongodb.core.convert.MappingMongoConverter
import org.springframework.data.mongodb.core.convert.MongoConverter
import org.springframework.data.mongodb.core.convert.MongoCustomConversions
import org.springframework.data.mongodb.core.mapping.MongoMappingContext
import org.springframework.data.mongodb.gridfs.ReactiveGridFsTemplate
import org.springframework.data.mongodb.repository.config.EnableReactiveMongoRepositories

private val logger = KotlinLogging.logger {}

@Configuration
@DependsOn(MongoProp.MONGO_DEV_SERVER_BEAN)
//@EnableReactiveMongoAuditing
@EnableConfigurationProperties(value = [MongoProp::class])
@EnableReactiveMongoRepositories(basePackageClasses = [Api101Repository::class])
class MongoConfig(private val mongoProp: MongoProp, private val api101Prop: Api101Prop) : AbstractReactiveMongoConfiguration() {
    init {
        logger.info { "$mongoProp" }
    }

    override fun getDatabaseName(): String {
        return mongoProp.database
    }

    override fun reactiveMongoClient(): MongoClient {
        return MongoClients.create(mongoProp.uri)
    }

    override fun mappingMongoConverter(
        databaseFactory: ReactiveMongoDatabaseFactory,
        customConversions: MongoCustomConversions,
        mappingContext: MongoMappingContext
    ): MappingMongoConverter = super
        .mappingMongoConverter(databaseFactory, customConversions, mappingContext)
        .apply {
            setTypeMapper(DefaultMongoTypeMapper(null))
        }


    @Bean
    fun gridFsTemplate(
        databaseFactory: ReactiveMongoDatabaseFactory, mappingConverter: MongoConverter
    ): ReactiveGridFsTemplate = ReactiveGridFsTemplate(databaseFactory, mappingConverter, api101Prop.gridfsBucket)

}