package io.i101.api101.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document

@Document("api101_collection_name")
data class Api101Model(
    @Id val id: String? = null,
    val name: String,
    val fileId: String,
    val audit: AuditMetadata
)
