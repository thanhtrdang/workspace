package io.i101.api101.config

import arrow.integrations.jackson.module.registerArrowModule
import com.fasterxml.jackson.databind.ObjectMapper
import io.swagger.v3.oas.models.OpenAPI
import io.swagger.v3.oas.models.info.Info
import mu.KotlinLogging
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration


private val logger = KotlinLogging.logger {}

@Configuration
@EnableConfigurationProperties(value = [Api101Prop::class])
class Api101Config(private val api101Prop: Api101Prop, jsonMapper: ObjectMapper) {
    init {
        logger.info { "$api101Prop" }

        jsonMapper.registerArrowModule()
    }

    @Bean
    fun openAPI(@Value("\${springdoc.version}") appVersion: String): OpenAPI {
        val info = Info()
            .version(appVersion)
            .title("API101")

        return OpenAPI().info(info)
    }

    @Bean(MongoProp.MONGO_DEV_SERVER_BEAN)
    fun dummyMongoDevServer() = Any()

}
