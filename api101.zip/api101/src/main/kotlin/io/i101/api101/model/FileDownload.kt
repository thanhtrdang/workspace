package io.i101.api101.model

import org.springframework.core.io.buffer.DataBuffer
import org.springframework.http.ContentDisposition
import org.springframework.http.MediaType
import reactor.core.publisher.Flux

data class FileDownload(
    val contentType: MediaType,
    val contentDisposition: ContentDisposition,
    val rawDataRx: Flux<DataBuffer>
)
