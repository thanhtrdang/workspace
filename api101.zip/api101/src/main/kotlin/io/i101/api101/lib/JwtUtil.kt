package io.i101.api101.lib

import arrow.core.Either
import io.i101.api101.config.Api101Prop
import io.i101.api101.endpoint.User
import io.jsonwebtoken.Claims
import io.jsonwebtoken.JwtParser
import io.jsonwebtoken.Jwts
import io.jsonwebtoken.security.Keys
import org.springframework.stereotype.Component
import java.security.Key
import java.util.*

private const val CLAIM_KEY_GROUPS = "groups"

@Component
class JwtUtil(private val api101Prop: Api101Prop) {
    private val signingKey: Key
    private val jwtParser: JwtParser

    init {
        signingKey = Keys.hmacShaKeyFor(api101Prop.jjwtSigningKey.toByteArray())
        jwtParser = Jwts
            .parserBuilder()
            .setSigningKey(signingKey)
            .build()
    }

    fun parseToken(token: String): Either<Throwable, Claims> = Either
        .catch {
            jwtParser.parseClaimsJws(token).body
        }

    fun generateToken(user: User): String {
        val createdDate = Date()
        val expirationDate = Date(createdDate.time + api101Prop.jjwtExpiration)

        return Jwts
            .builder()
            .claim(CLAIM_KEY_GROUPS, user.authorities.map { it.authority })
            .setSubject(user.username)
            .setIssuedAt(createdDate)
            .setExpiration(expirationDate)
            .signWith(signingKey)
            .compact()
    }

    companion object {
        fun getClaimGroups(claims: Claims): List<String> = claims
            .get(CLAIM_KEY_GROUPS, List::class.java)
            .map { group -> group as String }
    }
}
