package io.i101.api101.service

import io.i101.api101.repository.Api101Repository
import mu.KotlinLogging
import org.springframework.stereotype.Service

private val logger = KotlinLogging.logger {}

@Service
class Api101Service(private val api101Repository: Api101Repository) {

}
