package io.i101.api101.config

import io.i101.api101.lib.JwtUtil
import io.jsonwebtoken.Claims
import org.springframework.context.annotation.Bean
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.security.authentication.ReactiveAuthenticationManager
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity
import org.springframework.security.config.web.server.ServerHttpSecurity
import org.springframework.security.config.web.server.invoke
import org.springframework.security.core.Authentication
import org.springframework.security.core.GrantedAuthority
import org.springframework.security.core.authority.SimpleGrantedAuthority
import org.springframework.security.core.context.SecurityContext
import org.springframework.security.core.context.SecurityContextImpl
import org.springframework.security.web.server.SecurityWebFilterChain
import org.springframework.security.web.server.context.ServerSecurityContextRepository
import org.springframework.security.web.server.util.matcher.ServerWebExchangeMatchers.pathMatchers
import org.springframework.stereotype.Component
import org.springframework.web.server.ServerWebExchange
import reactor.core.publisher.Mono
import java.util.*

private const val BEARER_TOKEN_PREFIX = "Bearer "

@EnableWebFluxSecurity
class AuthConfig(
    private val securityContextRepository: SecurityContextRepository,
    private val authenticationManager: IdentityAuthenticationManager
) {
    @Bean
    fun securityWebFilterChain(httpSecurity: ServerHttpSecurity): SecurityWebFilterChain {
        httpSecurity
            .authenticationManager(authenticationManager)
            .securityContextRepository(securityContextRepository)

        return httpSecurity {
            authenticationManager
            authorizeExchange {
                authorize(pathMatchers(HttpMethod.OPTIONS, "/**"), permitAll)
                authorize("/login", permitAll)
                authorize("/api-docs/**", permitAll)
                authorize("/webjars/**", permitAll)
                authorize(anyExchange, authenticated)
            }
            csrf { disable() }
            cors { disable() }
            formLogin { disable() }
            httpBasic { disable() }
        }
    }
}

@Component
class IdentityAuthenticationManager : ReactiveAuthenticationManager {
    override fun authenticate(authentication: Authentication): Mono<Authentication> {
        return Mono.justOrEmpty(authentication)
    }
}

@Component
class SecurityContextRepository(private val jwtUtil: JwtUtil) : ServerSecurityContextRepository {
    override fun save(exchange: ServerWebExchange, context: SecurityContext): Mono<Void> {
        throw UnsupportedOperationException("Not supported yet.")
    }

    override fun load(exchange: ServerWebExchange): Mono<SecurityContext> {
        return Mono
            .justOrEmpty(exchange.request.headers.getFirst(HttpHeaders.AUTHORIZATION))
            .filter {
                it.startsWith(BEARER_TOKEN_PREFIX)
            }
            .map {
                it.substring(BEARER_TOKEN_PREFIX.length).trim()
            }
            .flatMap { bearerToken ->
                jwtUtil
                    .parseToken(bearerToken)
                    .fold(
                        { error -> Mono.error(error) },
                        { claims -> Mono.just(SecurityContextImpl(BearerTokenAuthentication(claims))) }
                    )
            }
    }
}

private data class BearerTokenAuthentication(private val claims: Claims) : Authentication {
    override fun getName(): String {
        return claims.subject
    }

    override fun getAuthorities(): List<GrantedAuthority> {
        return JwtUtil
            .getClaimGroups(claims)
            .map { group -> SimpleGrantedAuthority(group) }
    }

    override fun getCredentials(): Any {
        TODO("Not yet implemented")
    }

    override fun getDetails(): Any {
        TODO("Not yet implemented")
    }

    override fun getPrincipal(): String {
        return claims.subject
    }

    override fun isAuthenticated(): Boolean {
        return isTokenExpired()
    }

    override fun setAuthenticated(isAuthenticated: Boolean) {
        throw UnsupportedOperationException("Immutable and unsupported.")
    }

    private fun isTokenExpired(): Boolean = claims.expiration.after(Date())
}
