package io.i101.api101.endpoint

import io.i101.api101.model.FileMetadata
import io.i101.api101.repository.FileRepository
import mu.KotlinLogging
import org.springframework.core.io.buffer.DataBuffer
import org.springframework.core.io.buffer.DataBufferUtils
import org.springframework.http.HttpHeaders
import org.springframework.http.codec.multipart.FilePart
import org.springframework.http.server.reactive.ServerHttpResponse
import org.springframework.util.DigestUtils
import org.springframework.web.bind.annotation.*
import reactor.core.publisher.Mono
import reactor.kotlin.core.publisher.toMono

private val logger = KotlinLogging.logger {}

@RestController
@RequestMapping("/file")
class FileEndpoint(private val fileRepository: FileRepository) {
    @GetMapping("/{fileId}")
    fun downloadFile(@PathVariable fileId: String, response: ServerHttpResponse): Mono<Void> {
        return fileRepository
            .download(fileId)
            .flatMap { fileDownload ->
                response.headers.also { headers ->
                    headers.contentType = fileDownload.contentType
                    headers.contentDisposition = fileDownload.contentDisposition
                }
                response.writeWith(fileDownload.rawDataRx)
            }
    }

    @PostMapping
    fun uploadFile(
        @RequestPart("file") filePartRx: Mono<FilePart>,
        @RequestHeader(HttpHeaders.CONTENT_LENGTH) contentLength: Long
    ): Mono<String> {
        val fileMetadataRx = filePartRx
            .flatMap { filePart ->
                filePart
                    .content()
                    .transform(DataBufferUtils::join)
                    .toMono()
                    .map(DataBuffer::asInputStream)
            }
            .map { fileStream ->
                FileMetadata(
                    checksum = DigestUtils.md5DigestAsHex(fileStream),
                    contentLength = contentLength
                )
            }

        return fileRepository.upload(filePartRx, fileMetadataRx)
    }
}
