package io.i101.api101.endpoint

import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController

@RestController
class IndexEndpoint {
    @GetMapping("/")
    fun index(): ApiResult<Any> = ApiResult.ok()
}
