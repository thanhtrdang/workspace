package io.i101.api101.repository

import io.i101.api101.model.Api101Model
import kotlinx.coroutines.flow.Flow
import org.springframework.data.querydsl.ReactiveQuerydslPredicateExecutor
import org.springframework.data.repository.kotlin.CoroutineSortingRepository
import org.springframework.stereotype.Repository

@Repository
interface Api101Repository :
    CoroutineSortingRepository<Api101Model, String>, ReactiveQuerydslPredicateExecutor<Api101Model> {

    fun findByNameIgnoreCase(name: String): Flow<Api101Model>
}
