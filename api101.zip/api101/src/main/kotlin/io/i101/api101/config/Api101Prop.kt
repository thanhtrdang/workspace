package io.i101.api101.config

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.boot.context.properties.ConstructorBinding

@ConstructorBinding
@ConfigurationProperties("api101")
data class Api101Prop(
    val supportContact: String,
    val gridfsBucket: String,
    val jjwtSigningKey: String,
    val jjwtExpiration: Long
)
