package io.i101.api101.config

import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.context.annotation.ComponentScan
import org.springframework.test.context.ActiveProfiles

@ActiveProfiles("dev")
@EnableAutoConfiguration
@ComponentScan("io.i101.api101")
@SpringBootTest(classes = [MongoTestConfig::class, MongoConfig::class])
annotation class EnableTestConfig()
