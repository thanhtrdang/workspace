package io.i101.api101.endpoint

import io.i101.api101.config.EnableTestConfig
import org.junit.jupiter.api.DisplayName
import org.junit.jupiter.api.Test
import org.springframework.context.ApplicationContext
import org.springframework.test.web.reactive.server.WebTestClient

@EnableTestConfig
class IndexEndpointTests(applicationContext: ApplicationContext) {
    private val webTestClient = WebTestClient
        .bindToApplicationContext(applicationContext)
        .build()

    @Test
    @DisplayName("GET /")
    fun testIndex() {
        webTestClient
            .get().uri("/")
            .exchange()
            .expectStatus().isOk
            .expectBody().jsonPath(ApiResult<Any>::isOk.name).isEqualTo(true)
    }

    @Test
    @DisplayName("GET /alive")
    fun testAlive() {
        webTestClient
            .get().uri("/alive")
            .exchange()
            .expectStatus().isOk
    }
}
