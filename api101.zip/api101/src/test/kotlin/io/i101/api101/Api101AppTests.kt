package io.i101.api101

import io.i101.api101.config.EnableTestConfig
import org.junit.jupiter.api.Test

@EnableTestConfig
class Api101AppTests {

    @Test
    fun contextLoads() {
    }

}
