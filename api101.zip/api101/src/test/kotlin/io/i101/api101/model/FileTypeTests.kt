package io.i101.api101.model

import org.junit.jupiter.api.Test
import org.springframework.http.MediaType

class FileTypeTests {
    @Test
    fun testSupported() {
        assert(FileType.isSupported(MediaType.APPLICATION_PDF_VALUE))
        assert(FileType.isUnsupported(MediaType.APPLICATION_OCTET_STREAM_VALUE))
    }

    @Test
    fun testAll() {
        assert("pdf / png / jpeg" == FileType.all())
    }
}
