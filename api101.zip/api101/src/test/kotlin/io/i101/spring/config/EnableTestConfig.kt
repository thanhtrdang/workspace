package io.i101.spring.config

import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.context.annotation.ComponentScan
import org.springframework.test.context.ActiveProfiles

@ActiveProfiles("test")
@EnableAutoConfiguration
@ComponentScan("io.i101.spring")
@SpringBootTest(classes = [MongoTestConfig::class, MongoConfig::class])
annotation class EnableTestConfig()
