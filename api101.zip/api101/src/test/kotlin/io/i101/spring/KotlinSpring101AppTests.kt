package io.i101.spring

import io.i101.spring.config.EnableTestConfig
import org.junit.jupiter.api.Test

@EnableTestConfig
class KotlinSpring101AppTests {
    @Test
    fun contextLoads() {
        println("DONE.")

    }

}
