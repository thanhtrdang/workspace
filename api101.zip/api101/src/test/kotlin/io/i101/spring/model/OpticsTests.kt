package io.i101.spring.model

import arrow.optics.Optional
import arrow.optics.every
import arrow.optics.lens
import arrow.optics.optics
import org.junit.jupiter.api.Test

class OpticsTests {
    @Test
    fun test0() {
        val p = Person("me", listOf("pat", "mat"))
        val m = Person::name.lens.modify(p) { it.capitalize() }
        val fs = Person::friends.every.modify(p) { it.capitalize() }

        assert(m.name == p.name.capitalize())
//        assert(fs.friends == p.friends)
    }

    @Test
    fun test1() {
        val john = Employee(
            "John Doe",
            Company(
                "Kategory",
                Address(
                    "Functional city",
                    Street(42, "lambda street")
                )
            )
        )

        val optional: Optional<Employee, String> = Employee.company.address.street.name
        val eJohn = optional.modify(john, String::toUpperCase)

        assert(eJohn.company?.address?.street?.name == john.company?.address?.street?.name?.toUpperCase())
    }
}

data class Person(val name: String, val friends: List<String>)

@optics
data class Street(val number: Int, val name: String) {
    companion object
}

@optics
data class Address(val city: String, val street: Street) {
    companion object
}

@optics
data class Company(val name: String, val address: Address) {
    companion object
}

@optics
data class Employee(val name: String, val company: Company?) {
    companion object
}