package io.i101.spring.model

//import arrow.core.Valid
//import arrow.core.ValidatedNel
//import arrow.core.invalidNel
import io.i101.spring.config.EnableTestConfig
import org.junit.jupiter.api.Test

@EnableTestConfig
class ValidatedTests {
    @Test
    fun test0() {
//        val x = Organizer.create("  ")

        println("DONE.")

    }
}

//inline class Organizer(val value: String) {
//    companion object {
//        fun create(value: String): ValidatedNel<String, Organizer> = when {
//            value.isEmpty() -> "Organizer cannot be empty".invalidNel()
//            value.isBlank() -> "Organizer cannot be blank".invalidNel()
//            else -> Valid(Organizer(value))
//        }
//    }
//}
