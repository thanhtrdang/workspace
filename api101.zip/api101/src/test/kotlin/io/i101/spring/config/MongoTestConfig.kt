package io.i101.spring.config

import de.bwaldvogel.mongo.MongoServer
import de.bwaldvogel.mongo.backend.memory.MemoryBackend
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Primary

@Configuration
class MongoTestConfig(@Value("\${spring.data.mongodb.port}") val mongoPort: Int) {
    @Primary
    @Bean(name = [MongoProp.MONGO_DEV_SERVER_BEAN], destroyMethod = "shutdown")
    fun mongoServer(): MongoServer = MongoServer(MemoryBackend())
        .apply {
            bind("localhost", mongoPort)
        }
}
