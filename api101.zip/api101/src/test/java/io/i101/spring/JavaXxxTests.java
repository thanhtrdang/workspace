package io.i101.spring;

import lombok.val;
import org.junit.jupiter.api.Test;

public class JavaXxxTests {
    @Test
    public void test0() {
        val xxx = new JavaXxx();
        xxx.setName("XXX");

        assert xxx.getName().equals("XXX");
    }
}
