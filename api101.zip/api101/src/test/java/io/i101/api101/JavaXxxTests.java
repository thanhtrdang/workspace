package io.i101.api101;

import lombok.val;
import org.junit.jupiter.api.Test;

public class JavaXxxTests {
    @Test
    public void testXxx() {
        val xxx = new JavaXxx("XXX");

        assert xxx.getName().equals("XXX");
    }
}
