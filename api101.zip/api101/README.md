### Setup checklist

- [x] Java / Kotlin / Maven / Spring / MongoDB
- [x] Maven: Lombok
- [x] Maven: MongoDB QueryDSL
- [x] Maven: ksp (https://github.com/dyescape/kotlin-maven-symbol-processing)
- [x] Maven: Arrow optics plugin
- [x] Test: mongo-java-server
- [x] API docs: springdoc
- [x] jasypt: Maven / Spring / IntelliJ VM options (-Djasypt.encryptor.password=secrete-key) 
- [x] Error handling: 4xx / 5xx
- [x] Spring: Endpoint testing
- [ ] Spring: Kafka
- [x] Spring: Security (LDAP / web)
- [x] Directory / file structure
- [x] MongoDB: GridFS find / store / checksum
- [ ] Kotlin: coroutine / flow / arrow-kt
- [ ] ?Cache: https://github.com/ben-manes/caffeine
- [ ] Build / deploy pipeline: Jira / Jenkins / OpenShift
- [ ] Config: Enable / disable features (e.g. Kafka, Security..)

- [x] Local dev: mvnd (https://github.com/apache/maven-mvnd)
- [ ] ?Hot reload: jrebel or `???`

### Helpful commands

```shell
$ mvn clean package -DskipTests
$ mvn spring-boot:run

$ mvn jasypt:encrypt-value -Djasypt.encryptor.password="xyx@abc" -Djasypt.plugin.value=xxx
$ mvn jasypt:decrypt-value -Djasypt.encryptor.password="xyx@abc" -Djasypt.plugin.value="ENC(/uFuxC5yE18YvpB3TiaPfNMpJMlcGMtXPZmGqma5ZnclaPYEofVWLE7g2HVkimOf)"
```
