import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { debounceTime, distinctUntilChanged, map } from 'rxjs';
import { NgxResizeHandleType } from 'ngx-drag-resize';
import { trim } from 'lodash';

import { Rect, MIN_BOX_SIZE } from '../marker.model';

@Component({
  selector: 'xxx-marker-box',
  templateUrl: './marker-box.component.html',
  styleUrls: ['./marker-box.component.scss'],
})
export class MarkerBoxComponent implements OnInit {
  readonly ResizeHandleType = NgxResizeHandleType;
  readonly MinSize = MIN_BOX_SIZE;
  readonly ResizeWheelDisabled = true;

  @Input() boundary: string = '.marker-boundary';

  @Input() rect!: Rect;
  @Output() rectChanged = new EventEmitter<Rect>();

  @Input() set name(value: string) {
    this.nameField.setValue(value);
  }
  nameField = new FormControl('');

  showToolbar: boolean = false;

  constructor() {}

  ngOnInit(): void {
    this.nameField.valueChanges
      .pipe(
        map((name) => trim(name)),
        debounceTime(300),
        distinctUntilChanged()
      )
      .subscribe({
        next: (name) => {
          console.log(`Name: ${name}`);
        },
      });
  }

  onMarkerBoxActive(): void {
    this.showToolbar = true;
  }
  onMarkerBoxInactive(): void {
    this.showToolbar = false;
  }
  onMarkerRemoved(): void {
    console.log('Removed');
  }
}
