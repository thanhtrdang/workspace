export interface Point {
  readonly x: number;
  readonly y: number;
}

export interface Size {
  readonly width: number;
  readonly height: number;
}

export interface Rect {
  readonly origin: Point;
  readonly size: Size;
}

export interface Marker {
  readonly name: string;
  readonly rect: Rect;
}

export interface Canvas {
  readonly id: string;
  readonly markers: Marker[];
}

export interface Template {
  readonly id: string;
  readonly name: string;
  readonly canvases: Canvas[];
}

export const defaultRect = (): Rect => ({
  origin: { x: 100, y: 100 },
  size: minBoxSize(),
});
export const minBoxSize = (): Size => ({ width: 20, height: 20 });
export const minSelectionSize = (): Size => ({ width: 10, height: 10 });

export const DEFAULT_RECT = defaultRect();
export const MIN_BOX_SIZE = minBoxSize();
export const MIN_SELECTION_SIZE = minSelectionSize();
export const START_SELECTION_CENTER =
  Math.min(MIN_SELECTION_SIZE.width, MIN_SELECTION_SIZE.height) / 2;
