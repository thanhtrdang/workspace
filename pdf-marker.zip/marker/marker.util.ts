import { MIN_SELECTION_SIZE, Point, Size } from './marker.model';

export const isCanvasEvent = (event: MouseEvent, canvasId: string): boolean => {
  const target = event.target as HTMLElement;

  return target.id === canvasId;
};

export const isSelectionBigEnough = (
  startPoint: Point,
  endPoint: Point,
  delta: Size = MIN_SELECTION_SIZE
): boolean => {
  return (
    Math.abs(startPoint.x - endPoint.x) > delta.width &&
    Math.abs(startPoint.y - endPoint.y) > delta.height
  );
};
