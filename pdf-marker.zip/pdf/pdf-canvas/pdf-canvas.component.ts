import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { PDFDocumentProxy } from 'pdfjs-dist';

import { Size } from '@xxx/lib';

@Component({
  selector: 'xxx-pdf-canvas',
  templateUrl: './pdf-canvas.component.html',
  styleUrls: ['./pdf-canvas.component.scss'],
})
export class PdfCanvasComponent implements OnInit {
  @Input() pageNumber!: number;
  @Input() pdf!: PDFDocumentProxy;

  @ViewChild('pdfCanvas') _pdfCanvasRef!: ElementRef<HTMLCanvasElement>;
  size?: Size;

  constructor() {}

  async ngOnInit(): Promise<void> {
    const pdfPage = await this.pdf.getPage(this.pageNumber);

    const zoom = 1;
    const scale = zoom * (96 / 72);

    const viewport = pdfPage.getViewport({ scale: scale });
    // Support HiDPI-screens.
    const outputScale = window.devicePixelRatio || 1;

    this.size = {
      width: Math.floor(viewport.width),
      height: Math.floor(viewport.height),
    };

    const canvas = this._pdfCanvasRef.nativeElement;
    const context = canvas.getContext('2d')!;

    canvas.width = Math.floor(viewport.width * outputScale);
    canvas.height = Math.floor(viewport.height * outputScale);
    canvas.style.width = this.size.width + 'px';
    canvas.style.height = this.size.height + 'px';

    const transform =
      outputScale !== 1 ? [outputScale, 0, 0, outputScale, 0, 0] : undefined;

    const renderContext = {
      canvasContext: context,
      transform: transform,
      viewport: viewport,
    };

    pdfPage.render(renderContext);
  }
}
