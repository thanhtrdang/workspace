#!/usr/bin/env bash

aws s3 sync --acl private --sse --delete ./build s3://goleague-frontend-site-scratch
