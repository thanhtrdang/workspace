# PEPPER.GG Frontend

- Live site: https://alpha.pepper.gg/
- Test site: https://staging.pubgleeg.com/

# REQUIREMENTS

- [NodeJS 10.9.0](https://nodejs.org/en/blog/release/v10.9.0/)
- [Yarn 1.9.4](https://yarnpkg.com/en/)

# SET UP

- Install packages: "yarn"
- Export environment variables
  ```sh
  export REACT_APP_SENTRY_DSN=https://95ac2aceb77447d98174a2aaa5ca6491@sentry.io/1267217
  export REACT_APP_GA_TRACKING_ID=UA-126396576-1
  export REACT_APP_RECAPTCHA_PUBLIC_KEY=6Ldhz2sUAAAAAGLYZTH5VkPhmt9beRJ0Ehg310g1
  export REACT_APP_API_URL=http://localhost:8000
  export SENDGRID_API_KEY=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
  ```
- Run Frontend code (port 3000): "yarn start"
