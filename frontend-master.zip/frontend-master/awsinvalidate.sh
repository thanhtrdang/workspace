#!/usr/bin/env bash
#
# Invalidates the CloudFront distribution associated with the environment.
# Assumes your local machine has the appropriate AWS credentials.
#
set -e

readonly env=${1-staging}
readonly aws_region="us-west-2"

readonly dist_master="NONE"
readonly dist_dev="NONE"
readonly dist_staging="E3QQFKG60KJQCS"
readonly dist_prod="E2KMCIABPWWF8F"

dist_var="dist_$env"
dist="${!dist_var}"

if [ "$dist" != "NONE" ]; then
    echo "<$env> Invalidate CloudFront distribution: ${dist}"
    aws cloudfront create-invalidation --distribution-id "${dist}" --paths '/*'
else
    echo "<$env> No CloudFront distribution to invalidate."
fi
