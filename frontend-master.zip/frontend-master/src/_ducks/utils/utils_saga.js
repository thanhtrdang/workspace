import { delay } from 'redux-saga'
import { put } from 'redux-saga/effects'
import tracker from 'helpers/tracker'
import { history } from 'helpers/configureStore'
import { routes } from 'var'

import { types } from '../alert/alert_reducer'

export const alertMessage = function*(message, delayTime = 1800) {
  yield put({ type: types.SUCCESS, message })
  yield delay(delayTime)
  yield put({ type: types.VANISH })
}

export const handleReduxError = function*({ error, failedAction }) {
  // console.log('%cerror:', 'color:yellow;background:black;font-size:1rem;', error)
  // for (let i in error) {
  //   console.log(i, error[i])
  // }

  const url = error && error.config && error.config.url

  if (failedAction) {
    yield put({
      type: failedAction,
      url,
      status_message: error && error.response && error.response.statusText,
      content: error && error.message,
    })
  }

  return url
}

export const captureError = function*({ error, action, setErrors, failedAction }) {
  const url = yield handleReduxError({ error, failedAction })
  // Error without response -> return a general message and log
  if (!error.response) {
    yield put({
      type: types.ERROR,
      message: error.message || 'Server response is not received. Please check your connection.',
      url,
    })
    yield delay(2300)
    yield put({ type: types.VANISH })
    tracker.log({ error, action: { type: action.type } })
  } else {
    const { status, statusText, data } = error.response
    if (status === 400) {
      // 400 Error -> Notify error in form
      setErrors instanceof Function && setErrors(data)
    } else {
      // Other errors -> log errors and display error on status bar
      yield put({
        type: types.ERROR,
        code: status,
        status_message: statusText,
        content: error.message,
        url,
      })
      tracker.log({ error, action: { type: action.type } })
      if (status === 401) {
        history.push({
          pathname: routes.logout,
          state: { from: history.location },
        })
      }
      yield delay(2300)
      yield put({ type: types.VANISH })
    }
  }
}
