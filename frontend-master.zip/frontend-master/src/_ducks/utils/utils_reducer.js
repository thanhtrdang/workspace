export const initTypes = ({ prefix, data }) => {
  let result = {}
  for (const key in data) {
    data[key].forEach(option => {
      const id = key.toUpperCase() === '_' ? `${option.toUpperCase()}` : `${key.toUpperCase()}_${option.toUpperCase()}`
      const value = `${prefix.toUpperCase()}_${id}`
      result[id] = value
    })
  }
  return result
}

export const initReducer = ({ reducer, state, action, prefix }) => {
  const typeKey = action.type.replace(`${prefix}_`, '')
  return action && reducer[typeKey] instanceof Function ? reducer[typeKey](state, action) : state
}

export const generateStateFromAction = (action, state) => {
  const type = action.type
  if (type && typeof type === 'string') {
    const stateKey = type.substring(type.indexOf('_') + 1, type.lastIndexOf('_')).toLowerCase()
    const stateValue = type.substring(type.lastIndexOf('_') + 1, type.length).toLowerCase()
    return {
      ...state,
      [stateKey]: stateValue,
    }
  } else {
    return state
  }
}
