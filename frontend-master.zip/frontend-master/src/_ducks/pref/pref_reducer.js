import { initReducer, initTypes } from '../utils/utils_reducer'

const prefix = 'PREF'

export const types = initTypes({
  prefix,
  data: {
    _: ['RESET'],
    ADMIN_ANNOUCERS: ['VISIBLE', 'HIDDEN', 'TOGGLE'],
    HOME_ANNOUNCER: ['VISIBLE', 'HIDDEN'],
    CLOSED_TOURNAMENTS: ['VISIBLE', 'HIDDEN'],
  },
})

export const actions = {
  hideHomeAnnouncer: _ => ({
    type: types.HOME_ANNOUNCER_HIDDEN,
  }),
  hideClosedTournaments: _ => ({
    type: types.CLOSED_TOURNAMENTS_HIDDEN,
  }),
  showClosedTournaments: _ => ({
    type: types.CLOSED_TOURNAMENTS_VISIBLE,
  }),

  showAnnouncers: _ => ({
    type: types.ADMIN_ANNOUNCERS_VISIBLE,
  }),
  hideAnnouncers: _ => ({
    type: types.ADMIN_ANNOUNCERS_HIDDEN,
  }),
  toggle_announcers: _ => ({
    type: types.ADMIN_ANNOUNCERS_TOGGLE,
  }),
}

export const initialState = {
  closed_tournaments: 'visible',
  home_announcer: 'visible',
  admin_announcers: 'visible',
}

const reducer = {
  CLOSED_TOURNAMENTS_VISIBLE: state => ({ ...state, closed_tournaments: 'visible' }),
  CLOSED_TOURNAMENTS_HIDDEN: state => ({ ...state, closed_tournaments: 'hidden' }),

  HOME_ANNOUNCER_VISIBLE: state => ({ ...state, home_announcer: 'visible' }),
  HOME_ANNOUNCER_HIDDEN: state => ({ ...state, home_announcer: 'hidden' }),

  ADMIN_ANNOUNCERS_VISIBLE: state => ({ ...state, admin_announcers: 'visible' }),
  ADMIN_ANNOUNCERS_HIDDEN: state => ({ ...state, admin_announcers: 'hidden' }),
  ADMIN_ANNOUNCERS_TOGGLE: state => ({
    ...state,
    admin_announcers: state.admin_announcers === 'hidden' ? 'visible' : 'hidden',
  }),
}

export default (state = initialState, action) => initReducer({ action, state, reducer, prefix })

export const getHomeAnnoucerPref = state => state.home_announcer
export const getClosedTournamentsPref = state => state.closed_tournaments
export const is_admin_announcers_visible = state => state.announcersState === 'visible'
