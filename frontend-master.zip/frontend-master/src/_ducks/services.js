import { apiGameNames } from 'var'

const POST = 'post'
const PUT = 'put'

const auth = {
  login: {
    url: 'auth/token/login',
    method: POST,
  },
  signup: {
    // url: 'auth/users/create',
    url: 'invite/register',
    method: POST,
  },
  verify: {
    url: 'auth/users/confirm/',
    method: POST,
  },
  changePassword: {
    url: 'auth/password',
    secure: true,
    method: POST,
  },
  forgotPassword: {
    url: 'auth/password/reset/',
    method: POST,
  },
  resetPassword: {
    url: 'auth/password/reset/confirm/',
    method: POST,
  },
  resendActivationEmail: {
    url: 'invite/resend-activation-email',
    method: POST,
  },
}
/* ------ Tournament ------- */
const tournament = {
  request: id => ({ url: `api/tournaments/${id}/` }),
  requestList: ({ game, status }) => {
    const gameFilter = game ? `game_name=${apiGameNames[game]}` : undefined
    const statusFilter = status ? `status=${status}` : undefined
    const filter = [gameFilter, statusFilter].filter(i => i).join('&')
    const requestUrl = 'api/tournaments'
    const requestUrlWithFilter = filter ? `${requestUrl}/?${filter}` : requestUrl

    return {
      url: requestUrlWithFilter,
    }
  },
  requestMyPastTournaments: ({ game }) => ({
    url: `api/tournament/history?game_name=${apiGameNames[game]}`,
    secure: true,
  }),
  requestMyActiveTournaments: ({ game }) => ({
    url: `api/tournament/active?game_name=${apiGameNames[game]}`,
    secure: true,
  }),
  join: id => ({
    url: `api/tournament/${id}/join`,
    secure: true,
    method: POST,
  }),
  requestHistory: username => ({
    url: `api/info/${username}/tournaments`,
  }),
}

/* ------ Stats ------- */
const leaderboard = {
  request: id => ({
    url: `api/tournament/${id}/leaderboard`,
  }),
}

const matches = {
  requestMyMatches: {
    url: 'api/my-matches',
    secure: true,
  },
  requestMyMatchesInTournament: id => ({
    url: `api/tournament/${id}/matches`,
    secure: true,
  }),
  requestMatchDetails: match_id => ({
    url: `api/match/${match_id}/detail`,
  }),
  requestMatchSummary: match_id => ({
    url: `api/match/${match_id}/summary`,
  }),
}

/* ------ Pubg ------- */
const pubg = {
  activate: {
    url: 'api/user/game_activation?game_name=PUBG',
    secure: true,
    method: POST,
  },
  checkActivation: {
    url: 'api/user/game_activation?game_name=PUBG',
    secure: true,
  },
  link: {
    url: 'api/link/pubg/link',
    secure: true,
    method: POST,
  },
  requestCode: {
    url: 'api/link/pubg/verify',
    secure: true,
  },
  verify: {
    url: 'api/link/pubg/verify',
    secure: true,
    method: PUT,
  },
}

const apex = {
  activate: {
    url: 'api/user/game_activation?game_name=AL',
    secure: true,
    method: POST,
  },
  checkActivation: {
    url: 'api/user/game_activation?game_name=AL',
    secure: true,
  },
}

/* ------ User ------- */
const user = {
  profile: {
    url: 'api/profile',
    secure: true,
  },
  sendReferralEmail: {
    url: 'invite/send_referral',
    secure: true,
    method: POST,
  },
  publicProfile: username => ({
    url: `api/info/${username}`,
  }),
  stats: username => ({
    url: `api/info/${username}/stats`,
  }),
}

/* ------ Balance ------- */
const balance = {
  request: {
    url: 'api/accounting/balance',
    secure: true,
  },
  requestCredit: {
    url: 'api/accounting/balance',
    secure: true,
  },
  withdraw: {
    url: 'api/accounting/withdraw',
    method: POST,
    secure: true,
  },
  requestWithdrawHistory: {
    url: 'api/accounting/withdrawal-history',
    secure: true,
  },
  requestTransactionHistory: {
    url: 'api/accounting/transaction-history',
    secure: true,
  },
  checkDailyReward: {
    url: 'api/accounting/claim',
    secure: true,
  },
  claimDailyReward: {
    url: 'api/accounting/claim',
    method: POST,
    secure: true,
  },
}

const common = {
  announcements: {
    url: 'api/announcements',
  },
  contact: {
    url: 'api/contact',
    method: POST,
  },
}

export const services = {
  auth,
  user,
  tournament,
  leaderboard,
  matches,
  pubg,
  apex,
  balance,
  common,
}
