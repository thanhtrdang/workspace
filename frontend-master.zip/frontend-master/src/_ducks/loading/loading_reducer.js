export default (state = {}, action) => {
  const { type } = action
  const matches = /(.*)_(REQUEST|SUCCESS|FAILURE)/.exec(type)

  // Ignore if it's not a *_REQUEST / *_SUCCESS /  *_FAILURE actions
  if (!matches) return state

  const [, requestName, requestState] = matches

  return {
    ...state,
    // Return true if a request is fetching, and false if it's succeeded/failed
    [`${requestName}_REQUEST`]: requestState === 'REQUEST',
  }
}

export const is_any_loading = state => Object.values(state).includes(true)

export const is_loading = state => actions => actions.some(action => state[action] === true)
