/* Action Types */
import { initTypes, initReducer } from '../utils/utils_reducer'
import { SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION } from 'constants'

const prefix = 'PROFILE'

export const types = initTypes({
  prefix,
  data: {
    _: ['REQUEST', 'SUCCESS', 'FAILURE', 'RESET'],
  },
})

/* --- Actions --- */
export const actions = {
  requestProfile: init => ({
    type: types.REQUEST,
    init,
  }),
}

/* --- Reducers --- */
export const initialState = {
  username: undefined,
  email: undefined,
  id: undefined,
  referral_code: undefined,
  referrals: [],
  has_client_ever_run: undefined,
  client_running: undefined,
}

const reducer = {
  RESET: _ => initialState,
  SUCCESS: (state, action) => ({
    ...state,
    username: action.username,
    email: action.email,
    id: action.id,
    referral_code: action.referral_codes,
    referrals: action.referrals,

    has_client_ever_run: action.has_client_ever_run,
    client_running: action.client_running,
  }),
}

export default (state = initialState, action) => initReducer({ action, state, reducer, prefix })

/* --- Selectors --- */
export const get_username = state => state.username
export const get_email = state => state.email
export const get_user_id = state => state.id
export const get_referral_code = state => state.referral_code
export const get_referrals = state => state.referrals
export const has_client_ever_run = state => state.has_client_ever_run
export const is_client_running = state => state.client_running
