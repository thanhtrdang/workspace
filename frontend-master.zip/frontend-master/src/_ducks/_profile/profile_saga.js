import { put, takeLatest } from 'redux-saga/effects'

import tracker from 'helpers/tracker'
import utils from 'helpers/utils'

import { captureError } from '_ducks/utils/utils_saga'
import { types as pubgTypes } from '_ducks/_pubg/pubg_reducer'
import { types as wallet_types } from '_ducks/_wallet/wallet_reducer'

import { types as profile_types } from './profile_reducer'

import { invoke } from 'helpers/invoker'
import { services } from '_ducks/services'

/**-------------------
 *    PROFILE
 -------------------*/
function* requestProfileSaga() {
  yield takeLatest(profile_types.REQUEST, requestProfile)
}

function* requestProfile(action) {
  const { init } = action
  try {
    const {
      username,
      account: { account_id, email, balance, credit_balance },
      player_accounts,
      referral_codes,
      referrals,
      has_client_ever_run,
      client_running,
    } = yield invoke(services.user.profile)

    yield put({
      type: profile_types.SUCCESS,
      id: account_id,
      username,
      email,
      referral_codes,
      referrals,
      has_client_ever_run,
      client_running,
    })

    // PUBG
    if (utils.is_populated(player_accounts)) {
      yield put({
        type: pubgTypes.SUCCESS,
        playerId: player_accounts[0].player_id,
        name: player_accounts[0].name,
        verifiedStatus: player_accounts[0].verified_status,
        url: player_accounts[0].url,
      })
    } else {
      yield put({ type: pubgTypes.FAILURE })
    }

    yield put({
      type: wallet_types.BALANCE_SUCCESS,
      balance: balance ? parseFloat(balance.amount, 10) : 0,
      balanceCurrency: balance && balance.currency,
    })

    yield put({
      type: wallet_types.CREDIT_SUCCESS,
      credit: credit_balance ? parseInt(credit_balance.amount, 10) : 0,
      creditCurrency: credit_balance && credit_balance.currency,
    })

    // Check daily credit reward right after logging in
    yield put({
      type: wallet_types.CHECK_DAILY_REWARD_REQUEST,
    })

    if (init) {
      tracker.setUser({
        id: account_id,
        username,
        email,
      })
    }
  } catch (error) {
    yield captureError({ error, action, failedAction: profile_types.FAILED })
  }
}

export default [requestProfileSaga]
