import { put, takeLatest } from 'redux-saga/effects'

import { routes } from 'var'
import { history } from 'helpers/configureStore'

import { types } from './wallet_reducer'

import { captureError, alertMessage } from '../utils/utils_saga'

import { invoke } from 'helpers/invoker'
import { services } from '_ducks/services'

/* ---------------------------
        REQUEST BALANCE
----------------------------*/
function* requestBalanceSaga() {
  yield takeLatest(types.BALANCE_REQUEST, requestBalance)
}

function* requestBalance(action) {
  try {
    const {
      balance: { amount, currency },
    } = yield invoke(services.balance.request)
    yield put({
      type: types.BALANCE_SUCCESS,
      balance: parseFloat(amount, 10),
      balanceCurrency: currency,
    })
  } catch (error) {
    yield captureError({ error, action, failedAction: types.BALANCE_FAILURE })
  }
}

/* ---------------------------
        REQUEST CREDIT
----------------------------*/
function* requestCreditSaga() {
  yield takeLatest(types.CREDIT_REQUEST, requestCredit)
}

function* requestCredit(action) {
  try {
    const {
      credit_balance: { amount, currency },
    } = yield invoke(services.balance.requestCredit)
    yield put({
      type: types.CREDIT_SUCCESS,
      credit: parseInt(amount, 10),
      creditCurrency: currency,
    })
  } catch (error) {
    yield captureError({ error, action, failedAction: types.CREDIT_FAILURE })
  }
}

/* ---------------------------
        WITHDRAW BALANCE
----------------------------*/
function* withdrawSaga() {
  yield takeLatest(types.WITHDRAW_REQUEST, withdraw)
}

function* withdraw(action) {
  const { email, amount, setSubmitting, setErrors, resetForm } = action

  try {
    yield invoke(services.balance.withdraw, { paypal_address: email, amount })
    yield put({ type: types.WITHDRAW_SUCCESS })
    yield put({ type: types.BALANCE_REQUEST })
    resetForm()
    setSubmitting instanceof Function && setSubmitting(false)
    yield alertMessage('Your withdrawal request has been sent successfully.')
    history.push(routes.transactionHistory)
  } catch (error) {
    yield captureError({ error, action, setErrors, failedAction: types.WITHDRAW_FAILURE })
    setSubmitting instanceof Function && setSubmitting(false)
  }
}

function* checkDailyRewardSaga() {
  yield takeLatest(types.CHECK_DAILY_REWARD_REQUEST, checkDailyReward)
}

function* checkDailyReward(action) {
  try {
    const { amount_available, credit_available, next_available_credit_at, next_credits, streak } = yield invoke(
      services.balance.checkDailyReward,
    )
    yield put({
      type: types.CHECK_DAILY_REWARD_SUCCESS,
      amount_available,
      credit_available,
      next_available_credit_at,
      next_credits,
      streak,
    })
  } catch (error) {
    yield captureError({ error, action, failedAction: types.CHECK_DAILY_REWARD_FAILURE })
  }
}

function* claimDailyRewardSaga() {
  yield takeLatest(types.CLAIM_DAILY_REWARD_REQUEST, claimDailyReward)
}

function* claimDailyReward(action) {
  const { setErrors, setSubmitting } = action
  try {
    yield invoke(services.balance.claimDailyReward)
    yield put({ type: types.CLAIM_DAILY_REWARD_SUCCESS })
    // request credit to reset
    yield put({ type: types.CREDIT_REQUEST })
    yield put({ type: types.CHECK_DAILY_REWARD_REQUEST })
    setSubmitting instanceof Function && setSubmitting(false)
    yield alertMessage('Your daily reward has been claimed successfully.')
  } catch (error) {
    setSubmitting instanceof Function && setSubmitting(false)
    yield captureError({
      error,
      action,
      setErrors,
      failedAction: types.CLAIM_DAILY_REWARD_FAILURE,
    })
  }
}

export default [requestBalanceSaga, withdrawSaga, requestCreditSaga, checkDailyRewardSaga, claimDailyRewardSaga]
