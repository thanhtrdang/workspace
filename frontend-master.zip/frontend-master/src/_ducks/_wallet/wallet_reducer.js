import { initTypes } from '../utils/utils_reducer'

const prefix = 'WALLET'
/* Action Types */
export const types = initTypes({
  prefix,
  data: {
    _: ['reset'],
    BALANCE: ['REQUEST', 'SUCCESS', 'FAILURE'],
    CREDIT: ['REQUEST', 'SUCCESS', 'FAILURE'],
    WITHDRAW: ['REQUEST', 'SUCCESS', 'FAILURE'],
    CHECK_DAILY_REWARD: ['REQUEST', 'SUCCESS', 'FAILURE'],
    CLAIM_DAILY_REWARD: ['REQUEST', 'SUCCESS', 'FAILURE'],
  },
})

/* --- Initial State --- */
export const initialState = {
  balance: 0,
  balanceCurrency: '',

  credit: 0,
  creditCurrency: '',

  daily_credit_available: false,
  daily_next_available_credit_at: null,
  daily_streak: 0,

  daily_amount_available: 0,
  daily_next_credits: 0,
  daily_credit_currency: '',
}

/* --- Actions --- */
export const actions = {
  request: _ => ({
    type: types.BALANCE_REQUEST,
  }),

  requestCredit: _ => ({
    type: types.CREDIT_REQUEST,
  }),

  withdraw: (email, amount, setErrors, setSubmitting, resetForm) => ({
    type: types.WITHDRAW_REQUEST,
    email,
    amount,
    setErrors,
    setSubmitting,
    resetForm,
  }),

  checkDailyReward: _ => ({
    type: types.CHECK_DAILY_REWARD_REQUEST,
  }),

  claimDailyReward: (setErrors, setSubmitting) => ({
    type: types.CLAIM_DAILY_REWARD_REQUEST,
    setErrors,
    setSubmitting,
  }),
}

export default (state = initialState, action) => {
  switch (action.type) {
    case types.RESET:
      return initialState

    case types.BALANCE_SUCCESS:
      return {
        ...state,
        balance: action.balance,
        balanceCurrency: action.balanceCurrency || state.balanceCurrency,
      }

    case types.CREDIT_SUCCESS:
      return { ...state, credit: action.credit, creditCurrency: action.creditCurrency }

    case types.CLAIM_DAILY_REWARD_SUCCESS:
      return {
        ...state,
        daily_credit_available: false,
      }

    case types.CHECK_DAILY_REWARD_SUCCESS:
      const { amount_available, credit_available, next_available_credit_at, next_credits, streak } = action
      return {
        ...state,
        daily_amount_available: amount_available,
        daily_credit_available: credit_available,
        daily_next_available_credit_at: next_available_credit_at,
        daily_next_credits: next_credits.amount,
        daily_credit_currency: next_credits.currency,
        daily_streak: streak,
      }

    default:
      return state
  }
}

export const getBalance = state => state.balance
export const getBalanceCurrency = state => state.balanceCurrency
export const get_credit = state => state.credit
export const get_credit_currency = state => state.creditCurrency || state.daily_credit_currency

export const isDailyCreditsAvailable = state => state.daily_credit_available
export const getNextRewardDate = state => state.daily_next_available_credit_at
export const getAvailableRewardAmount = state => state.daily_amount_available
export const getNextRewardAmount = state =>
  state.daily_credit_available ? state.daily_next_credits : state.daily_amount_available
