import { put, takeLatest } from 'redux-saga/effects'

import { captureError } from '_ducks/utils/utils_saga'

import { types } from './apex_reducer'
import { types as walletTypes } from '_ducks/_wallet/wallet_reducer'

import { invoke } from 'helpers/invoker'
import { services } from '_ducks/services'

function* activateSaga() {
  yield takeLatest(types.ACTIVATE_REQUEST, activate)
}

function* activate(action) {
  try {
    yield invoke(services.apex.activate)
    yield put({ type: types.ACTIVATE_SUCCESS })
    yield put({ type: walletTypes.CREDIT_REQUEST })
  } catch (error) {
    yield captureError({ error, action, failedAction: types.ACTIVATE_FAILURE })
  }
}

function* checkActivationSaga() {
  yield takeLatest(types.CHECK_ACTIVATION_REQUEST, checkActivation)
}

function* checkActivation(action) {
  try {
    const { activated } = yield invoke(services.apex.checkActivation)
    yield put({ type: types.CHECK_ACTIVATION_SUCCESS, activated })
  } catch (error) {
    yield captureError({ error, action, failedAction: types.CHECK_ACTIVATION_FAILURE })
  }
}

export default [activateSaga, checkActivationSaga]
