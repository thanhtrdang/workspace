import { initReducer, initTypes } from '_ducks/utils/utils_reducer'

/* Action Types */
const prefix = 'APEX'

export const types = initTypes({
  prefix,
  data: {
    _: ['RESET'],
    ACTIVATE: ['REQUEST', 'SUCCESS', 'FAILURE'],
    CHECK_ACTIVATION: ['REQUEST', 'SUCCESS', 'FAILURE'],
  },
})

/* --- Actions --- */
export const actions = {
  activate: _ => ({
    type: types.ACTIVATE_REQUEST,
  }),
  checkActivation: _ => ({
    type: types.CHECK_ACTIVATION_REQUEST,
  }),
}

/* --- Reducers --- */
export const initialState = {
  activated: undefined,
}

const reducer = {
  RESET: _ => initialState,
  ACTIVATE_SUCCESS: state => ({
    ...state,
    activated: true,
  }),
  CHECK_ACTIVATION_SUCCESS: (state, action) => ({
    ...state,
    activated: action.activated,
  }),
}

export default (state = initialState, action) => initReducer({ action, state, reducer, prefix })

export const is_activated = state => state.activated
