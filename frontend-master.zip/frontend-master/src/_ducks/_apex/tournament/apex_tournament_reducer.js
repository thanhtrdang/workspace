import utils from 'helpers/utils'
import tournamentUtils from './apex_tournament_utils'
import { initTypes, initReducer } from '_ducks/utils/utils_reducer'

const prefix = 'APEX_TOURNAMENT'

export const types = initTypes({
  prefix,
  data: {
    _: ['END', 'REQUEST', 'SUCCESS', 'FAILURE'],
    MY: ['REQUEST', 'SUCCESS', 'FAILURE', 'RESET'],
    LIST: ['REQUEST', 'SUCCESS', 'FAILURE'],
    JOIN: ['REQUEST', 'SUCCESS', 'FAILURE'],
  },
})

/* --- Actions --- */
export const actions = {
  requestTournament: id => ({
    type: types.REQUEST,
    id,
  }),
  requestList: filter => ({
    type: types.LIST_REQUEST,
    filter,
  }),
  requestMyTournaments: _ => ({
    type: types.MY_REQUEST,
  }),
  joinTournament: (id, setErrors, setSubmitting) => ({
    type: types.JOIN_REQUEST,
    id,
    setErrors,
    setSubmitting,
  }),

  // -------- Synchronous actions --------- //
  endTournament: id => ({
    type: types.END,
    id,
  }),
}

/* --- Reducers --- */
export const initialState = {
  tournaments: {},
  my_ids: [],
}

const reducer = {
  SUCCESS: (state, action) => ({
    ...state,
    tournaments: { ...state.tournaments, [action.tournament.id.toString()]: action.tournament },
  }),
  LIST_SUCCESS: (state, action) => ({
    ...state,
    tournaments: action.tournaments,
  }),
  MY_SUCCESS: (state, action) => ({
    ...state,
    my_ids: Object.keys(action.tournaments),
  }),

  MY_RESET: state => ({ ...state, my_ids: [] }),

  JOIN_SUCCESS: (state, action) => ({ ...state, my_ids: [...state.my_ids, action.id.toString()] }),

  END: (state, action) => {
    const endedTournamentId = action.id
    const listWithEndedTournament = state.all.map(tournament =>
      tournament.id === endedTournamentId ? { ...tournament, status: 'ended' } : tournament,
    )

    return {
      ...state,
      all: listWithEndedTournament,
    }
  },
}

export default (state = initialState, action) => initReducer({ action, state, reducer, prefix })

/* --- Selectors --- */
export const get = (state, id) => (state.tournaments ? state.tournaments[id] : null)

export const get_all = state => tournamentUtils.sort('status')(Object.values(state.tournaments))

export const get_active = state => Object.values(state.tournaments).filter(tournament => tournament.status === 'active')

export const get_inactive = state =>
  Object.values(state.tournaments).filter(tournament => tournament.status !== 'active')

export const get_my = state =>
  tournamentUtils.sort('status')(utils.filter_object_by_ids(state.tournaments)(state.my_ids))

export const get_my_ids = state => {
  return state.my_ids
}
