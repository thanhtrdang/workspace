import * as R from 'ramda'
import utils from 'helpers/utils'

class Tournament {
  sort = (field, order = 'asc') => tournament => {
    switch (field) {
      case 'status':
        const diff = (t1, t2) => (t1.status === 'active' ? -1 : 1)
        const sortedList = R.sort(diff, tournament)

        if (order === 'desc') {
          return R.reverse(sortedList)
        }
        return sortedList

      default:
        return tournament
    }
  }

  getRemainder = (oldList, list) =>
    utils.is_populated(oldList) ? oldList.filter(tourney => R.findIndex(R.propEq('id', tourney.id))(list) === -1) : []
}

export default new Tournament()
