import { put, takeEvery, select } from 'redux-saga/effects'
import * as R from 'ramda'

import { routes } from 'var'
import { gamePaths } from 'var'

import utils from 'helpers/utils'
import tournamentUtils from './apex_tournament_utils'
import { history } from 'helpers/configureStore'

import { captureError, alertMessage } from '_ducks/utils/utils_saga'
import { is_authed, has_client_ever_run } from '_ducks/reducers'
import { types as wallet_types } from '_ducks/_wallet/wallet_reducer'
import { types as leaderboardTypes } from '_ducks/_apex/leaderboard/apex_leaderboard_reducer'

import { types as tournamentTypes } from './apex_tournament_reducer'

import { invoke } from 'helpers/invoker'
import { services } from '_ducks/services'

/* -------------------------- 
*           LIST
-------------------------- */
function* requestListSaga() {
  yield takeEvery(tournamentTypes.LIST_REQUEST, requestList)
}
function* requestList(action) {
  const { filter } = action
  try {
    const results = yield invoke(services.tournament.requestList({ game: 'apex', ...filter }))
    const unsortedList = results.filter(tournament => tournament.status !== 'cancelled')
    const list = tournamentUtils.sort('status')(unsortedList)
    const tournaments = utils.array_to_object(list)

    yield put({
      type: tournamentTypes.LIST_SUCCESS,
      tournaments,
    })
  } catch (error) {
    yield captureError({ error, action, failedAction: tournamentTypes.LIST_FAILURE })
  }
}

/* -------------------------- 
*     SINGLE TOURNAMENT
-------------------------- */
function* requestTournamentSaga() {
  yield takeEvery(tournamentTypes.REQUEST, requestTournament)
}
function* requestTournament(action) {
  const { id } = action
  try {
    // const tournament = yield call(tournamentService.requestTournament, id)
    const tournament = yield invoke(services.tournament.request(id))
    yield put({
      type: tournamentTypes.SUCCESS,
      tournament,
    })
  } catch (error) {
    yield captureError({ error, action, failedAction: tournamentTypes.FAILURE })
  }
}

/* -------------------------- 
*    MY TOURNAMENTS LIST
-------------------------- */
function* requestMyTournamentsSaga() {
  yield takeEvery(tournamentTypes.MY_REQUEST, requestMyTournaments)
}
function* requestMyTournaments(action) {
  const authed = yield select(is_authed)
  if (authed) {
    try {
      const myPastTournaments = yield invoke(services.tournament.requestMyPastTournaments({ game: 'apex' }))
      const myActiveTournaments = yield invoke(services.tournament.requestMyActiveTournaments({ game: 'apex' }))

      const unsortedList = R.unionWith(R.eqBy(R.prop('id')), myPastTournaments, myActiveTournaments)

      const list = tournamentUtils.sort('status')(unsortedList)
      const tournaments = utils.array_to_object(list)

      yield put({
        type: tournamentTypes.MY_SUCCESS,
        list,
        tournaments,
      })
    } catch (error) {
      yield captureError({ error, action, failedAction: tournamentTypes.MY_FAILURE })
    }
  }
}

/* -------------------------- 
*           JOIN
-------------------------- */
function* joinTournamentSaga() {
  yield takeEvery(tournamentTypes.JOIN_REQUEST, joinTournament)
}

function* joinTournament(action) {
  const { id, setSubmitting, setErrors } = action
  const authed = yield select(is_authed)
  const hasClientEverRun = yield select(has_client_ever_run)
  // Redirect if user hasn't logged in
  if (!authed) {
    history.push({
      pathname: routes.login,
      state: { from: history.location },
    })
    return
  }

  try {
    yield invoke(services.tournament.join(id))

    yield put({ type: tournamentTypes.JOIN_SUCCESS, id })

    /* Refresh the leaderboard */
    yield put({ type: leaderboardTypes.PARTICIPANTS_REQUEST, id })

    /* Refresh credit */
    yield put({
      type: wallet_types.CREDIT_REQUEST,
    })
    setSubmitting instanceof Function && setSubmitting(false)

    yield alertMessage('You have successfully joined the tournament.')
    !hasClientEverRun && history.push(gamePaths.apex.client)
  } catch (error) {
    if (error.response.status === 400) {
      // 400 Error -> Notify error in form
      setErrors instanceof Function && setErrors(error.response.data)
    }
    yield captureError({
      error,
      action,
      setErrors,
      failedAction: tournamentTypes.JOIN_FAILURE,
    })
    setSubmitting instanceof Function && setSubmitting(false)
  }
}

export default [requestTournamentSaga, requestListSaga, requestMyTournamentsSaga, joinTournamentSaga]
