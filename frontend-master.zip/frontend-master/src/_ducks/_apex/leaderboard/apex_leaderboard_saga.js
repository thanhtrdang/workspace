import { put, takeLatest } from 'redux-saga/effects'

import { captureError } from '_ducks/utils/utils_saga'
import { types } from './pubg_leaderboard_reducer'

import { invoke } from 'helpers/invoker'
import { services } from '_ducks/services'

/* -------------------------- 
*          Participants
-------------------------- */
function* requestParticipantsSaga() {
  yield takeLatest(types.PARTICIPANTS_REQUEST, requestParticipants)
}
function* requestParticipants(action) {
  const { id } = action
  try {
    const { participants } = yield invoke(services.leaderboard.request(id))

    // const data = participants.map(p => ({ ...p, id: p.user.username }))
    // const participantSchema = new schema.Entity('participants')
    // const participantListSchema = new schema.Array(participantSchema)
    // const participantsData = normalize(data, participantListSchema).entities.participants

    yield put({
      type: types.PARTICIPANTS_SUCCESS,
      participants,
      tournament_id: id,
    })
  } catch (error) {
    yield captureError({ error, action, failedAction: types.PARTICIPANTS_FAILURE })
  }
}

export default [requestParticipantsSaga]
