import { initTypes, initReducer } from '_ducks/utils/utils_reducer'

/* Prefix */
const prefix = 'PUBG_LEADERBOARD'

/* Action Types */
export const types = initTypes({
  prefix,
  data: {
    _: ['RESET'],
    PARTICIPANTS: ['REQUEST', 'SUCCESS', 'FAILURE'],
  },
})

export const actions = {
  request: id => ({
    type: types.PARTICIPANTS_REQUEST,
    id,
  }),
}
/* --- Initial State --- */
const initialState = {
  participants: {},
}

const reducer = {
  RESET: _ => initialState,
  PARTICIPANTS_FAILURE: state => state,
  PARTICIPANTS_SUCCESS: (state, action) => ({
    ...state,
    participants: {
      ...state.participants,
      [action.tournament_id]: { id: action.tournament_id, data: action.participants },
    },
  }),
}
export default (state = initialState, action) => initReducer({ action, state, reducer, prefix })

/* --- Selectors --- */
export const get_participants = (state, id) => state.participants[id]
