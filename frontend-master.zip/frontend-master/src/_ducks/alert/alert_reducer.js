// export const types = {
//   ALERT_MESSAGE_SUCCESS: 'ALERT_MESSAGE_SUCCESS',
//   ALERT_MESSAGE_ERROR: 'ALERT_MESSAGE_ERROR',
//   ALERT_MESSAGE_HIDDEN: 'ALERT_MESSAGE_HIDDEN',
// }

import { initTypes, initReducer } from '../utils/utils_reducer'

const prefix = 'ALERT'

export const types = initTypes({
  prefix,
  data: {
    _: ['SUCCESS', 'ERROR', 'VANISH'],
  },
})
export const actions = {
  alert_success: message => ({
    type: types.SUCCESS,
    message,
  }),
  alert_error: error => ({
    type: types.ERROR,
    status_message: error && error.response && error.response.statusText,
    content: (error && error.message) || 'Server response is not received. Please check your connection.',
    code: !!error.response && error.response.status,
    url: error && error.config && error.config.url,
  }),
  alert_vanish: _ => ({
    type: types.VANISH,
  }),
}

const initialState = {
  messages: [],
}

const reducer = {
  SUCCESS: (state, action) => ({
    ...state,
    messages: [
      ...state.messages,
      {
        state: 'success',
        content: action.message,
      },
    ],
  }),
  ERROR: (state, action) => ({
    ...state,
    messages: [
      ...state.messages,
      {
        state: 'error',
        status_message: action.status_message,
        content: action.content,
        code: action.code,
        url: action.url,
      },
    ],
  }),
  VANISH: state => ({ ...state, messages: state.messages.slice(1) }),
}

export default (state = initialState, action) => initReducer({ action, state, reducer, prefix })

export const get = state =>
  state.messages.filter((message, index, self) => index === self.findIndex(item => item.content === message.content))

export const get_delay = _ => 2500
