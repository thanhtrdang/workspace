import { fork } from 'redux-saga/effects'

import auth_saga from './_auth/auth_saga'
import wallet_saga from './_wallet/wallet_saga'
import profile_saga from './_profile/profile_saga'
import pubg_saga from './_pubg/pubg_saga'
import pubg_tournament_saga from './_pubg/tournament/pubg_tournament_saga'
import pubg_leaderboard_saga from './_pubg/leaderboard/pubg_leaderboard_saga'

import apex_saga from './_apex/apex_saga'
import apex_tournament_saga from './_apex/tournament/apex_tournament_saga'

const sagas = [
  ...auth_saga,
  ...wallet_saga,
  ...profile_saga,
  ...pubg_saga,
  ...pubg_tournament_saga,
  ...pubg_leaderboard_saga,
  ...apex_saga,
  ...apex_tournament_saga,
]

export default function* root() {
  yield sagas.map(saga => fork(saga))
}
