import { put, takeLatest } from 'redux-saga/effects'

import tracker from 'helpers/tracker'

import { captureError } from '../utils/utils_saga'
import { types as authTypes } from '../_auth/auth_reducer'
import { types as pubgTournamentTypes } from '../_pubg/tournament/pubg_tournament_reducer'
import { types as apexTournamentTypes } from '../_apex/tournament/apex_tournament_reducer'
import { types as profileTypes } from '../_profile/profile_reducer'
import { types as pubgTypes } from '../_pubg/pubg_reducer'
import { types as apexTypes } from '../_apex/apex_reducer'
import { types as walletTypes } from '../_wallet/wallet_reducer'

import { invoke } from 'helpers/invoker'
import { services } from '_ducks/services'

import { PIXEL_ID } from 'var'
import ReactPixel from 'react-facebook-pixel'

/* Login */
function* loginSaga() {
  yield takeLatest(authTypes.LOGIN_REQUEST, login)
}

function* login(action) {
  const { username, password, setErrors, setSubmitting } = action

  try {
    const { auth_token } = yield invoke(services.auth.login, { username, password })
    yield put({ type: authTypes.LOGIN_SUCCESS, auth_token })
    setSubmitting instanceof Function && setSubmitting(false)

    yield put({
      type: profileTypes.REQUEST,
      init: true,
    })

    yield put({ type: pubgTypes.CHECK_ACTIVATION_REQUEST })
    yield put({ type: apexTypes.CHECK_ACTIVATION_REQUEST })
  } catch (error) {
    yield captureError({ error, action, setErrors, failedAction: authTypes.LOGIN_FAILURE })
    setSubmitting instanceof Function && setSubmitting(false)
  }
}

/* Logout */
function* logoutSaga() {
  yield takeLatest(authTypes.LOGOUT_REQUEST, logout)
}

function* logout(action) {
  try {
    yield put({ type: profileTypes.RESET })
    yield put({ type: pubgTypes.RESET })
    yield put({ type: apexTypes.RESET })
    yield put({ type: walletTypes.RESET })
    yield put({ type: pubgTournamentTypes.MY_RESET })
    yield put({ type: apexTournamentTypes.MY_RESET })
    yield tracker.clear()
    yield put({ type: authTypes.LOGOUT_SUCCESS })
  } catch (error) {
    yield captureError({ error, action, failedAction: authTypes.LOGOUT_FAILURE })
  }
}

/* Signup */
function* signupSaga() {
  yield takeLatest(authTypes.SIGNUP_REQUEST, signup)
}

function* signup(action) {
  const {
    username,
    password,
    email,
    referralCode,
    recaptcha,
    setErrors,
    setSubmitting,
    setStatus,
    recaptchaRef,
  } = action

  try {
    yield invoke(services.auth.signup, {
      username,
      password,
      email,
      referral_code: referralCode,
      recaptcha,
    })
    if (PIXEL_ID) {
      ReactPixel.init(PIXEL_ID)
      ReactPixel.track('CompleteRegistration')
    }
    yield put({ type: authTypes.SIGNUP_SUCCESS })
    setSubmitting instanceof Function && setSubmitting(false)
    setStatus instanceof Function && setStatus({ completed: true })
  } catch (error) {
    setSubmitting instanceof Function && setSubmitting(false)
    recaptchaRef.current.reset()
    yield captureError({
      error,
      action: {
        type: action.type,
        username,
        email,
        referralCode,
        recaptcha,
      },
      setErrors,
      failedAction: authTypes.SIGNUP_FAILURE,
    })
  }
}

export default [loginSaga, logoutSaga, signupSaga]
