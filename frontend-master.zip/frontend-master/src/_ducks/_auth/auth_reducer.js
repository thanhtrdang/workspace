/* Action Types */
import { initTypes, initReducer } from '../utils/utils_reducer'

const prefix = 'AUTH'

export const types = initTypes({
  prefix,
  data: {
    LOGIN: ['REQUEST', 'SUCCESS', 'FAILURE'],
    LOGOUT: ['REQUEST', 'SUCCESS', 'FAILURE'],
    SIGNUP: ['REQUEST', 'SUCCESS', 'FAILURE'],
  },
})

/* --- Actions --- */
export const actions = {
  login: (username, password, setErrors, setSubmitting, retarget) => ({
    type: types.LOGIN_REQUEST,
    username,
    password,
    setErrors,
    setSubmitting,
    retarget,
  }),

  logout: _ => ({ type: types.LOGOUT_REQUEST }),

  signup: ({
    username,
    password,
    email,
    referralCode,
    recaptcha,
    setErrors,
    setSubmitting,
    setStatus,
    recaptchaRef,
  }) => ({
    type: types.SIGNUP_REQUEST,
    username,
    password,
    email,
    referralCode,
    recaptcha,
    setErrors,
    setSubmitting,
    setStatus,
    recaptchaRef,
  }),

  changePassword: (currentPassword, password, setErrors, setSubmitting, resetForm) => ({
    type: types.CHANGE_PASSWORD_REQUEST,
    currentPassword,
    password,
    setErrors,
    setSubmitting,
    resetForm,
  }),
}

/* --- Reducers --- */
export const initialState = {
  token: '',
}

const reducer = {
  LOGOUT_SUCCESS: _ => initialState,
  LOGIN_SUCCESS: (state, action) => ({ ...state, token: action.auth_token }),
}

export default (state = initialState, action) => initReducer({ action, state, reducer, prefix })

/* --- Selectors --- */
export const is_authed = state => (!!state.token ? true : false)
export const get_token = state => state.token
