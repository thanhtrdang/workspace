import { combineReducers } from 'redux'
import { connectRouter } from 'connected-react-router'

import auth, * as from_auth from './_auth/auth_reducer'
import balance, * as from_wallet from './_wallet/wallet_reducer'
import pubg, * as from_pubg from './_pubg/pubg_reducer'
import profile, * as from_profile from './_profile/profile_reducer'
import pubg_tournament, * as from_pubg_tournament from './_pubg/tournament/pubg_tournament_reducer'
import pubg_leaderboard, * as from_pubg_leaderboard from './_pubg/leaderboard/pubg_leaderboard_reducer'

import apex, * as from_apex from './_apex/apex_reducer'
import apex_tournament, * as from_apex_tournament from './_apex/tournament/apex_tournament_reducer'
import apex_leaderboard, * as from_apex_leaderboard from './_pubg/leaderboard/pubg_leaderboard_reducer'

import alert, * as from_alert from './alert/alert_reducer'
import pref, * as from_pref from './pref/pref_reducer'
import loading, * as from_loading from './loading/loading_reducer'

export const rootReducer = history =>
  combineReducers({
    router: connectRouter(history),
    auth,
    profile,
    balance,
    pubg,
    pubg_tournament,
    pubg_leaderboard,
    apex,
    apex_tournament,
    apex_leaderboard,
    alert,
    pref,
    loading,
  })

/* Auth selectors */
export const auth_actions = from_auth.actions
export const auth_types = from_auth.types
export const is_authed = state => from_auth.is_authed(state.auth)
export const get_token = state => from_auth.get_token(state.auth)

/* User selectors */
export const profile_actions = from_profile.actions
export const get_email = state => from_profile.get_email(state.profile)
export const get_username = state => from_profile.get_username(state.profile)
export const get_user_id = state => from_profile.get_user_id(state.profile)
export const get_referral_code = state => from_profile.get_referral_code(state.profile)
export const get_referrals = state => from_profile.get_referrals(state.profile)
export const has_client_ever_run = state => from_profile.has_client_ever_run(state.profile)
export const is_client_running = state => from_profile.is_client_running(state.profile)

/* Wallet selectors */
export const wallet_actions = from_wallet.actions
export const getBalance = state => from_wallet.getBalance(state.balance)
export const getBalanceCurrency = state => from_wallet.getBalanceCurrency(state.balance)
export const get_credit = state => from_wallet.get_credit(state.balance)
export const get_credit_currency = state => from_wallet.get_credit_currency(state.balance)

export const isDailyCreditsAvailable = state => from_wallet.isDailyCreditsAvailable(state.balance)
export const getNextRewardDate = state => from_wallet.getNextRewardDate(state.balance)
export const getAvailableRewardAmount = state => from_wallet.getAvailableRewardAmount(state.balance)
export const getNextRewardAmount = state => from_wallet.getNextRewardAmount(state.balance)

/* Pubg selectors */
export const pubg_actions = from_pubg.actions
export const get_pubg_id = state => from_pubg.get_id(state.pubg)
export const get_pubg_name = state => from_pubg.get_name(state.pubg)
export const get_pubg_verification = state => from_pubg.get_verification(state.pubg)
export const is_pubg_linked = state => from_pubg.is_linked(state.pubg)
export const is_pubg_activated = state => from_pubg.is_activated(state.pubg)

/* Tournament selectors */
export const pubg_tournament_actions = from_pubg_tournament.actions
export const pubg_tournament_types = from_pubg_tournament.types
export const get_all_pubg_tournaments = state => from_pubg_tournament.get_all(state.pubg_tournament)
export const get_active_pubg_tournaments = state => from_pubg_tournament.get_active(state.pubg_tournament)
export const get_inactive_pubg_tournaments = state => from_pubg_tournament.get_inactive(state.pubg_tournament)
export const get_my_pubg_tournaments = state => from_pubg_tournament.get_my(state.pubg_tournament)
export const get_my_pubg_tournament_ids = state => from_pubg_tournament.get_my_ids(state.pubg_tournament)
export const get_pubg_tournament = (state, id) => from_pubg_tournament.get(state.pubg_tournament, id)

/* Leaderboard selectors */
export const pubg_leaderboard_actions = from_pubg_leaderboard.actions
export const pubg_leaderboard_types = from_pubg_leaderboard.types
export const get_pubg_participants = (state, id) => from_pubg_leaderboard.get_participants(state.pubg_leaderboard, id)

/* Apex selectors */
export const apex_actions = from_apex.actions
export const is_apex_activated = state => from_apex.is_activated(state.apex)

/* Tournament selectors */
export const apex_tournament_actions = from_apex_tournament.actions
export const apex_tournament_types = from_apex_tournament.types
export const get_all_apex_tournaments = state => from_apex_tournament.get_all(state.apex_tournament)
export const get_active_apex_tournaments = state => from_apex_tournament.get_active(state.apex_tournament)
export const get_inactive_apex_tournaments = state => from_apex_tournament.get_inactive(state.apex_tournament)
export const get_my_apex_tournaments = state => from_apex_tournament.get_my(state.apex_tournament)
export const get_my_apex_tournament_ids = state => from_apex_tournament.get_my_ids(state.apex_tournament)
export const get_apex_tournament = (state, id) => from_apex_tournament.get(state.apex_tournament, id)

/* Leaderboard selectors */
export const apex_leaderboard_actions = from_apex_leaderboard.actions
export const apex_leaderboard_types = from_apex_leaderboard.types
export const get_apex_participants = (state, id) => from_apex_leaderboard.get_participants(state.apex_leaderboard, id)

/* Alert selectors */
export const alert_actions = from_alert.actions
export const get_alerts = state => from_alert.get(state.alert)
export const get_alert_delay = _ => from_alert.get_delay()

/* Preferences */
export const pref_actions = from_pref.actions
export const getHomeAnnoucerPref = state => from_pref.getHomeAnnoucerPref(state.pref)
export const getClosedTournamentsPref = state => from_pref.getClosedTournamentsPref(state.pref)
export const is_admin_announcers_visible = state => from_pref.is_admin_announcers_visible(state.pref)

/* Loading selectors */
export const is_loading = state => actions => from_loading.is_loading(state.loading)(actions)
export const is_any_loading = state => from_loading.is_any_loading(state.loading)
