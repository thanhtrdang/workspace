import { initReducer, initTypes } from '_ducks/utils/utils_reducer'

/* Action Types */
const prefix = 'PUBG'

export const types = initTypes({
  prefix,
  data: {
    _: ['REQUEST', 'SUCCESS', 'FAILURE', 'RESET'],
    LINK: ['REQUEST', 'SUCCESS', 'FAILURE'],
    VERIFY: ['REQUEST', 'SUCCESS', 'FAILURE'],

    ACTIVATE: ['REQUEST', 'SUCCESS', 'FAILURE'],
    CHECK_ACTIVATION: ['REQUEST', 'SUCCESS', 'FAILURE'],
  },
})

/* --- Actions --- */
export const actions = {
  activate: _ => ({
    type: types.ACTIVATE_REQUEST,
  }),
  checkActivation: _ => ({
    type: types.CHECK_ACTIVATION_REQUEST,
  }),

  link: (name, id, setErrors, setSubmitting) => ({
    type: types.LINK_REQUEST,
    name,
    id,
    setErrors,
    setSubmitting,
  }),
  verify: (image, setErrors, setSubmitting) => ({
    type: types.VERIFY_REQUEST,
    image,
    setErrors,
    setSubmitting,
  }),
}

/* --- Reducers --- */
export const initialState = {
  id: undefined,
  name: undefined,
  link: undefined,
  verification_status: undefined,

  activated: undefined,
}

const reducer = {
  RESET: _ => initialState,
  SUCCESS: (state, action) => ({
    ...state,
    id: action.playerId,
    name: action.name,
    link: true,
    verification_status: action.verifiedStatus,
  }),
  FAILURE: state => ({
    ...state,
    id: null,
    name: null,
    link: false,
    verification_status: null,
  }),
  ACTIVATE_SUCCESS: state => ({
    ...state,
    activated: true,
  }),
  CHECK_ACTIVATION_SUCCESS: (state, action) => ({
    ...state,
    activated: action.activated,
  }),
}

export default (state = initialState, action) => initReducer({ action, state, reducer, prefix })

export const get_id = state => state.id
export const get_name = state => state.name
export const is_linked = state => state.link
export const get_verification = state => state.verification_status

export const is_activated = state => state.activated
