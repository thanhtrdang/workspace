import { put, takeLatest, select } from 'redux-saga/effects'

import { routes } from 'var'
import { history } from 'helpers/configureStore'
import utils from 'helpers/utils'

import { is_pubg_activated } from '_ducks/reducers'
import { captureError, alertMessage } from '_ducks/utils/utils_saga'
import { types as profileTypes } from '_ducks/_profile/profile_reducer'
import { types as walletTypes } from '_ducks/_wallet/wallet_reducer'

import { types } from './pubg_reducer'

import { invoke } from 'helpers/invoker'
import { services } from '_ducks/services'

function* activateSaga() {
  yield takeLatest(types.ACTIVATE_REQUEST, activate)
}

function* activate(action) {
  try {
    yield invoke(services.pubg.activate)
    yield put({ type: types.ACTIVATE_SUCCESS })
    yield put({ type: walletTypes.CREDIT_REQUEST })
  } catch (error) {
    yield captureError({ error, action, failedAction: types.ACTIVATE_FAILURE })
  }
}

function* checkActivationSaga() {
  yield takeLatest(types.CHECK_ACTIVATION_REQUEST, checkActivation)
}

function* checkActivation(action) {
  try {
    const { activated } = yield invoke(services.pubg.checkActivation)
    yield put({ type: types.CHECK_ACTIVATION_SUCCESS, activated })
  } catch (error) {
    yield captureError({ error, action, failedAction: types.CHECK_ACTIVATION_FAILURE })
  }
}

/* Set Pubg Username */
function* linkSaga() {
  yield takeLatest(types.LINK_REQUEST, link)
}

function* link(action) {
  const { name, setErrors, setSubmitting } = action
  try {
    yield invoke(services.pubg.link, { name })

    const isPubgActivated = yield select(is_pubg_activated)
    // Auto activate account after linking pubg
    if (!isPubgActivated) {
      yield put({ type: types.ACTIVATE_REQUEST })
    }

    // Verify link status by refreshing profile
    const { player_accounts } = yield invoke(services.user.profile)
    yield put({ type: types.LINK_SUCCESS })

    if (utils.is_populated(player_accounts)) {
      yield put({
        type: types.SUCCESS,
        playerId: player_accounts[0].player_id,
        name: player_accounts[0].name,
        verifiedStatus: player_accounts[0].verified_status,
      })
    } else {
      yield put({ type: types.LINK_FAILURE })
    }

    setSubmitting instanceof Function && setSubmitting(false)
  } catch (error) {
    setSubmitting instanceof Function && setSubmitting(false)
    yield captureError({
      error,
      action,
      setErrors,
      failedAction: types.LINK_FAILURE,
    })
  }
}

function* verifySaga() {
  yield takeLatest(types.VERIFY_REQUEST, verify)
}

function* verify(action) {
  const { image, setErrors, setSubmitting } = action
  let data = new FormData()
  data.append('image', image)
  try {
    yield invoke(services.pubg.verify, data)
    yield put({ type: types.VERIFY_SUCCESS })

    // Refresh player info
    yield put({ type: profileTypes.REQUEST })

    setSubmitting instanceof Function && setSubmitting(false)
    yield alertMessage('You image has been uploaded successfully.')

    yield history.push(routes.home)
  } catch (error) {
    setSubmitting instanceof Function && setSubmitting(false)
    yield captureError({ error, action, setErrors, failedAction: types.VERIFY_FAILURE })
  }
}

export default [linkSaga, verifySaga, activateSaga, checkActivationSaga]
