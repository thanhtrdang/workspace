import * as R from 'ramda'
import moment from 'moment'
import utils from 'helpers/utils'

class Tournament {
  sort = (field, order = 'asc') => tournament => {
    switch (field) {
      case 'status':
        const diff = (t1, t2) => (t1.status === 'active' ? -1 : 1)
        const sortedList = R.sort(diff, tournament)

        if (order === 'desc') {
          return R.reverse(sortedList)
        }
        return sortedList
      case 'end_date':
        const dateDiff = (t1, t2) => (moment(t1.ends_at).isBefore(moment(t2.ends_at)) ? -1 : 1)
        const dateSortedList = R.sort(dateDiff, tournament)

        if (order === 'desc') {
          return R.reverse(dateSortedList)
        }
        return dateSortedList
      default:
        return tournament
    }
  }

  getRemainder = (oldList, list) =>
    utils.is_populated(oldList) ? oldList.filter(tourney => R.findIndex(R.propEq('id', tourney.id))(list) === -1) : []
}

export default new Tournament()
