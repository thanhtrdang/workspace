export const load = name => {
  try {
    const item = localStorage.getItem(name)
    if (item !== null) {
      return JSON.parse(item)
    }
  } catch (err) {
    console.log(err)
  }
}

export const save = (name, obj) => {
  try {
    if (name === 'state') throw Error('Invalid name')
    const serializedObj = JSON.stringify(obj)
    localStorage.setItem(name, serializedObj)
  } catch (err) {
    console.log(err)
  }
}

export const loadState = () => {
  try {
    const serializedState = localStorage.getItem('state')
    if (serializedState === null) {
      return undefined
    }
    return JSON.parse(serializedState)
  } catch (err) {
    return undefined
  }
}

export const saveState = state => {
  try {
    const serializedState = JSON.stringify(state)
    localStorage.setItem('state', serializedState)
  } catch (err) {
    // TODO: Log errors
  }
}
