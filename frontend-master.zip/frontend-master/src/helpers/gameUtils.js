import { games } from 'var'

export const gameUtils = {
  // Validate if a game is in used
  validate: game_name => games.some(item => item.name === game_name),

  // Return an array of all games in used
  getAll: _ => games.filter(item => item.is_active).map(item => item.name),

  getDefault: _ => {
    const defaultGame = games.find(item => item.is_default)
    return (defaultGame && defaultGame.name) || games[0].name
  },
}
