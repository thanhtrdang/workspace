import { routes } from 'var'
import { history } from './configureStore'

export const findNextRoute = ({ retarget, base }) => {
  if (retarget && retarget !== routes.login && retarget !== routes.signup) {
    return retarget
  } else if (
    history &&
    history.location &&
    history.location.state &&
    history.location.state.from &&
    history.location.state.from.pathname &&
    history.location.state.from.pathname !== routes.login &&
    history.location.state.from.pathname !== routes.signup
  ) {
    return history.location.state.from.pathname
  } else {
    return base
  }
}

export const retargetTo = ({ retarget, base }) => {
  const nextRoute = findNextRoute({ retarget, base })
  history.push(nextRoute)
}
