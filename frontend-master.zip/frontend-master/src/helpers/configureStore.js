import { applyMiddleware, compose, createStore } from 'redux'

import { devToolsEnhancer } from 'redux-devtools-extension'

import { createBrowserHistory } from 'history'
import { createLogger } from 'redux-logger'
import { routerMiddleware } from 'connected-react-router'
import { loadState, saveState } from './localStorage'
import createSagaMiddleware from 'redux-saga'

import Sagat from '_ducks/sagas'
import { rootReducer } from '_ducks/reducers'

const logger = createLogger({})
export const history = createBrowserHistory()

export const configureStore = () => {
  const persistedState = loadState()

  const sagaMiddleware = createSagaMiddleware()
  const middleware = [routerMiddleware(history), sagaMiddleware]
  if (process.env.NODE_ENV !== 'production') {
    middleware.push(logger)
  }

  const store = createStore(
    rootReducer(history),
    persistedState,
    compose(
      applyMiddleware(...middleware),
      devToolsEnhancer(),
    ),
  )

  // TODO: Throttle w/ lodash
  store.subscribe(() => {
    saveState({
      auth: store.getState().auth,
      profile: store.getState().profile,
      wallet: store.getState().wallet,
      pref: store.getState().pref,
      apex: store.getState().apex,
      apex_tournament: store.getState().apex_tournament,
      pubg_player: store.getState().pubg_player,
      pubg_tournament: store.getState().pubg_tournament,
    })
  })

  sagaMiddleware.run(Sagat)

  return store
}

export default configureStore
