import * as Sentry from '@sentry/browser'
import { SENTRY_DSN } from 'var'

class Tracker {
  init = props => {
    props
      ? Sentry.init(props)
      : Sentry.init({
          dsn: SENTRY_DSN,
          maxBreadcrumbs: 0,
        })
  }

  setUser = props => {
    Sentry.configureScope(scope => {
      scope.setUser(props)
    })
  }

  clear = _ => {
    Sentry.configureScope(scope => {
      scope.clear()
    })
  }

  log = ({ error, action, data }) => {
    const requestedURL = error && error.config && error.config.url
    const requestedMethod = error && error.config && error.config.method
    const longErrorMessage = error && error.stack

    Sentry.configureScope(scope => {
      scope.setExtra('Error Request Method', requestedMethod)
      scope.setExtra('Error URL', requestedURL)
      scope.setExtra('Error Long Message', longErrorMessage)

      action && scope.setExtra('Payload', JSON.stringify(action))
      data && scope.setExtra('Data', data)

      if (error && error.response) {
        scope.setExtra('Error Code', error.response.status)
        scope.setExtra('Error Code Message', error.response.statusText)
        const xhr =
          !!error.response.request && JSON.stringify(error.response.request.__sentry_xhr__)
        xhr && scope.setExtra('Error XHR', xhr)
      }
    })
    // action && action.type ? Sentry.captureException(action.type) : Sentry.captureException(error)
    error.message === 'Network Error'
      ? Sentry.captureException(error.message)
      : requestedURL
      ? Sentry.captureException(
          `${requestedMethod.toString().toUpperCase()} - ${requestedURL} - ${error.message}`,
        )
      : Sentry.captureException(error.message || error)
  }
}

export default new Tracker()
