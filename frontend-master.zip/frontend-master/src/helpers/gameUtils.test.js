import { gameUtils } from './gameUtils'

test('validate()', () => {
  expect(gameUtils.validate('pubg')).toEqual(true)
  expect(gameUtils.validate('apex')).toEqual(true)
  expect(gameUtils.validate('dota')).toEqual(false)
})

test('getAll()', () => {
  const expectedResult = ['pubg', 'apex']
  const result = gameUtils.getAll()
  expect(Array.isArray(expectedResult)).toBe(true) // result should be an array
  expect(expectedResult).toEqual(expect.arrayContaining(result)) // result should be equal to the expected one
})

test('getDefault()', () => {
  const result = gameUtils.getDefault()
  expect(result).toBeDefined() // result should be defined
  expect(typeof result).toBe('string') // result should be a string
})
