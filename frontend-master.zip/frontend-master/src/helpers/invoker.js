import { select, call } from 'redux-saga/effects'
import { get_token } from '_ducks/reducers'
import api from 'helpers/api'

const error401 = {
  response: {
    status: 401,
    statusText: 'Unauthorize. Please login to continue.',
  },
}

/* Generate async services -- used by sagas */
export const invoke = function*(service, data) {
  const token = yield select(get_token)
  // Stop request if not authorized, should throw exception later.
  if (service.secure && !token) {
    throw error401
  }

  return yield call(makeRequest, {
    url: `${api.baseUrl}/${service.url}`,
    header: service.secure ? createHeaderFromToken(token) : '',
    method: service.method || 'get',
    data,
  })
}

/* Generate async services -- used by react */
export const generateAsyncRequest = async ({ service, token, data }) => {
  if (service.secure && !token) {
    throw error401
  }

  return await makeRequest({
    url: `${api.baseUrl}/${service.url}`,
    header: service.secure ? createHeaderFromToken(token) : '',
    method: service.method || 'get',
    data,
  })
}

export const makeRequest = async ({ url, header, method, data }) => {
  const res =
    method === 'get'
      ? await api.get({ url, header, data })
      : method === 'post'
      ? await api.post({ url, header, data })
      : await api.put({ url, header, data })
  return res.data
}

export const createHeaderFromToken = token => ({
  headers: { Authorization: `Token ${token}` },
})
