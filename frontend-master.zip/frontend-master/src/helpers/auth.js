import { select } from 'redux-saga/effects'

import { get_token } from '_ducks/reducers'

export function* authHeader(extra) {
  const token = yield select(get_token)
  if (!token) {
    return {}
  } else if (!extra || extra instanceof Object === false) {
    return { headers: { Authorization: `Token ${token}` } }
  } else {
    let headers = { Authorization: `Token ${token}` }
    for (let item in extra) {
      headers[item] = extra[item]
    }
    return { headers: headers }
  }
}
