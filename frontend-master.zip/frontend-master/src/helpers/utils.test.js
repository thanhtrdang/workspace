import u from './utils'

test('Detect populated array', () => {
  const arr = [1, 2, 3, 4, { a: 'b' }]
  expect(u.is_populated(arr)).toBe(true)
})

test('Detect empty array', () => {
  const arr = []
  expect(u.is_populated(arr)).toBe(false)
})

test('Array to object', () => {
  const arr = [{ id: 1, name: 'Harry' }, { id: 2, name: 'Ron' }]
  const obj = {
    1: {
      id: 1,
      name: 'Harry',
    },
    2: {
      id: 2,
      name: 'Ron',
    },
  }
  expect(u.array_to_object(arr)).toEqual(obj)
})
