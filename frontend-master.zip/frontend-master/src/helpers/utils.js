class Utils {
  /*
   * In use
   */
  is_populated = arr => arr && arr instanceof Array && arr.length > 0

  array_to_object = arr => arr.reduce((result, element) => ({ ...result, [element.id]: element }), {})

  filter_object_by_ids = obj => ids =>
    Object.keys(obj)
      .filter(key => ids.includes(key))
      .map(key => obj[key])

  /**
   * Not in use, need to test before implementing
   */
  get_ids_from_array = arr => (this.is_populated(arr) ? arr.map(tourney => tourney.id) : [])
}

export default new Utils()
