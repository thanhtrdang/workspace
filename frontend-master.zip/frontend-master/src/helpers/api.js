import axios from 'axios'

class Api {
  constructor(apiUrl, env) {
    this.baseUrl = apiUrl
    this.env = env
  }

  refine = url =>
    this.env === 'development' || this.env === 'debug'
      ? url.replace(/^https:\/\//i, 'http://')
      : url.replace(/^http:\/\//i, 'https://')

  get = async ({ url, header }) => {
    const response = await axios.get(this.refine(url), header)
    return response
  }

  post = async ({ url, data, header }) => {
    const response = await axios.post(this.refine(url), data, header)
    return response
  }

  put = async ({ url, data, header }) => {
    const response = await axios.put(this.refine(url), data, header)
    return response
  }
}

export default new Api(process.env.REACT_APP_API_URL, process.env.NODE_ENV)
