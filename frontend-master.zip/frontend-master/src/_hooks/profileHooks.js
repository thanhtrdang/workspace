import { generateAsyncRequest } from 'helpers/invoker'
import { services } from '_ducks/services'

export const fetchPubgStats = async ({ username, callback, setLoading, handleError }) => {
  try {
    const results = await generateAsyncRequest({
      service: services.user.stats(username),
    })
    setLoading instanceof Function && setLoading(false)
    const stats = [
      { title: 'Chicken Dinners', content: results.wins },
      { title: 'Win Rate', content: results.win_rate },
      { title: 'Kills', content: results.kills },
      { title: 'K/D Ratio', content: results.kd_ratio },
      { title: 'Top 10s', content: results.top_tens },
      { title: 'Headshots', content: results.headshot_kills },
    ]
    callback instanceof Function && callback(stats)
  } catch (error) {
    handleError instanceof Function && handleError({ error, name: 'PUBG_STATS__FETCH' })
    setLoading instanceof Function && setLoading(false)
    return undefined
  }
}
