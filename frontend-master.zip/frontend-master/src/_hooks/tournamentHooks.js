import { generateAsyncRequest } from 'helpers/invoker'
import { services } from '_ducks/services'

export const fetchTournaments = async ({ filter, callback, setLoading, handleError, mount }) => {
  try {
    const tournaments = await generateAsyncRequest({
      service: services.tournament.requestList(filter),
    })
    setLoading instanceof Function && setLoading(false)
    callback instanceof Function && callback(tournaments)
  } catch (error) {
    handleError instanceof Function && handleError({ error, name: 'PUBG_TOURNAMENTS__FETCH' })
    setLoading instanceof Function && setLoading(false)
    return undefined
  }
}
