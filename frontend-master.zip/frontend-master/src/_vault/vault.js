import * as pubg from './pubgVault'
import * as apex from './apexVault'
import { combineReducers } from 'redux'

export const initialState = {
  pubg: pubg.initialState,
  apex: apex.initialState,
}

export const actions = { pubg: pubg.actions, apex: apex.actions }

export const selectors = { pubg: pubg.selectors, apex: apex.selectors }

export const reducer = combineReducers({ pubg: pubg.reducer, apex: apex.reducer })
