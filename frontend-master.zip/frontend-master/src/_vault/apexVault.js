export const initialState = {
  active_tournaments: [],
  special_tournaments: [],
}

export const types = {
  SET_APEX_ACTIVE_TOURNAMENTS: {
    name: 'SET_APEX_ACTIVE_TOURNAMENTS',
    exec: (state, action) => ({ ...state, active_tournaments: action.tournaments }),
  },
  SET_APEX_SPECIAL_TOURNAMENTS: {
    name: 'SET_APEX_SPECIAL_TOURNAMENTS',
    exec: (state, action) => ({ ...state, special_tournaments: action.tournaments }),
  },
}

export const reducer = (state = initialState, action) =>
  types[action.type] ? types[action.type].exec(state, action) : state

export const actions = {
  setActiveTournaments: tournaments => ({ type: types.SET_APEX_ACTIVE_TOURNAMENTS.name, tournaments }),
  setSpecialTournaments: tournaments => ({ type: types.SET_APEX_SPECIAL_TOURNAMENTS.name, tournaments }),
}

export const selectors = {
  getActiveTournaments: state => state.apex.active_tournaments,
  getSpecialTournaments: state => state.apex.special_tournaments,
}
