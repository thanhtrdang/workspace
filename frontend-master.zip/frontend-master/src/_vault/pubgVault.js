export const initialState = {
  active_tournaments: [],
  special_tournaments: [],
}

export const types = {
  SET_PUBG_ACTIVE_TOURNAMENTS: {
    name: 'SET_PUBG_ACTIVE_TOURNAMENTS',
    exec: (state, action) => ({ ...state, active_tournaments: action.tournaments }),
  },
  SET_PUBG_SPECIAL_TOURNAMENTS: {
    name: 'SET_PUBG_SPECIAL_TOURNAMENTS',
    exec: (state, action) => ({ ...state, special_tournaments: action.tournaments }),
  },
  SET_PUBG_STATS: {
    name: 'SET_PUBG_STATS',
    exec: (state, action) => ({ ...state, stats: action.stats }),
  },
}

export const reducer = (state = initialState, action) =>
  types[action.type] ? types[action.type].exec(state, action) : state

export const actions = {
  setActiveTournaments: tournaments => ({ type: types.SET_PUBG_ACTIVE_TOURNAMENTS.name, tournaments }),
  setSpecialTournaments: tournaments => ({ type: types.SET_PUBG_SPECIAL_TOURNAMENTS.name, tournaments }),
  setStats: stats => ({ type: types.SET_PUBG_STATS.name, stats }),
}

export const selectors = {
  getActiveTournaments: state => state.pubg.active_tournaments,
  getSpecialTournaments: state => state.pubg.special_tournaments,
  getStats: state => state.pubg.stats,
}
