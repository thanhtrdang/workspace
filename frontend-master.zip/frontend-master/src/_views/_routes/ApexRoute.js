import React, { useContext, useEffect } from 'react'
import { AuthContext } from '_contexts'

import { Redirect, Route } from 'react-router-dom'
import { routes } from 'var'
import { gamePaths } from 'var'

import { connect } from 'react-redux'
import { get_my_apex_tournament_ids, apex_tournament_actions, is_apex_activated,has_client_ever_run  } from '_ducks/reducers'

const ApexRouteComponent = ({ component: Component, ...rest, myTournamentIds, requestMyTournaments, isApexActive, hasClientEverRun }) => {
  const { authed } = useContext(AuthContext)

  useEffect(_ => {
    authed && myTournamentIds === undefined && requestMyTournaments()
  }, [])
  
  return (
    <Route
      {...rest}
      render={props => (
        !authed 
        ? <Redirect to={routes.signup} /> 
        : !isApexActive
        ? <Redirect to={gamePaths.apex.welcome} />
        : myTournamentIds === undefined 
        ? ''
        : Array.isArray(myTournamentIds) && myTournamentIds.length === 0 
        ? <Redirect to={gamePaths.apex.tutorial_tournament} />
        : !hasClientEverRun 
        ? <Redirect to={gamePaths.apex.client} />
        :<Component {...props} />
        )}
    />
  )
}

const mapState = state => ({
  myTournamentIds: get_my_apex_tournament_ids(state),
  isApexActive: is_apex_activated(state),
  hasClientEverRun: has_client_ever_run(state),
})

const mapDispatch = dispatch => ({
  requestMyTournaments: _ => dispatch(apex_tournament_actions.requestMyTournaments()),
})
export const ApexRoute = connect(mapState, mapDispatch)(ApexRouteComponent)
