import React, { useContext, useEffect } from 'react'
import { AuthContext } from '_contexts'

import { Redirect, Route } from 'react-router-dom'
import { routes } from 'var'
import { gamePaths } from 'var'

import { connect } from 'react-redux'
import { is_pubg_activated, is_pubg_linked, get_my_pubg_tournament_ids, pubg_tournament_actions  } from '_ducks/reducers'


const PubgRouteComponent = ({ component: Component, ...rest, isPubgActivated, isPubgLinked, myTournamentIds, requestMyTournaments }) => {
  const { authed } = useContext(AuthContext)
  
  useEffect(_ => {
    authed && myTournamentIds === undefined && requestMyTournaments()
  }, [])

  return (
    <Route
      {...rest}
      render={props => (
        !authed 
        ? <Redirect to={{ pathname: routes.signup }} /> 
        : isPubgActivated === undefined || isPubgLinked === undefined
        ? ''
        : !isPubgActivated || !isPubgLinked
        ? <Redirect to={{pathname: gamePaths.pubg.welcome}} />
        : myTournamentIds === undefined 
        ? ''
        : Array.isArray(myTournamentIds) && myTournamentIds.length === 0 
        ? <Redirect to={gamePaths.pubg.tutorial_tournament} />
        :<Component {...props} />
        )}
    />
  )
}
const mapState = state => ({
  isPubgActivated: is_pubg_activated(state),
  isPubgLinked: is_pubg_linked(state),
  myTournamentIds: get_my_pubg_tournament_ids(state),
})

const mapDispatch = dispatch => ({
  requestMyTournaments: _ => dispatch(pubg_tournament_actions.requestMyTournaments()),
})
export const PubgRoute = connect(mapState, mapDispatch)(PubgRouteComponent)
