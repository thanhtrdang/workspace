import React, { useContext } from 'react'
import { AuthContext } from '_contexts'

import { Redirect, Route } from 'react-router-dom'
import { routes } from 'var'

export const PrivateRoute = ({ component: Component, ...rest }) => {
  const { authed } = useContext(AuthContext)
  return (
    <Route
      {...rest}
      render={props =>
        !authed ? (
          <Redirect to={{ pathname: routes.signup, state: { from: props.location } }} />
        ) : (
          <Component {...props} />
        )
      }
    />
  )
}
