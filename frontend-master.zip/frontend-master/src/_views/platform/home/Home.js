import React, { useContext } from 'react'
import { Redirect } from 'react-router-dom'
import { GameContext, AuthContext } from '_contexts'

import { GuestHome } from './guest/GuestHome'
import { SelectGame } from '../'

export const Home = _ => {
  const { path } = useContext(GameContext)
  const { authed } = useContext(AuthContext)

  return !authed ? <GuestHome /> : !path ? <SelectGame /> : !path.home ? '' : <Redirect to={path.home} />
}
