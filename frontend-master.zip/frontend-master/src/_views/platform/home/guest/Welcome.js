import React from 'react'

import { Link } from 'react-router-dom'

import { routes } from 'var'

import { Title, Button, Subtitle } from 'pepper'
import { DiscordIcon } from 'pepper/icons/DiscordIcon'

export const Welcome = _ => {
  return (
    <div className="welcome">
      <div className="welcome__inner">
        <Title size="huge" transform="uppercase">
          Enter for free, win cash prizes
        </Title>
        <Subtitle size="large" font="stylish" color="white">
          Casual esports tournaments that anyone can win
        </Subtitle>
        <div className="welcome__buttons mt8">
          <div className="welcome__button">
            <Link to={{ pathname: routes.signup }}>
              <Button primary>SIGN UP FOR FREE</Button>
            </Link>
          </div>

          <div className="welcome__button">
            <Button className="discord">
              <DiscordIcon /> <span className="pl2">Chat with us on Discord</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
