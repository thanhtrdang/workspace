import React, { Fragment } from 'react'
import { Link } from 'react-router-dom'
import { generate } from 'shortid'

import { routes } from 'var'

import { PepperIcon } from '_components'
import { Title, Segment, Button, Subtitle } from 'pepper'

const boxes = [
  {
    icon: 'sign_add',
    title: 'Join a Tournament',
    subTitle: 'Enter a tournament through the main dashboard',
    className: 'get-started__box--1',
  },
  {
    icon: 'sign_stars',
    title: 'Play Games',
    subTitle: "Link your game account and we'll track your score",
    className: 'get-started__box--2',
  },
  {
    icon: 'sign_dollar',
    title: 'Win Cash',
    subTitle: 'By playing like you normally would',
    className: 'get-started__box--3',
  },
]

export const GetStarted = _ => (
  <div className="get-started pv9 ph6">
    <div>
      <Title size="big" align="center" margin={9} transform="uppercase">
        Getting started is easy
      </Title>
    </div>
    <div className="get-started__boxes">
      {boxes.map(box => (
        <Fragment key={generate()}>
          <Segment className={`get-started__box ${box.className}`}>
            <Title className="get-started__title" size="large2">
              {box.title}
            </Title>
            <Subtitle size="small">{box.subTitle}</Subtitle>
            <PepperIcon name={box.icon} customSize="4rem" noMargin className="get-started__box__icon" />
          </Segment>
        </Fragment>
      ))}
    </div>
    <div className="flex-center mt8">
      <Link to={routes.signup}>
        <Button primary>GET STARTED</Button>
      </Link>
    </div>
  </div>
)
