import React, { useState, useEffect, useContext } from 'react'
import { Link } from 'react-router-dom'

import { routes } from 'var'
import { Welcome } from './Welcome'
import { GetStarted } from './GetStarted'
import { SupportedGames } from './SupportedGames'
import { Title, Button } from 'pepper'

import { AsyncContext } from '_components'
import { TournamentGrid } from '../../../games/_shared/TournamentGrid/TournamentGrid'
import { fetchTournaments } from '_hooks'

export const GuestHome = _ => {
  const { handleError } = useContext(AsyncContext)
  const [loading, setLoading] = useState(true)
  const [tournaments, setTournaments] = useState([])

  const fetch = _ =>
    fetchTournaments({
      filter: { status: 'active' },
      callback: tournaments => Array.isArray(tournaments) && setTournaments(tournaments),
      setLoading,
      handleError,
    })

  useEffect(_ => {
    fetch()
  }, [])

  return (
    <div className="guest-home">
      <Welcome />
      <div className="guest-home__featured pv9 ph6">
        <Title size="big" margin={7} transform="uppercase">
          Featured Tournaments
        </Title>
        <TournamentGrid
          tournaments={tournaments.slice(0, 3)}
          loading={loading}
          handleCountdownFinish={fetch}
          center
          gameThumbnailVisible={true}
        />

        <div className="guest-home__see-more">
          <Link to={routes.signup}>
            <Button primary>SIGN UP FOR FREE</Button>
          </Link>
        </div>
      </div>
      <GetStarted />
      <SupportedGames />
    </div>
  )
}
