import React from 'react'

// import dota from 'images/landing-page/dota2_blend.png'
import fortnite from 'images/landing-page/apex_blend.png'
import pubg from 'images/landing-page/pubg_blend.png'
import { Title, Subtitle } from 'pepper'

export const SupportedGames = _ => (
  <div className="supported-games-section pv9 ph6">
    <Title size="big" margin={9} transform="uppercase">
      Current Games
    </Title>
    <div className="supported-games">
      <div className="supported-games__item">
        <img src={pubg} alt="pubg" />
        <Subtitle
          className="supported-games__text supported-games__text--active title"
          font="stylish"
          transform="uppercase">
          Available
        </Subtitle>
      </div>
      <div className="supported-games__item">
        <img src={fortnite} alt="apex" />
        <Subtitle
          className="supported-games__text supported-games__text--active title"
          font="stylish"
          transform="uppercase">
          Available
        </Subtitle>
      </div>
      {/* <div className="supported-games__item">
        <img src={dota} alt="dota" />
        <div className="supported-games__text title">Coming Soon</div>
      </div> */}
    </div>
  </div>
)
