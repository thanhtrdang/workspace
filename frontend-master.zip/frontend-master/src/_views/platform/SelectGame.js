import React, { useContext, useState } from 'react'
import { GameContext } from '_contexts'
import { generate } from 'shortid'
import { Segment, Title, Button } from 'pepper'
import { PepperIcon } from '_components'

export const SelectGame = _ => {
  const { saveGame, isPubgActivated, isApexActivated } = useContext(GameContext)
  const [option, setOption] = useState()

  return isPubgActivated === undefined || isApexActivated === undefined ? (
    ''
  ) : (
    <div className="select-game">
      <Segment center theme="light" className="select-game__segment">
        <Title>What game do you play?</Title>
        <div className="select-game__games">
          {games.map(game => (
            <div className="select-game__game" key={generate()} onClick={_ => setOption(game)}>
              {option === game ? (
                <PepperIcon name={`card_${game}`} customSize="9rem" noMargin />
              ) : (
                <PepperIcon name={`card_bw_${game}`} customSize="9rem" noMargin />
              )}
            </div>
          ))}
        </div>
        {option && <div className="select-game__more">You can always add more games later</div>}
      </Segment>

      {option && (
        <div className="select-game__button">
          <Button primary onClick={_ => saveGame(option)}>
            Continue
          </Button>
        </div>
      )}
    </div>
  )
}

const games = ['pubg', 'apex']
