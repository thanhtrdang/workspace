import React from 'react'
import { Title, Button, Divider, Subtitle } from 'pepper'

import { Redirect } from 'react-router-dom'
import { gamePaths } from 'var'

import { connect } from 'react-redux'
import { is_pubg_activated, is_pubg_linked, pubg_actions } from '_ducks/reducers'

import { PubgLink } from './PubgLink'

import { PepperIcon } from '_components'
import pubg_welcome from './images/Pubg_transparent.png'

const PubgWelcomeComponent = ({ isPubgActive, isPubgLinked, activatePubg }) => {
  return isPubgActive === undefined ? (
    ''
  ) : isPubgActive && isPubgLinked ? (
    <Redirect to={gamePaths.pubg.home} />
  ) : (
    <div className="pubg-welcome">
      <div className="pubg-welcome__segment">
        <img src={pubg_welcome} alt="pubg welcome" className="pubg-welcome__image" />
        <div className="pubg-welcome__content">
          <PepperIcon name="logo_pubg" size="huge" />
          <Divider invisible />
          <Title margin={1}>Enter now to receive</Title>
          <Title color="yellow" margin={2}>
            10,000 GLG
          </Title>
          <Subtitle>GLG is used to enter tournaments</Subtitle>
          {isPubgLinked ? <Button onClick={activatePubg}>Enter a tournament</Button> : <PubgLink />}
        </div>
      </div>
    </div>
  )
}

const mapState = state => ({
  isPubgActive: is_pubg_activated(state),
  isPubgLinked: is_pubg_linked(state),
})

const mapDispatch = dispatch => ({
  activatePubg: _ => dispatch(pubg_actions.activate()),
})

export const PubgWelcome = connect(
  mapState,
  mapDispatch,
)(PubgWelcomeComponent)
