import React, { useState, useEffect, useContext } from 'react'
import { Segment, Subtitle, Title } from 'pepper'
import { connect } from 'react-redux'
import {
  get_credit,
  get_credit_currency,
  is_loading,
  pubg_tournament_types as types,
  get_my_pubg_tournament_ids,
  is_pubg_activated,
  is_pubg_linked,
} from '_ducks/reducers'
import { pubg_tournament_actions } from '_ducks/reducers'

import { AsyncContext } from '_components'
import { TournamentGrid } from '../../../games/_shared/TournamentGrid/TournamentGrid'
import { fetchTournaments } from '_hooks'

import { Redirect } from 'react-router-dom'
import { gamePaths } from 'var'

import { StarIcon } from 'pepper/icons/StarIcon'

const PubgTutorialTournamentComponent = ({
  creditCurrency,
  requestMyPubgTournaments,
  my_loading,
  myPubgTournamentIds,
  isPubgActivated,
  isPubgLinked,
}) => {
  const { handleError } = useContext(AsyncContext)
  const [loading, setLoading] = useState(true)
  const [tournaments, setTournaments] = useState([])

  useEffect(_ => {
    let mount = true
    requestMyPubgTournaments()

    fetchTournaments({
      filter: { game: 'pubg', status: 'active' },
      callback: tournaments => {
        if (mount) {
          Array.isArray(tournaments) && setTournaments(tournaments)
          setLoading(false)
        }
      },
      handleError,
    })

    return _ => {
      mount = false
    }
  }, [])

  const alreadyJoinedTournament = Array.isArray(myPubgTournamentIds) && myPubgTournamentIds.length > 0

  return isPubgActivated === false || isPubgLinked === false || alreadyJoinedTournament ? (
    <Redirect to={gamePaths.pubg.home} />
  ) : loading || my_loading || myPubgTournamentIds === undefined ? (
    ''
  ) : (
    <div className="tutorial-tournament">
      <Segment theme="light" className="tutorial-tournament__segment">
        <Title>You have received</Title>
        <Title margin={8}>
          <StarIcon /> <span className="tutorial-tournament__amount"> 10,000 {creditCurrency}</span>
        </Title>
        <Subtitle margin={0}>Go ahead and enter a tournament!</Subtitle>
      </Segment>

      <TournamentGrid tournaments={tournaments} loading={loading} handleCountdownFinish={fetch} center />
    </div>
  )
}

const mapState = state => ({
  credit: get_credit(state),
  creditCurrency: get_credit_currency(state),
  my_loading: is_loading(state)([types.MY_REQUEST]),
  myPubgTournamentIds: get_my_pubg_tournament_ids(state),
  isPubgActivated: is_pubg_activated(state),
  isPubgLinked: is_pubg_linked(state),
})

const mapDispatch = dispatch => ({
  requestMyPubgTournaments: _ => dispatch(pubg_tournament_actions.requestMyTournaments()),
})

export const PubgTutorialTournament = connect(
  mapState,
  mapDispatch,
)(PubgTutorialTournamentComponent)
