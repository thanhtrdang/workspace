import React from 'react'
import { connect } from 'react-redux'
import { Form, Input, Field, Button } from 'pepper'
import { withFormik } from 'formik'
import * as Yup from 'yup'

import { get_user_id, pubg_actions } from '_ducks/reducers'

import { ValidationError } from '_components'

const PubgLinkComponent = ({ values, touched, errors, isSubmitting, handleChange, handleSubmit }) => {
  return (
    <Form onSubmit={handleSubmit}>
      <Field className="pubg-link__field">
        <Input
          placeholder="Enter your PUBG account name"
          name="name"
          value={values.name}
          onChange={handleChange}
          size="large"
          className="pubg-link__input"
        />
        <ValidationError errors={errors} touched={touched} field="name" />
        <ValidationError errors={errors} />
      </Field>
      <Button primary type="submit" disabled={isSubmitting}>
        Enter a tournament
      </Button>
    </Form>
  )
}

const PubgLinkFormik = withFormik({
  mapPropsToValues: props => ({
    name: '',
  }),
  validationSchema: Yup.object().shape({
    name: Yup.string().required('PUBG name is required.'),
  }),
  handleSubmit: ({ name }, { props, setErrors, setSubmitting }) => {
    props.submit(name, props.id, setErrors, setSubmitting)
  },
  displayName: 'PubgLinkForm',
})(PubgLinkComponent)

const mapState = state => ({
  id: get_user_id(state),
})

const mapDispatch = dispatch => ({
  submit: (name, id, setErrors, setSubmitting) => dispatch(pubg_actions.link(name, id, setErrors, setSubmitting)),
})

export const PubgLink = connect(
  mapState,
  mapDispatch,
)(PubgLinkFormik)
