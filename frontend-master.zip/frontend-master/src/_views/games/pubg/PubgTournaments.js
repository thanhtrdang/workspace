import React, { useState, useEffect, useContext } from 'react'
import { AuthContext } from '_contexts'

import { connect } from 'react-redux'
import {
  // State
  get_all_pubg_tournaments,
  get_my_pubg_tournament_ids,
  // Actions
  pubg_tournament_actions,
  // Loading
  is_loading,
  pubg_tournament_types as types,
} from '_ducks/reducers'

import { PubgTournamentsView } from './PubgTournamentsView'

export const PubgTournamentsComponent = ({
  tournaments,
  myTournamentIds,
  requestList,
  requestMyTournaments,
  loading,
}) => {
  const [init, setInit] = useState(false)
  const { authed } = useContext(AuthContext)

  useEffect(_ => {
    if (!init) {
      setInit(true)
      requestList()
      authed && requestMyTournaments()
    }
  })

  return <PubgTournamentsView tournaments={tournaments} myTournamentIds={myTournamentIds} loading={loading} />
}

const mapState = state => ({
  tournaments: get_all_pubg_tournaments(state),
  myTournamentIds: get_my_pubg_tournament_ids(state),
  loading: is_loading(state)([types.LIST_REQUEST, types.MY_REQUEST]),
})

const mapDispatch = dispatch => ({
  requestList: _ => dispatch(pubg_tournament_actions.requestList()),
  requestMyTournaments: _ => dispatch(pubg_tournament_actions.requestMyTournaments()),
})

export const PubgTournaments = connect(
  mapState,
  mapDispatch,
)(PubgTournamentsComponent)
