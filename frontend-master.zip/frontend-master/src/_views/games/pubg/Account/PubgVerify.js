import React from 'react'
import { connect } from 'react-redux'
import * as Yup from 'yup'
import { withFormik } from 'formik'
import { Title, Subtitle, Container, Form, Input, Field, Segment, Button } from 'pepper'

import tracker from 'helpers/tracker'
import { generateAsyncRequest } from 'helpers/invoker'

import { get_pubg_verification, is_pubg_linked, get_token, pubg_actions } from '_ducks/reducers'

import { ValidationError } from '_components'

import image from './images/linkaccount.png'
import { services } from '_ducks/services'

import { Redirect } from 'react-router-dom'
import { gamePaths } from 'var'

class PubgVerifyComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      code: '',
      preview: '',
    }
  }

  componentDidMount = async ({ token, isPubgLinked } = this.props) => {
    if (isPubgLinked) {
      try {
        const data = await generateAsyncRequest({
          service: services.pubg.requestCode,
          token,
        })
        this.setState({ code: data.codeword })
      } catch (error) {
        tracker.log({ error, action: { type: 'ASYNC_VERIFY_CODE_REQUEST' } })
      }
    }
  }

  handleImageChange = event => {
    this.setState({ preview: URL.createObjectURL(event.target.files[0]) })
    this.props.setFieldValue('image', event.target.files[0])
  }

  render = (
    { pubgVerifiedStatus, touched, errors, isSubmitting, handleSubmit } = this.props,
    { preview, code } = this.state,
    { handleImageChange } = this,
  ) =>
    pubgVerifiedStatus === undefined ? (
      ''
    ) : pubgVerifiedStatus === 'verified' ? (
      <Redirect to={{ pathname: gamePaths.pubg.home }} />
    ) : (
      <div className="page">
        <Container>
          {/* VERIFY PUBG */}
          <Segment>
            {pubgVerifiedStatus === 'pending' && (
              <Subtitle color="blue" size="large" font="stylish">
                Your account verification is in progress
              </Subtitle>
            )}
            <div className="verify-pubg">
              <div className="verify-pubg__intro">
                <Title size="small" font="stylish">
                  <span className="text--green">Verification Code: </span>
                  <span className="text--pink">{code}</span>
                </Title>
                <div className="verify-pubg__sample-image">
                  <img
                    src={image}
                    alt="verification-screenshot"
                    style={{ boxShadow: '0px 2px 6px 2px #00000082', width: '100%' }}
                  />
                </div>
                <p className="mt">
                  To verify your PUBG account, you need to upload a picture of your PUBG profile with the verification
                  code above. Pepper will use this information to determine the validity of your account.
                </p>
              </div>
              <Upload
                handleSubmit={handleSubmit}
                handleImageChange={handleImageChange}
                preview={preview}
                errors={errors}
                touched={touched}
                isSubmitting={isSubmitting}
                pubgVerifiedStatus={pubgVerifiedStatus}
              />
            </div>
          </Segment>
        </Container>
      </div>
    )
}

const PubgVerifyFormik = withFormik({
  mapPropsToValues: props => ({
    image: null,
  }),
  validationSchema: Yup.object().shape({
    image: Yup.mixed()
      .required('Image is required.')
      .test('fileSize', 'Image size must be less than 10MB', value => value && value.size < 10 * 1024 * 1024),
  }),
  handleSubmit: ({ image }, { props, setErrors, setSubmitting }) => {
    props.submit(image, setErrors, setSubmitting)
  },
  displayName: 'PubgVerifyForm',
})(PubgVerifyComponent)

const mapState = state => ({
  pubgVerifiedStatus: get_pubg_verification(state),
  isPubgLinked: is_pubg_linked(state),
  token: get_token(state),
})
const mapDispatch = dispatch => ({
  submit: (image, setErrors, setSubmitting) => dispatch(pubg_actions.verify(image, setErrors, setSubmitting)),
})

export const PubgVerify = connect(
  mapState,
  mapDispatch,
)(PubgVerifyFormik)

const Upload = ({ handleSubmit, handleImageChange, pubgVerifiedStatus, preview, errors, touched, isSubmitting }) => (
  <div>
    <Form onSubmit={handleSubmit}>
      <Field>
        <Subtitle>Upload your PUBG image here</Subtitle>
        <div className="submit-match__upload">
          {preview ? (
            <img alt="" src={preview} style={{ width: '100%' }} />
          ) : (
            <label htmlFor="image">
              <div className="submit-match__upload-placeholder ">
                <div className="submit-match__fake-upload-button">
                  <Title size="massive" nomargin>
                    +
                  </Title>
                </div>
              </div>
            </label>
          )}
        </div>

        <Input type="file" name="image" id="image" onChange={handleImageChange} />
      </Field>
      <ValidationError errors={errors} touched={touched} field="image" />
      <ValidationError errors={errors} />
      <div className="mv">
        <Button primary type="submit" disabled={isSubmitting}>
          Submit Image
        </Button>
      </div>
    </Form>
  </div>
)
