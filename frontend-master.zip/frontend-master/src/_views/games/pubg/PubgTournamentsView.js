import React from 'react'

import { TournamentsView } from '../_shared/PageTournaments/TournamentsView'

export const PubgTournamentsView = ({ tournaments, myTournamentIds, loading }) => (
  <div className="tournaments">
    {Array.isArray(tournaments) && (
      <TournamentsView tournaments={tournaments} myTournamentIds={myTournamentIds} loading={loading} />
    )}
  </div>
)
