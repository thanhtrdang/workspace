import React from 'react'
import { Link } from 'react-router-dom'
import { Button } from 'pepper'
import { gamePaths } from 'var'
import { WarningIcon } from 'pepper/icons/WarningIcon'

export const PubgVerificationReminder = _ => (
  <div className="tournament-instance-banner">
    <WarningIcon />
    <span className="pubg-verification-reminder__text">
      You must verify your account in order for your matches to be tracked and to be eligible for rewards
    </span>
    <Link to={gamePaths.pubg.verify} className="pubg-verification-reminder__button">
      <Button primary>Verify account</Button>
    </Link>
  </div>
)
