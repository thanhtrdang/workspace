import React, { useState, useEffect } from 'react'
import { connect } from 'react-redux'
import {
  get_pubg_tournament,
  get_username,
  get_pubg_participants,
  is_loading,
  pubg_leaderboard_actions,
  pubg_leaderboard_types as types,
} from '_ducks/reducers'

import { Leaderboard_PS } from './Leaderboard_PS'

const LeaderboardComponent = ({ match, tournament, user, requestLeaderboard, participants, loading }) => {
  const [init, setInit] = useState(false)

  useEffect(_ => {
    if (!init) {
      const id = match && match.params && match.params.id
      requestLeaderboard(id)
      setInit(true)
    }
  })

  return participants && participants.data ? (
    <Leaderboard_PS tournament={tournament} user={user} participants={participants.data} loading={loading} />
  ) : (
    ''
  )
}

const mapState = (
  state,
  {
    match: {
      params: { id },
    },
  },
) => {
  return {
    tournament: get_pubg_tournament(state, parseInt(id, 10)),
    user: get_username(state),
    participants: get_pubg_participants(state, id),
    loading: is_loading(state)([types.PARTICIPANTS_REQUEST]),
  }
}

const mapDispatch = dispatch => ({
  requestLeaderboard: id => dispatch(pubg_leaderboard_actions.request(id)),
})

export const Leaderboard = connect(
  mapState,
  mapDispatch,
)(LeaderboardComponent)
