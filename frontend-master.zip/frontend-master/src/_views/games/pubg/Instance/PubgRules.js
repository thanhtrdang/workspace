import React from 'react'
import ordinal from 'ordinal-js'
import { generate } from 'shortid'
import { Segment } from 'pepper'

import { OmniTable } from '_components'
import { Subtitle } from 'pepper'

const rules = [
  {
    title: `General Rules`,
    contents: [
      `Play as many games as you want.`,
      `Only your top games are used for scoring.`,
      `Play any game mode (solo, duo, three-man squad, or squad.)`,
      `Must be FPP.`,
      `You can play in tournaments simultaneously, and your top scores are counted across tournaments.`,
      `You must verify your PUBG account and play at least one match during that tournament's duration to be eligible to win a prize.`,
    ],
  },

  {
    title: `Daily Rules`,
    contents: [
      `Top 3 Match Scores are used for scoring.`,
      `Tournaments start at 00:00 GMT and end 24 hours later at 11:59 GMT.`,
    ],
  },

  {
    title: `Weekly Rules`,
    contents: [
      `Top 7 Match Scores are used for scoring.`,
      `Tournaments start on Monday at 00:00 GMT and end 7 days later at 11:59 GMT.`,
    ],
  },
  {
    title: `Ties`,
    contents: [
      `If a tie occurs, it will be resolved by the following tie-breakers in the following order:`,
      `  1. Total kills`,
      `  2. Average placement of recorded matches`,
      `  3. If the above two tie-breakers don't produce a winner, then a new quick-match tournament will be created, and the winner of the
quick-match will break the tie. Quick matches will continue until a winner is produced.`,
    ],
  },
  {
    title: `Cheating`,
    contents: [
      `All cheaters will be banned from our platform, and our legal team will commence a claim to recoup any prize money awarded and the legal
expenses for doing so. Recouped prize money will be redistributed amongst the remaining players in the tournament. If you
suspect someone is cheating, please report them to us at support@pepper.gg.`,
    ],
  },
]

const placementRows = []
for (let i = 0; i < 25; i++) {
  placementRows.push(i + 1)
}

const dataList = [
  placementRows.map(index => ({
    rank: `${ordinal.toOrdinal(index)}`,
    points: 101 - index,
  })),
  placementRows.map(index => ({
    rank: `${ordinal.toOrdinal(index + 25)}`,
    points: 101 - index - 25,
  })),
  placementRows.map(index => ({
    rank: `${ordinal.toOrdinal(index + 50)}`,
    points: 101 - index - 50,
  })),
  placementRows.map(index => ({
    rank: `${ordinal.toOrdinal(index + 75)}`,
    points: 101 - index - 75,
  })),
]

const frame = [
  {
    header: 'Rank',
    content: props => props.rank,
  },
  {
    header: 'Point',
    content: props => (
      <span className="tournament-rules__rule__content__points">
        {props.points} {props.points > 1 ? 'points' : 'point'}
      </span>
    ),
  },
]

const scoringRules = [
  {
    title: `Match Score`,
    contents: [
      `Your Match Score is equal to the sum of your total Kill Score and your Placement Score. In Duo, 3-man Squad, and Squad modes, only your personal kills and placement are counted towards your Match Score.`,
    ],
  },
  {
    title: `Kill Score`,
    contents: [
      `Each kill is worth 10 points.`,
      `Your Kill Score is the product of your individual kills and the points per kill. For example, if you get 5 kills in a match, and each kill is worth 10 points then, 5 x 10 = 50 for a Kill Score of 50.`,
    ],
  },
]

const generateRule = rule => (
  <div key={generate()}>
    <div className="tournament-rules__rule-list">
      <div className="tournament-rules__rule">
        <Subtitle size="big" color="green">
          {rule.title}
        </Subtitle>
        {rule.contents.map(content => (
          <p key={generate()} className="tournament-rules__rule__content">
            {content}
          </p>
        ))}
      </div>
    </div>
  </div>
)

const rulesCol1 = rules.filter((rule, index) => index <= rules.length / 2).map(rule => generateRule(rule))

const rulesCol2 = rules.filter((rule, index) => index > rules.length / 2).map(rule => generateRule(rule))

export const PubgRules = _ => (
  <div className="tournament-rules">
    <Segment size="large" theme="light">
      <div>
        {rulesCol1}
        {rulesCol2}
      </div>

      <div className="tournament-rules__rule-list">
        <div className="tournament-rules__rule">
          <Subtitle size="big" color="green">
            Scoring Rules
          </Subtitle>
          {scoringRules.map(rule => (
            <div key={generate()} className="tournament-rules__sub-rule">
              <Subtitle color="pink">{rule.title}</Subtitle>
              {rule.contents.map(content => (
                <p key={generate()} className="tournament-rules__rule__content">
                  {content}
                </p>
              ))}
            </div>
          ))}
          <div className="tournament-rules__placement-score">
            <Subtitle color="pink">Placement Score</Subtitle>
            <div className="tournament-rules__sub-rule">Placement Score is as follows:</div>
            <div className="tournament-rules__score-table">
              {dataList.map(data => (
                <div key={generate()}>
                  <OmniTable data={data} frame={frame} pageSize={25} />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Segment>
  </div>
)
