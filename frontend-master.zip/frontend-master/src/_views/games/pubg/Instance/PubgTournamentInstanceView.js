import React, { Fragment } from 'react'
import { TournamentInstance } from '../../_shared/TournamentInstance/TournamentInstance'

import { gamePaths } from 'var'
import { Switch, Route } from 'react-router-dom'
import { OmniTab } from '_components'
import { PrivateRoute } from '_views/_routes'

import { TournamentMatches } from '_containers/Matches'
import { PubgRules } from './PubgRules'
import { Leaderboard } from './Leaderboard'
import { PubgVerificationReminder } from './PubgVerificationReminder'

export const PubgTournamentInstanceView = ({
  authed,
  tournament,
  myTournamentIds,
  loading,
  requestTournamentInstance,
  requestMyTournaments,
  endTournament,
  join,
  vericationReminderVisible,
}) => {
  const pubgTabs = tournament && (
    <OmniTab className="page-tournament-instance__tab-section">
      <OmniTab.Bar>
        <OmniTab.Link exact to={addTabState(`${gamePaths.pubg.tournaments}/${tournament.id}`)}>
          Leaderboard
        </OmniTab.Link>
        <OmniTab.Link to={addTabState(`${gamePaths.pubg.tournaments}/${tournament.id}/rules`)}>Rules</OmniTab.Link>
        {authed && (
          <OmniTab.Link to={addTabState(`${gamePaths.pubg.tournaments}/${tournament.id}/matches`)}>
            Matches
          </OmniTab.Link>
        )}
      </OmniTab.Bar>

      <OmniTab.Content>
        <Switch>
          <Route path={gamePaths.pubg.tournament_instance} exact component={Leaderboard} />
          <Route path={gamePaths.pubg.tournament_rules} component={PubgRules} />
          <PrivateRoute path={gamePaths.pubg.tournament_matches} component={TournamentMatches} />
        </Switch>
      </OmniTab.Content>
    </OmniTab>
  )

  return (
    <Fragment>
      <TournamentInstance
        authed={authed}
        tournament={tournament}
        myTournamentIds={myTournamentIds}
        loading={loading}
        requestTournamentInstance={requestTournamentInstance}
        requestMyTournaments={requestMyTournaments}
        endTournament={endTournament}
        tabs={pubgTabs}
        join={join}
        banner={vericationReminderVisible && <PubgVerificationReminder />}
      />
    </Fragment>
  )
}

const addTabState = link => ({
  pathname: link,
  state: { tab: true },
})
