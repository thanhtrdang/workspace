import React, { useContext } from 'react'

import { AuthContext } from '_contexts'

import { Redirect } from 'react-router-dom'
import { gamePaths } from 'var'
import utils from 'helpers/utils'

// Redux
import { connect } from 'react-redux'
import {
  get_pubg_tournament,
  get_my_pubg_tournament_ids,
  get_pubg_verification,
  pubg_tournament_actions,
  is_loading,
  pubg_tournament_types as types,
  is_pubg_activated,
  is_pubg_linked,
} from '_ducks/reducers'

import { PubgTournamentInstanceView } from './PubgTournamentInstanceView'

export const PubgTournamentInstanceComponent = ({
  pubgVerification,
  myTournamentIds,
  requestTournamentInstance,
  requestMyTournaments,
  endTournament,
  tournament,
  loading,
  join,
  isPubgActivated,
  isPubgLinked,
}) => {
  const { authed } = useContext(AuthContext)

  const isUserVerificationPending = pubgVerification !== undefined && pubgVerification !== 'verified'
  const hasUserJoinedTournament = utils.is_populated(myTournamentIds)

  const vericationReminderVisible = isUserVerificationPending && hasUserJoinedTournament

  return isPubgActivated === false || isPubgLinked === false ? (
    <Redirect to={{ pathname: gamePaths.pubg.home }} />
  ) : (
    <PubgTournamentInstanceView
      authed={authed}
      tournament={tournament}
      myTournamentIds={myTournamentIds}
      loading={loading}
      requestTournamentInstance={requestTournamentInstance}
      requestMyTournaments={requestMyTournaments}
      endTournament={endTournament}
      join={join}
      vericationReminderVisible={vericationReminderVisible}
    />
  )
}
const mapState = (state, ownProps) => ({
  tournament: get_pubg_tournament(state, parseInt(ownProps.match.params.id, 10)),
  myTournamentIds: get_my_pubg_tournament_ids(state),
  loading: is_loading(state)([types.REQUEST, types.MY_REQUEST]),
  pubgVerification: get_pubg_verification(state),
  isPubgActivated: is_pubg_activated(state),
  isPubgLinked: is_pubg_linked(state),
})

const mapDispatch = dispatch => ({
  requestTournamentInstance: id => dispatch(pubg_tournament_actions.requestTournament(parseInt(id, 10))),
  requestMyTournaments: _ => dispatch(pubg_tournament_actions.requestMyTournaments()),
  endTournament: id => dispatch(pubg_tournament_actions.endTournament(parseInt(id, 10))),
  join: (id, setErrors, setSubmitting) =>
    dispatch(pubg_tournament_actions.joinTournament(parseInt(id, 10), setErrors, setSubmitting)),
})

export const PubgTournamentInstance = connect(
  mapState,
  mapDispatch,
)(PubgTournamentInstanceComponent)
