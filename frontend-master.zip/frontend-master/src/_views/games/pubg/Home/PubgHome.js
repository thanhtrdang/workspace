import React, { useContext } from 'react'
import { GameHome } from '../../_shared/PageHome/GameHome'
import { PubgHomeStats } from './PubgHomeStats'
import { Divider } from 'pepper'

import { VaultContext } from '_contexts'

import { connect } from 'react-redux'
import { get_my_pubg_tournament_ids, pubg_tournament_actions } from '_ducks/reducers'

export const PubgHomeComponent = ({ myTournamentIds, requestMyTournaments }) => {
  const { state, dispatch, selectors, actions } = useContext(VaultContext)
  const specialTournaments = selectors.pubg.getSpecialTournaments(state)
  const activeTournaments = selectors.pubg.getActiveTournaments(state)
  const setSpecialTournaments = tournaments => dispatch(actions.pubg.setSpecialTournaments(tournaments))
  const setActiveTournaments = tournaments => dispatch(actions.pubg.setActiveTournaments(tournaments))

  return (
    <div className="main-inner">
      <PubgHomeStats />
      <Divider invisible size="large" />
      <GameHome
        game="pubg"
        specialTournaments={specialTournaments}
        activeTournaments={activeTournaments}
        setSpecialTournaments={setSpecialTournaments}
        setActiveTournaments={setActiveTournaments}
        myTournamentIds={myTournamentIds}
        requestMyTournaments={requestMyTournaments}
      />
    </div>
  )
}

const mapState = state => ({
  myTournamentIds: get_my_pubg_tournament_ids(state),
})

const mapDispatch = dispatch => ({
  requestMyTournaments: _ => dispatch(pubg_tournament_actions.requestMyTournaments()),
})

export const PubgHome = connect(
  mapState,
  mapDispatch,
)(PubgHomeComponent)
