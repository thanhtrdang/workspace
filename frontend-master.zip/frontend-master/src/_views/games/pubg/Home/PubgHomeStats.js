import React, { useState, useEffect, useContext } from 'react'
import { AsyncContext } from '_components'
import { VaultContext } from '_contexts'

import { PubgHomeStatsView } from './PubgHomeStatsView'
import { fetchPubgStats } from '_hooks'

import { connect } from 'react-redux'
import { get_username } from '_ducks/reducers'

export const PubgHomeStatsComponent = ({ username }) => {
  const { state, dispatch, selectors, actions } = useContext(VaultContext)
  const { handleError } = useContext(AsyncContext)
  const [loading, setLoading] = useState(true)

  const stats = selectors.pubg.getStats(state)
  const setStats = stats => dispatch(actions.pubg.setStats(stats))

  useEffect(
    _ => {
      let mount = true
      username &&
        fetchPubgStats({
          username,
          setLoading,
          handleError,
          callback: stats => {
            if (mount) {
              setStats(stats)
            }
          },
        })

      return _ => {
        mount = false
      }
    },
    [username],
  )
  return <PubgHomeStatsView stats={stats} loading={loading} />
}

const mapState = state => ({
  username: get_username(state),
})

export const PubgHomeStats = connect(mapState)(PubgHomeStatsComponent)
