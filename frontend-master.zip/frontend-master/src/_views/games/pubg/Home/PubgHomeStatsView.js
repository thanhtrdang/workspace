import React, { Fragment } from 'react'
import { generate } from 'shortid'
import utils from 'helpers/utils'

import { Title } from 'pepper'

export const PubgHomeStatsView = ({ stats }) => (
  <Fragment>
    <Title color="grey">PUBG Lifetime Overview</Title>
    <div className="stats-overview__pubg">
      {utils.is_populated(stats) &&
        stats.map(stat => (
          <div className="segment tiny light vflex-center text--center" key={generate()}>
            <Title align="center" margin={3} color="grey">
              {stat.content !== undefined ? stat.content : '-'}
            </Title>
            {stat.title}
          </div>
        ))}
    </div>
  </Fragment>
)
