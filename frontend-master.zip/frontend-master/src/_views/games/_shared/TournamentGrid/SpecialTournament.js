import React, { useContext } from 'react'
import classnames from 'classnames'
import { SpinnerIcon } from 'pepper/icons/SpinnerIcon'

// Contexts
import { GameContext } from '_contexts'

import { Link } from 'react-router-dom'

import { Title, Button, Divider } from 'pepper'

export const SpecialTournament = ({ tournament, myTournamentIds, loading }) => {
  const { path, game } = useContext(GameContext)
  const specialGameClass = `tournament-special--${game}`
  const isEntered =
    tournament && tournament.id && Array.isArray(myTournamentIds) && myTournamentIds.includes(tournament.id.toString())

  const content = (
    <div className={classnames({ 'tournament-special': true, [specialGameClass]: true })}>
      <Title size="big" transform="uppercase">
        {tournament.rules && tournament.rules.name}
      </Title>
      <Divider invisible size="big" />
      <Title size="big" transform="uppercase" margin={0} color="green">
        {tournament.prize_pool && parseInt(tournament.prize_pool.amount, 10)}{' '}
        {tournament.prize_pool && tournament.prize_pool.currency}
      </Title>
      <Title size="large2" transform="uppercase" margin={3}>
        Prize Pool
      </Title>
      {loading ? (
        <SpinnerIcon />
      ) : isEntered ? (
        <Button disabled={true} className="tournament-special__button">
          Entered
        </Button>
      ) : (
        <Button primary className="tournament-special__button">
          {tournament.fee && tournament.fee.amount} {tournament.fee && tournament.fee.currency}
        </Button>
      )}
    </div>
  )
  return path ? <Link to={`${path.tournaments}/${tournament.id}`}>{content}</Link> : <div>{content}</div>
}
