import React from 'react'
import { SpinnerIcon } from 'pepper/icons/SpinnerIcon'

export const BottomView = ({
  tournament: {
    fee: { amount, currency },
    status,
  },
  isEntered,
  loading,
}) => (
  <div className="tournament-grid-item__bottom">
    {loading ? (
      <SpinnerIcon />
    ) : isEntered ? (
      <div className="tournament-grid-item__bottom__button tournament-grid-item__bottom__button--joined">Entered</div>
    ) : status !== 'active' ? (
      ''
    ) : (
      <div className="tournament-grid-item__bottom__button">
        {amount} {currency}
      </div>
    )}
  </div>
)
