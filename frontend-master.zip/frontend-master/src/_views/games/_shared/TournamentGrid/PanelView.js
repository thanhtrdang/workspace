import React from 'react'
import moment from 'moment'

import { datetimeFormatMD, datetimeFormatHm } from 'var'
import { Title, Subtitle } from 'pepper'

export const PanelView = ({ tournament: { prize_pool, status, ends_at } }) => (
  <div className="tournament-grid-item__panel">
    {prize_pool && (
      <div className="tournament-grid-item__panel__item">
        <div className="text--center">
          <Title color="green" margin={1}>
            {parseInt(prize_pool.amount, 10)} {prize_pool.currency}
          </Title>
          <Subtitle transform="uppercase" margin={0} size="big">
            Prize pool
          </Subtitle>
        </div>
      </div>
    )}

    {(status === 'closed' || status === 'processed') && (
      <div className="tournament-grid-item__panel__item ">
        <div className="text--center ml">
          <div className="tournament-grid-item__panel__end">
            <Title margin={1} color="red">
              {moment(ends_at).format(datetimeFormatMD)}
            </Title>
          </div>
          <Subtitle margin={0}>{moment(ends_at).format(datetimeFormatHm)}</Subtitle>
        </div>
      </div>
    )}
  </div>
)
