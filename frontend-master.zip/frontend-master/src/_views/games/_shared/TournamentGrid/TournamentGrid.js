import React, { useContext } from 'react'

// Contexts
import { GameContext } from '_contexts'

import { generate } from 'shortid'

import { OmniGrid } from '_components'
import { TournamentGridItem } from './TournamentGridItem'

export const TournamentGrid = ({
  tournaments,
  myTournamentIds,
  handleCountdownFinish,
  loading,
  center,
  gameThumbnailVisible,
  ...props
}) => {
  const { path, game } = useContext(GameContext)

  const gridItems =
    Array.isArray(tournaments) &&
    tournaments.map(tournament => (
      <TournamentGridItem
        tournament={tournament}
        myTournamentIds={myTournamentIds}
        path={path}
        game={game}
        loading={loading}
        handleCountdownFinish={handleCountdownFinish}
        key={generate()}
        center={center}
        gameThumbnailVisible={gameThumbnailVisible}
      />
    ))

  return <OmniGrid items={gridItems} mode="load-more" pageSize={6} center={center} {...props} />
}
