import React from 'react'

import { PepperIcon } from '_components'
import { Title } from 'pepper'

import { ProfileIcon } from 'pepper/icons/ProfileIcon'
import { SpinnerIcon } from 'pepper/icons/SpinnerIcon'

import { feGameNames } from 'var'

export const ThumbnailView = ({
  loading,
  gameThumbnailVisible,
  tournament: {
    num_participants,
    rules: { name },
    prize_pool: { amount },
    winner,
    game,
  },
}) => {
  const thumbClass = parseInt(amount, 10) > 89 ? thumbs[game.name].weekly : thumbs[game.name].daily
  return (
    <div className={`tournament-thumbnail ${thumbClass}`}>
      {gameThumbnailVisible && feGameNames[game.name] && (
        <div className="tournament-grid-item__game-thumbnail">
          <PepperIcon name={`card_${feGameNames[game.name]}`} customSize="3rem" noMargin />
        </div>
      )}
      <div>
        <Title align="center" transform="uppercase" margin={0} className="mt3">
          {name}
        </Title>
        {winner && (
          <div className="tournament-grid-item__thumbnail__winner">
            <PepperIcon name="tournament_trophy" size="tiny" noMargin /> {winner}
          </div>
        )}
      </div>
      <div className="tournament-grid-item__thumbnail__no-participants">
        <div className="mr1">
          <ProfileIcon width="1rem" height="1rem" color="#1BB163" />
        </div>
        {loading ? <SpinnerIcon width="1rem" height="1rem" /> : <div style={{ width: '1rem' }}>{num_participants}</div>}
      </div>
    </div>
  )
}

const thumbs = {
  PUBG: {
    daily: 'pubg-tournament-thumbnail--daily',
    weekly: 'pubg-tournament-thumbnail pubg-tournament-thumbnail--weekly',
  },
  AL: {
    daily: 'apex-tournament-thumbnail--daily',
    weekly: 'apex-tournament-thumbnail apex-tournament-thumbnail--weekly',
  },
}
