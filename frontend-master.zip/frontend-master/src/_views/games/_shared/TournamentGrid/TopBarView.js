import React from 'react'
import moment from 'moment'

import { TournamentCountdown } from '_components'

import { SpinnerIcon } from 'pepper/icons/SpinnerIcon'

export const TopBarView = ({ tournament, loading, handleCountdownFinish }) => {
  return (
    <div className="tournament-grid-item__top-bar">
      {loading ? <SpinnerIcon /> : generateTopBarRightText(tournament, handleCountdownFinish)}
    </div>
  )
}

const generateTopBarRightText = (tournament, handleCountdownFinish) =>
  tournament.status !== 'active' || moment().isAfter(moment(tournament.ends_at)) ? (
    tournament.status
  ) : (
    <TournamentCountdown
      endTime={tournament.ends_at}
      status={tournament.status}
      onFinish={handleCountdownFinish}
      justify="center"
    />
  )
