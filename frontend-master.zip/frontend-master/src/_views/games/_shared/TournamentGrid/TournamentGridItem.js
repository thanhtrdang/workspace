import React, { Fragment } from 'react'
import { Link } from 'react-router-dom'
import classnames from 'classnames'

import { TopBarView } from './TopBarView'
import { ThumbnailView } from './ThumbnailView'
import { PanelView } from './PanelView'
import { BottomView } from './BottomView'

export const TournamentGridItem = ({
  tournament,
  myTournamentIds,
  path,
  game,
  loading,
  handleCountdownFinish,
  center,
  gameThumbnailVisible,
}) => {
  const isEntered = tournament && Array.isArray(myTournamentIds) && myTournamentIds.includes(tournament.id.toString())
  const thisClass = classnames({
    'tournament-grid-item': true,
    'tournament-grid-item--center': center,
  })
  const content = (
    <Fragment>
      <ThumbnailView
        tournament={tournament}
        loading={loading}
        game={game}
        gameThumbnailVisible={gameThumbnailVisible}
      />
      <TopBarView tournament={tournament} loading={loading} handleCountdownFinish={handleCountdownFinish} />
      <PanelView tournament={tournament} />
      <BottomView tournament={tournament} isEntered={isEntered} loading={loading} />
    </Fragment>
  )
  return path ? (
    <div className={thisClass}>
      <Link to={`${path.tournaments}/${tournament.id}`}>{content}</Link>
    </div>
  ) : (
    <div className={thisClass}>{content}</div>
  )
}
