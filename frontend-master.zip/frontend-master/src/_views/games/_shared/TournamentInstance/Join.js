import React from 'react'
import { Button, Form } from 'pepper'
import { withFormik } from 'formik'
import moment from 'moment'

import { ValidationError } from '_components'
import { SpinnerIcon } from 'pepper/icons/SpinnerIcon'

const JoinComponent = ({ tournament, myTournamentIds, loading, errors, isSubmitting, handleSubmit }) => {
  return (
    <div className="tournament-intro__join">
      {loading ? (
        <SpinnerIcon />
      ) : myTournamentIds && myTournamentIds.includes(tournament.id.toString()) ? (
        <Button color="grey" disabled={true}>
          Entered
        </Button>
      ) : tournament.status !== 'active' || moment().isAfter(moment(tournament.ends_at)) ? (
        ''
      ) : (
        <Form onSubmit={handleSubmit}>
          <Button type="submit" primary disabled={isSubmitting}>
            Enter now
          </Button>
          <ValidationError errors={errors} />
        </Form>
      )}
    </div>
  )
}

export const Join = withFormik({
  handleSubmit: (_, { props, setErrors, setSubmitting }) => {
    props.handleSubmit(props.tournament.id, setErrors, setSubmitting)
  },
  displayName: 'JoinForm',
})(JoinComponent)
