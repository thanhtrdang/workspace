import React, { useEffect, useContext } from 'react'

import { GameContext } from '_contexts'

import { withRouter } from 'react-router-dom'

import { Intro } from './Intro'

export const TournamentInstance = withRouter(
  ({
    match,
    authed,
    tournament,
    myTournamentIds,
    loading,
    requestTournamentInstance,
    requestMyTournaments,
    endTournament,
    join,
    tabs,
    banner,
  }) => {
    const id = match && match.params && match.params.id
    const { game } = useContext(GameContext)

    const handleCountdownFinish = _ => {
      endTournament(tournament.id)
      setTimeout(_ => requestTournamentInstance(tournament.id), 3000)
    }

    useEffect(_ => {
      requestTournamentInstance(id)
      authed && requestMyTournaments()
    }, [])

    return tournament ? (
      <div className="tournament-instance">
        {banner}
        <Intro
          tournament={tournament}
          loading={loading}
          handleCountdownFinish={handleCountdownFinish}
          join={join}
          myTournamentIds={myTournamentIds}
          game={game}
        />
        {tabs}
      </div>
    ) : (
      ''
    )
  },
)
