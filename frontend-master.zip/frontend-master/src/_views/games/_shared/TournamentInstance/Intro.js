import React, { Fragment } from 'react'
import moment from 'moment'
import classnames from 'classnames'


import { OmniCountdown, PepperIcon } from '_components'
import { Divider, Title } from 'pepper'
import { SpinnerIcon } from 'pepper/icons/SpinnerIcon'
import { ClockIcon } from 'pepper/icons/ClockIcon'

import { Join } from './Join'

const gameClasses = {
  pubg: 'tournament-intro--pubg',
  apex: 'tournament-intro--apex',
}

export const Intro = ({ tournament, loading, handleCountdownFinish, join, myTournamentIds, game }) => {
  const backgroundClass = classnames({
    'tournament-intro': true,
    [gameClasses[game]]: game ? true : false,
  })

  return (
    <Fragment>
      <div className="flex">
        <div className={`tournament-tag tournament-tag--${tournament.status}`}>
          {loading ? <SpinnerIcon /> : tournament.status}
        </div>
        {game === 'pubg' && <div className="tournament-tag tournament-tag--fpp">FPP Only</div>}
      </div>
      {tournament.status === 'closed' && moment().isBefore(moment(tournament.ends_at).add(45, 'minutes')) && (
        <div className="tournament-process-countdown">
          <div className="tournament-process-countdown__title title">Tournament is processing... </div>
          <div>
            Prizes will be processed in approximately
            <span className="tournament-process-countdown__countdown">
              <OmniCountdown endTime={moment(tournament.ends_at).add(45, 'minutes')} mode="minute" />
            </span>
            minutes.
          </div>
        </div>
      )}

      <div className={backgroundClass}>
        <div className="tournament-intro__left">
          <div className="tournament-intro__title">
            <Title>{tournament.rules.name}</Title>
          </div>
          <div>{tournament.rules.details}</div>
          <Divider size="big" invisible />

          <div className="tournament-intro__time">
            <TimeBox time={tournament.starts_at} title="Start" />
            <TimeBox time={tournament.ends_at} title="End" />
            {moment().isBefore(moment(tournament.ends_at)) && (
              <div className="tournament-intro__countdown">
                <OmniCountdown endTime={tournament.ends_at} onFinish={handleCountdownFinish} view={CustomCountdown} />
              </div>
            )}
          </div>
        </div>

        <div className="tournament-intro__right">
          <div>
            {tournament.prize_pool && (
              <div className="tournament-intro__box">
                <Title color="green">
                  ${parseInt(tournament.prize_pool.amount, 10)} {tournament.prize_pool.currency}
                </Title>
                Prize pool
              </div>
            )}

            <div className="tournament-intro__box">
              <Title color="yellow">{tournament.fee && `${tournament.fee.amount} ${tournament.fee.currency}`}</Title> To
              enter
            </div>
            <Join tournament={tournament} handleSubmit={join} loading={loading} myTournamentIds={myTournamentIds} />
          </div>
        </div>
        <div />
      </div>
    </Fragment>
  )
}

const TimeBox = ({ time, title }) => (
  <div className="time-box">
    <Title color="grey" margin={0}>
      {moment(time).format('MMM DD')}
    </Title>
    <div className="time-box__time"> {moment(time).format('hh:mm a')}</div>
    <div className="time-box__title"> {title}</div>
  </div>
)

const CustomCountdown = ({ days, hours, minutes, seconds, expire }) =>
  expire ? (
    '-'
  ) : (
    <div className="custom-countdown">
      <PepperIcon name="clock" customSize="1.5rem"/>  {days > 0 && `${days} days : `}{hours} : {minutes} : {seconds}
    </div>
  )
