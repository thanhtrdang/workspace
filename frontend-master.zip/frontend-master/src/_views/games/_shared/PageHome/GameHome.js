import React, { useState, useEffect, useContext } from 'react'
import { AsyncContext } from '_components'
import { AuthContext } from '_contexts'
import { fetchTournaments } from '_hooks'

import utils from 'helpers/utils'

import { GameHomeView } from './GameHomeView'

export const GameHome = ({
  game,
  specialTournaments,
  activeTournaments,
  setSpecialTournaments,
  setActiveTournaments,
  myTournamentIds,
  requestMyTournaments,
}) => {
  const { authed } = useContext(AuthContext)
  const { handleError } = useContext(AsyncContext)
  const [loading, setLoading] = useState(true)

  useEffect(_ => {
    let mount = true
    authed && requestMyTournaments instanceof Function && requestMyTournaments()

    fetchTournaments({
      filter: { game, status: 'active' },
      handleError,

      callback: tournaments => {
        if (mount) {
          setLoading(false)
          if (Array.isArray(tournaments)) {
            const specialTournaments = tournaments.filter(tournament => tournament.prize_pool.amount > 100)
            setSpecialTournaments(specialTournaments)

            const activeTournaments = utils.is_populated(specialTournaments)
              ? tournaments.filter(tournament => tournament.id !== specialTournaments[0].id)
              : // tournaments.filter(
                //     tournament => specialTournaments.find(special => special.id === tournament.id) === undefined,
                //   )
                tournaments
            setActiveTournaments(activeTournaments)
          }
        }
      },
    })

    return _ => {
      mount = false
    }
  }, [])

  return (
    <GameHomeView
      specialTournaments={specialTournaments}
      activeTournaments={activeTournaments}
      myTournamentIds={myTournamentIds}
      loading={loading}
    />
  )
}
