import React from 'react'

import { TournamentGrid } from '../TournamentGrid/TournamentGrid'
import { SpecialTournament } from '../TournamentGrid/SpecialTournament'
import { Title } from 'pepper'

export const GameHomeView = ({ specialTournaments, activeTournaments, myTournamentIds, loading }) => (
  <div className="featured-tournaments">
    <Title color="grey">Featured Tournaments</Title>
    {Array.isArray(specialTournaments) && specialTournaments.length > 0 && (
      <SpecialTournament tournament={specialTournaments[0]} myTournamentIds={myTournamentIds} loading={loading} />
    )}
    <Title color="grey" margin={0} className="mt8 featured-tournaments__active-label">
      Active Tournaments
    </Title>
    <TournamentGrid tournaments={activeTournaments} myTournamentIds={myTournamentIds} loading={loading} />
  </div>
)
