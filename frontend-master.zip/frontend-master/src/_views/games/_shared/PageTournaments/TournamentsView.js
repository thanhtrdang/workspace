import React from 'react'
import { TournamentGrid } from '../TournamentGrid/TournamentGrid'
import { Title } from 'pepper'

export const TournamentsView = ({ tournaments, myTournamentIds, loading }) => (
  <div className="tournaments">
    <Title color="grey">Tournaments</Title>
    <TournamentGrid tournaments={tournaments} myTournamentIds={myTournamentIds} loading={loading} />
  </div>
)
