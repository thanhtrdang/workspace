import React, { useContext } from 'react'

import { AuthContext } from '_contexts'

// Redux
import { connect } from 'react-redux'
import {
  get_apex_tournament,
  get_my_apex_tournament_ids,
  apex_tournament_actions,
  is_loading,
  apex_tournament_types as types,
  is_client_running,
} from '_ducks/reducers'

import { ApexTournamentInstanceView } from './ApexTournamentInstanceView'

export const ApexTournamentInstanceComponent = ({
  myTournamentIds,
  requestTournamentInstance,
  requestMyTournaments,
  endTournament,
  tournament,
  loading,
  join,
  isClientRunning,
}) => {
  const { authed } = useContext(AuthContext)
  const clientReminderVisible = isClientRunning === false
  return (
    <ApexTournamentInstanceView
      authed={authed}
      tournament={tournament}
      myTournamentIds={myTournamentIds}
      loading={loading}
      requestTournamentInstance={requestTournamentInstance}
      requestMyTournaments={requestMyTournaments}
      endTournament={endTournament}
      join={join}
      clientReminderVisible={clientReminderVisible}
    />
  )
}
const mapState = (state, ownProps) => ({
  tournament: get_apex_tournament(state, parseInt(ownProps.match.params.id, 10)),
  myTournamentIds: get_my_apex_tournament_ids(state),
  loading: is_loading(state)([types.REQUEST, types.MY_REQUEST]),
  isClientRunning: is_client_running(state),
})

const mapDispatch = dispatch => ({
  requestTournamentInstance: id => dispatch(apex_tournament_actions.requestTournament(parseInt(id, 10))),
  requestMyTournaments: _ => dispatch(apex_tournament_actions.requestMyTournaments()),
  endTournament: id => dispatch(apex_tournament_actions.endTournament(parseInt(id, 10))),
  join: (id, setErrors, setSubmitting) =>
    dispatch(apex_tournament_actions.joinTournament(parseInt(id, 10), setErrors, setSubmitting)),
})

export const ApexTournamentInstance = connect(
  mapState,
  mapDispatch,
)(ApexTournamentInstanceComponent)
