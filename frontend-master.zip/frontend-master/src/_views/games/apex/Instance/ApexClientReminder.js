import React from 'react'
import { Link } from 'react-router-dom'
import { gamePaths } from 'var'
import { WarningIcon } from 'pepper/icons/WarningIcon'

export const ApexClientReminder = _ => (
  <div className="tournament-instance-banner">
    <WarningIcon />
    <span className="apex-client-reminder__text">
      You need to turn your <Link to={gamePaths.apex.client}>Pepper Client</Link> on to record matches.
    </span>
  </div>
)
