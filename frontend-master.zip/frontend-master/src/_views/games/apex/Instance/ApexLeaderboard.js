import React, { useState, useEffect } from 'react'
import { connect } from 'react-redux'
import {
  get_apex_tournament,
  get_username,
  get_apex_participants,
  is_loading,
  apex_leaderboard_actions,
  apex_leaderboard_types as types,
} from '_ducks/reducers'

import { ApexLeaderboardView } from './ApexLeaderboardView'

const ApexLeaderboardComponent = ({ match, tournament, user, requestLeaderboard, participants, loading }) => {
  const [init, setInit] = useState(false)

  useEffect(_ => {
    if (!init) {
      const id = match && match.params && match.params.id
      requestLeaderboard(id)
      setInit(true)
    }
  })

  return participants && participants.data ? (
    <ApexLeaderboardView tournament={tournament} user={user} participants={participants.data} loading={loading} />
  ) : (
    ''
  )
}

const mapState = (
  state,
  {
    match: {
      params: { id },
    },
  },
) => {
  return {
    tournament: get_apex_tournament(state, parseInt(id, 10)),
    user: get_username(state),
    participants: get_apex_participants(state, id),
    loading: is_loading(state)([types.PARTICIPANTS_REQUEST]),
  }
}

const mapDispatch = dispatch => ({
  requestLeaderboard: id => dispatch(apex_leaderboard_actions.request(id)),
})

export const ApexLeaderboard = connect(
  mapState,
  mapDispatch,
)(ApexLeaderboardComponent)
