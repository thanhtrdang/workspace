import React, { Fragment } from 'react'
import { TournamentInstance } from '../../_shared/TournamentInstance/TournamentInstance'

import { gamePaths } from 'var'
import { Switch, Route } from 'react-router-dom'
import { OmniTab } from '_components'

import { ApexRules } from './ApexRules'
import { ApexLeaderboard } from './ApexLeaderboard'
import { ApexClientReminder } from './ApexClientReminder'

export const ApexTournamentInstanceView = ({
  authed,
  tournament,
  myTournamentIds,
  loading,
  requestTournamentInstance,
  requestMyTournaments,
  endTournament,
  join,
  clientReminderVisible,
}) => {
  const apexTabs = tournament && (
    <OmniTab className="page-tournament-instance__tab-section">
      <OmniTab.Bar>
        <OmniTab.Link exact to={addTabState(`${gamePaths.apex.tournaments}/${tournament.id}`)}>
          Leaderboard
        </OmniTab.Link>
        <OmniTab.Link exact to={addTabState(`${gamePaths.apex.tournaments}/${tournament.id}/rules`)}>
          Rules
        </OmniTab.Link>
      </OmniTab.Bar>

      <OmniTab.Content>
        <Switch>
          <Route path={gamePaths.apex.tournament_instance} exact component={ApexLeaderboard} />
          <Route path={gamePaths.apex.tournament_rules} component={ApexRules} />
        </Switch>
      </OmniTab.Content>
    </OmniTab>
  )

  return (
    <Fragment>
      <TournamentInstance
        authed={authed}
        tournament={tournament}
        myTournamentIds={myTournamentIds}
        loading={loading}
        requestTournamentInstance={requestTournamentInstance}
        requestMyTournaments={requestMyTournaments}
        endTournament={endTournament}
        tabs={apexTabs}
        join={join}
        banner={clientReminderVisible && <ApexClientReminder />}
      />
    </Fragment>
  )
}

const addTabState = link => ({
  pathname: link,
  state: { tab: true },
})
