import React from 'react'
import { generate } from 'shortid'
import { Segment, Subtitle } from 'pepper'

const rules = [
  {
    title: `General Rules`,
    contents: [
      `Play as many games as you want.`,
      `Only your top games are used for scoring.`,
      `You can play in tournaments simultaneously, and your top scores are counted across tournaments.`,
      `You must run the Pepper Client while playing for your account to be verified and for your scores to be recorded.`,
    ],
  },

  {
    title: `Daily Rules`,
    contents: [
      `Top 3 Match Scores are used for scoring.`,
      `Tournaments start at 00:00 GMT and end 24 hours later at 11:59 GMT.`,
    ],
  },

  {
    title: `Weekly Rules`,
    contents: [
      `Top 7 Match Scores are used for scoring.`,
      `Tournaments start on Monday at 00:00 GMT and end 7 days later at 11:59 GMT.`,
    ],
  },
  {
    title: `Cheating`,
    contents: [
      `All cheaters will be banned from our platform, and our legal team will commence a claim to recoup any prize money awarded and the legal
expenses for doing so. Recouped prize money will be redistributed amongst the remaining players in the tournament. If you
suspect someone is cheating, please report them to us at support@pepper.gg.`,
    ],
  },
  {
    title: `Scoring Rules`,
    contents: [
      `Your Match Score is the score you gain at the end of a Apex Legends round. When a game ends, the Pepper Client checks your in-game score and automatically loads it to the platform.`,
    ],
  },
]

const generateRule = rule => (
  <div key={generate()}>
    <div className="tournament-rules__rule-list">
      <div className="tournament-rules__rule">
        <Subtitle size="big" color="green">
          {rule.title}
        </Subtitle>
        {rule.contents.map(content => (
          <p key={generate()} className="tournament-rules__rule__content">
            {content}
          </p>
        ))}
      </div>
    </div>
  </div>
)

const rulesCol = rules.map(rule => generateRule(rule))

export const ApexRules = _ => (
  <div className="tournament-rules">
    <Segment size="large" theme="light">
      <div>{rulesCol}</div>
    </Segment>
  </div>
)
