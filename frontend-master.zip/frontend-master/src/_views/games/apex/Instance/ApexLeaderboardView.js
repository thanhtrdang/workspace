import React, { Fragment } from 'react'
import { Link } from 'react-router-dom'
import { routes } from 'var'

import { PepperIcon, OmniTable, OmniLoading, ErrorBoundary } from '_components'

export const ApexLeaderboardView = ({ tournament, participants, user, loading }) => {
  const frame = [
    {
      header: 'Player',
      content: props => {
        return (
          <Link to={`${routes.users}/${props.username}/tournament-history`}>
            <Fragment>{props.usernameSpan || props.username}</Fragment>
          </Link>
        )
      },
    },
    {
      header: 'Kills',
      content: props => props.kills,
      align: 'center',
    },
    {
      header: 'Total Score',
      content: props => props.total_score,
      align: 'center',
    },
    {
      header: tournament.num_matches_used
        ? `Total Matches (Best ${tournament.num_matches_used} used)`
        : 'Total Matches',
      content: props => props.matches_total,
      align: 'center',
    },
    {
      header: 'Payout',
      content: props => props.payout,
      align: 'right',
      minWidth: '111px',
    },
  ]

  const records = !(participants instanceof Array)
    ? null
    : participants.length === 0
    ? []
    : participants.map(row => ({
        username: row.user.username,
        // apex_name: row.player.name,
        verified_status: row.player.verified_status,
        kills: row.kills || '-',
        total_score: row.score,
        matches_total: row.matches,
        payout:
          row.player.verified_status !== 'verified' || !row.payout ? (
            '-'
          ) : (
            <span>
              {row.payout.amount} {row.payout ? row.payout.currency : ''}
            </span>
          ),
        _styles: {
          color: row.player.verified_status !== 'verified' && '#ccc',
          background: row.user.username === user && 'rgb(5, 46, 238)',
          fontWeight: row.user.username === user && 'bold',
        },
      }))

  const recordWithWinners = records && addWinnerHighlight(records, tournament)

  return (
    <OmniLoading loading={loading} preview={participants && participants.length > 0}>
      <ErrorBoundary>
        <OmniTable
          data={recordWithWinners}
          frame={frame}
          noResultMessage="Nobody has joined this tournament yet."
          rowName="player"
          rowsName="players"
          showRank
          showTotal
          title="The leaderboard may take up to 45 minutes to update."
        />
      </ErrorBoundary>
    </OmniLoading>
  )
}

const addWinnerHighlight = (data, tournament) => {
  if (tournament.status !== 'processed') {
    return data
  }

  const medalList = ['tournament_trophy', 'medal_silver', 'medal_bronze'].map(medal => <PepperIcon name={medal} />)

  const dataWithWinners =
    // Check if there is a winner
    data[0] && data[0].payout && parseInt(data[0].payout.amount, 10) > 0
      ? data.map((row, index) => ({
          ...row,
          usernameSpan:
            // Validate top rank players
            index < 3 && parseInt(row.payout.amount, 10) > 0 ? (
              <span className="leaderboard__user-medal">
                {medalList[index]} {row.username}
              </span>
            ) : (
              <span className="leaderboard__user-no-medal">{row.username}</span>
            ),
        }))
      : data

  return dataWithWinners
}
