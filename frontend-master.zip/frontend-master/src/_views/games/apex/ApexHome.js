import React, { useContext } from 'react'
import { GameHome } from '../_shared/PageHome/GameHome'

import { VaultContext } from '_contexts'

import { connect } from 'react-redux'
import { get_my_apex_tournament_ids, apex_tournament_actions } from '_ducks/reducers'

export const ApexHomeComponent = ({ myTournamentIds, requestMyTournaments }) => {
  const { state, dispatch, selectors, actions } = useContext(VaultContext)
  const specialTournaments = selectors.apex.getSpecialTournaments(state)
  const activeTournaments = selectors.apex.getActiveTournaments(state)
  const setSpecialTournaments = tournaments => dispatch(actions.apex.setSpecialTournaments(tournaments))
  const setActiveTournaments = tournaments => dispatch(actions.apex.setActiveTournaments(tournaments))

  return (
    <div className="main-inner">
      <GameHome
        game="apex"
        specialTournaments={specialTournaments}
        activeTournaments={activeTournaments}
        setSpecialTournaments={setSpecialTournaments}
        setActiveTournaments={setActiveTournaments}
        myTournamentIds={myTournamentIds}
        requestMyTournaments={requestMyTournaments}
      />
    </div>
  )
}

const mapState = state => ({
  myTournamentIds: get_my_apex_tournament_ids(state),
})

const mapDispatch = dispatch => ({
  requestMyTournaments: _ => dispatch(apex_tournament_actions.requestMyTournaments()),
})

export const ApexHome = connect(
  mapState,
  mapDispatch,
)(ApexHomeComponent)
