import React from 'react'

import { TournamentsView } from '../_shared/PageTournaments/TournamentsView'

export const ApexTournamentsView = ({ tournaments, myTournamentIds, loading }) => (
  <div className="main-inner">
    {Array.isArray(tournaments) && (
      <TournamentsView tournaments={tournaments} myTournamentIds={myTournamentIds} loading={loading} />
    )}
  </div>
)
