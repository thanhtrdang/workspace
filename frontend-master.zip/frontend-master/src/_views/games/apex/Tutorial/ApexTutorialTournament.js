import React, { useState, useEffect, useContext } from 'react'
import { Segment, Subtitle, Title } from 'pepper'
import { connect } from 'react-redux'
import {
  get_credit_currency,
  is_loading,
  get_my_apex_tournament_ids,
  apex_tournament_types as types,
} from '_ducks/reducers'
import { apex_tournament_actions } from '_ducks/reducers'

import { AsyncContext } from '_components'
import { TournamentGrid } from '../../../games/_shared/TournamentGrid/TournamentGrid'
import { fetchTournaments } from '_hooks'

import { Redirect } from 'react-router-dom'
import { gamePaths } from 'var'

import { StarIcon } from 'pepper/icons/StarIcon'

const ApexTutorialTournamentComponent = ({
  creditCurrency,
  requestMyApexTournaments,
  my_loading,
  myApexTournamentIds,
}) => {
  const { handleError } = useContext(AsyncContext)
  const [loading, setLoading] = useState(true)
  const [tournaments, setTournaments] = useState([])

  useEffect(_ => {
    let mount = true
    requestMyApexTournaments()

    fetchTournaments({
      filter: { game: 'apex', status: 'active' },
      callback: tournaments => {
        if (mount) {
          Array.isArray(tournaments) && setTournaments(tournaments)
          setLoading(false)
        }
      },
      handleError: handleError,
    })

    return _ => {
      mount = false
    }
  }, [])

  return Array.isArray(myApexTournamentIds) && myApexTournamentIds.length > 0 ? (
    <Redirect to={gamePaths.apex.home} />
  ) : loading || my_loading || myApexTournamentIds === undefined ? (
    ''
  ) : (
    <div className="tutorial-tournament">
      <Segment theme="light" className="tutorial-tournament__segment">
        <Title>You have received</Title>
        <Title margin={8}>
          <StarIcon /> <span className="tutorial-tournament__amount"> 10,000 {creditCurrency}</span>
        </Title>
        <Subtitle margin={0}>Go ahead and enter a tournament!</Subtitle>
      </Segment>

      <TournamentGrid tournaments={tournaments} loading={loading} handleCountdownFinish={fetch} center />
    </div>
  )
}

const mapState = state => ({
  creditCurrency: get_credit_currency(state),
  my_loading: is_loading(state)([types.MY_REQUEST]),
  myApexTournamentIds: get_my_apex_tournament_ids(state),
})

const mapDispatch = dispatch => ({
  requestMyApexTournaments: _ => dispatch(apex_tournament_actions.requestMyTournaments()),
})

export const ApexTutorialTournament = connect(
  mapState,
  mapDispatch,
)(ApexTutorialTournamentComponent)
