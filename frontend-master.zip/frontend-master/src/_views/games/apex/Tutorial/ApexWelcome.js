import React, { useEffect } from 'react'
import { Title, Button, Divider, Subtitle } from 'pepper'

import { Redirect } from 'react-router-dom'
import { gamePaths } from 'var'

import { connect } from 'react-redux'
import { is_apex_activated, apex_actions } from '_ducks/reducers'

import { PepperIcon } from '_components'
import apex_welcome from './images/Lifeline.png'

const ApexWelcomeComponent = ({ activateApex, isApexActive, checkApexActivation }) => {
  useEffect(_ => {
    isApexActive === undefined && checkApexActivation()
  }, [])

  return isApexActive === undefined ? (
    ''
  ) : isApexActive ? (
    <Redirect to={gamePaths.apex.home} />
  ) : (
    <div className="apex-welcome">
      <div className="apex-welcome__segment">
        <img src={apex_welcome} alt="apex welcome" className="apex-welcome__image" />
        <div className="apex-welcome__content">
          <PepperIcon name="logo_apex" size="huge" />
          <Divider invisible />
          <Title margin={1}>Enter now to receive</Title>
          <Title margin={2} color="yellow">
            10,000 GLG
          </Title>
          <Subtitle>GLG is used to enter tournaments</Subtitle>
          <Divider invisible />
          <Button primary onClick={activateApex}>
            Enter a tournament
          </Button>
        </div>
      </div>
    </div>
  )
}

const mapState = state => ({
  isApexActive: is_apex_activated(state),
})

const mapDispatch = dispatch => ({
  checkApexActivation: _ => dispatch(apex_actions.checkActivation()),
  activateApex: _ => dispatch(apex_actions.activate()),
})
export const ApexWelcome = connect(
  mapState,
  mapDispatch,
)(ApexWelcomeComponent)
