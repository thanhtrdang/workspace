import React, { Fragment, useEffect, useState } from 'react'
import { Segment, Title, Subtitle, Button, Container, Divider } from 'pepper'
import { PepperClientIcon } from 'pepper/icons/PepperClientIcon'

import { withRouter } from 'react-router-dom'
import { gamePaths } from 'var'

import { connect } from 'react-redux'
import { is_client_running, has_client_ever_run } from '_ducks/reducers'

import tipon from './images/tipon.png'
import tipoff from './images/tipoff.png'

const CLIENT_URL = process.env.REACT_APP_CLIENT_URL

const ApexTutorialClientComponent = ({ isClientRunning, hasClientEverRun, history }) => {
  const [downloading, setDownloading] = useState(false)

  let timer = null

  useEffect(
    _ => {
      if (hasClientEverRun && isClientRunning) {
        timer = setTimeout(_ => history.push(gamePaths.apex.home), 2000)
      }
      return _ => clearTimeout(timer)
    },
    [hasClientEverRun, isClientRunning],
  )

  return (
    <div className="apex-client">
      <Container center>
        <Segment className="apex-client__segment" theme="light">          
          <div className="flex-center-center mv9">
            <PepperClientIcon width="5rem" height="100%" />
            <Title color="white" align="center" margin={0} className="ml6">
              Download Pepper Client
            </Title>
          </div>
          <Subtitle align="center" margin={8}>
            Pepper client automatically authenticates your game account and keeps track of your matches and scores.            
          </Subtitle>
          <Divider invisible size="small"/>
          {hasClientEverRun && isClientRunning ? (
            <Fragment>
              <div className="apex-client__connected mb">Successfully Connected</div>
              <div className="mt">Tranferring you to home...</div>
            </Fragment>
          ) : downloading ? (
            <Fragment>
              <div className="apex-client__downloading">
                <span className="apex-client_download-text">Waiting for Pepper Client to connect... </span>
                <div className="apex-client__downloading-bar" />
              </div>
              <Subtitle size="small" className="mt7">
                Please wait up to 90 seconds for your client to connect
              </Subtitle>
            </Fragment>
          ) : (
            <a href={CLIENT_URL} target="_blank" rel="noopener noreferrer" onClick={_ => setDownloading(true)}>
              <Button primary>Download Pepper Client</Button>
            </a>
          )}
        </Segment>

        {(downloading || hasClientEverRun || isClientRunning) && <Tips />}
      </Container>
    </div>
  )
}

const mapState = state => ({
  isClientRunning: is_client_running(state),
  hasClientEverRun: has_client_ever_run(state),
})

export const ApexTutorialClient = connect(mapState)(withRouter(ApexTutorialClientComponent))

const Tips = _ => <div className="client-tips">
  <Title>Tips</Title>
  <div className="client-tips__item">
    <img src={tipon} className="client-tips__image"/> 
    <span  className="client-tips__text">A status indicator will show your client's status so you know that your matches and scores are being tracked.</span>
  </div>

  <div className="client-tips__item">
    <img src={tipoff} className="client-tips__image"/> 
    <span className="client-tips__text text--red">Untracked matches wil not show up in the tournament history.</span>
  </div>
</div>