import React from 'react'
import { NavLink } from 'react-router-dom'

export const GameMenuItem = ({ icon, text, to, exact, hidden, last }) =>
  hidden ? (
    ''
  ) : (
    <NavLink exact={exact} to={to} className="game-menu-item" activeClassName="game-menu-item--active">
      <div className="game-menu-item__content">
        <div className="game-menu-item__icon">{icon}</div>
        <div className="game-menu-item__text">{text}</div>
      </div>
    </NavLink>
  )
