import React from 'react'
import { LogoBlockIcon } from 'pepper/icons/LogoBlockIcon'

export const PepperStore = _ => (
  <a href="http://shopify.com/peppergg" className="game-menu-item game-menu-item--last">
    <div className="game-menu-item__content">
      <div className="">
        <LogoBlockIcon />
      </div>
      <div className="game-menu-item__text">Pepper Store</div>
    </div>
  </a>
)
