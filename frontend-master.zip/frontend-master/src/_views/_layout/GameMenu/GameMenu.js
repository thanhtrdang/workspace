import React, { useContext } from 'react'
import utils from 'helpers/utils'
// Redux
import { connect } from 'react-redux'
import {
  get_pubg_verification,
  is_pubg_activated,
  get_my_pubg_tournament_ids,
  get_my_apex_tournament_ids,
  has_client_ever_run,
} from '_ducks/reducers'

// Context
import { GameContext, AuthContext, MenuContext } from '_contexts'
import { GameMenuView } from './GameMenuView'

const GameMenuComponent = ({
  isPubgActivated,
  pubgVerification,
  myPubgTournamentIds,
  myApexTournamentIds,
  hasClientEverRun,
}) => {
  const { game, path } = useContext(GameContext)
  const { authed } = useContext(AuthContext)
  const { closeSubs } = useContext(MenuContext)

  const verifyPubgHidden = !authed || pubgVerification === undefined || pubgVerification === 'verified'
  const pubgHidden = !isPubgActivated || !utils.is_populated(myPubgTournamentIds)
  const apexHidden = !hasClientEverRun || !utils.is_populated(myApexTournamentIds)
  return authed && path && game ? (
    <GameMenuView
      game={game}
      apexHidden={apexHidden}
      verifyPubgHidden={verifyPubgHidden}
      pubgHidden={pubgHidden}
      closeSubs={closeSubs}
    />
  ) : (
    ''
  )
}

const mapState = state => ({
  pubgVerification: get_pubg_verification(state),
  isPubgActivated: is_pubg_activated(state),
  myPubgTournamentIds: get_my_pubg_tournament_ids(state),

  myApexTournamentIds: get_my_apex_tournament_ids(state),
  hasClientEverRun: has_client_ever_run(state),
})

export const GameMenu = connect(mapState)(GameMenuComponent)
