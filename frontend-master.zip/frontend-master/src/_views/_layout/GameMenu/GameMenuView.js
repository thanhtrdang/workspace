import React from 'react'
import { generate } from 'shortid'

import utils from 'helpers/utils'

// Icons
// import { HomeIcon } from 'pepper/icons/HomeIcon'
import { TournamentIcon } from 'pepper/icons/TournamentIcon'
import { AddIcon } from 'pepper/icons/AddIcon'
// import { StatsIcon } from 'pepper/icons/StatsIcon'

// Components
import { GameSelection } from './GameSelection'
import { GameMenuItem } from './GameMenuItem'

import { gamePaths } from 'var'
// import { PepperStore } from './PepperStore'

export const GameMenuView = ({ game, apexHidden, pubgHidden, verifyPubgHidden, closeSubs }) => {
  const menu = {
    pubg: [
      <GameMenuItem
        icon={<TournamentIcon />}
        text="Tournaments"
        to={gamePaths.pubg.tournaments}
        key={generate()}
        hidden={pubgHidden}
      />,
      <GameMenuItem
        icon={<AddIcon />}
        text="Verify PUBG"
        to={gamePaths.pubg.verify}
        key={generate()}
        hidden={verifyPubgHidden || pubgHidden}
      />,
    ],
    apex: [
      <GameMenuItem
        icon={<TournamentIcon />}
        text="Tournaments"
        to={gamePaths.apex.tournaments}
        key={generate()}
        hidden={apexHidden}
      />,
    ],
  }
  return (
    <div className="game-menu" onClick={closeSubs}>
      <GameSelection key={generate()} />
      {utils.is_populated(menu[game]) && menu[game].map(item => item)}
    </div>
  )
}
