import React from 'react'

import { PepperIcon } from '_components'
import { withRouter } from 'react-router-dom'
import { routes } from 'var'

import { gameUtils } from 'helpers/gameUtils'
import { generate } from 'shortid'

const GameCardsComponent = ({ close, saveGame, history }) => {
  const handleClick = name => {
    close()
    saveGame(name)
    history.push(routes.home)
  }
  const games = gameUtils.getAll()

  return (
    <div className="game-cards">
      {games.map(name => (
        <a onClick={_ => handleClick(name)} className="game-cards__item" key={generate()}>
          <PepperIcon name={`card_${name}`} noMargin size="large" />
        </a>
      ))}
    </div>
  )
}

export const GameCards = withRouter(GameCardsComponent)
