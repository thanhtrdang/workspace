import React, { useEffect, useContext, Fragment } from 'react'
import { withRouter } from 'react-router-dom'
import classnames from 'classnames'
import { PepperIcon } from '_components'
// import { GameCards } from './GameCards'
import { routes } from 'var'
import { GameContext } from '_contexts'

import { gameUtils } from 'helpers/gameUtils'

const GameSelectionComponent = ({ history }) => {
  const { game, saveGame } = useContext(GameContext)

  // const [cardsVisible, setCardsVisible] = useState(false)

  useEffect(_ => {
    const path = history && history.location && history.location.pathname
    const gameNameGuess = path.replace(/^\/([^/]*).*$/, '$1')
    if (gameNameGuess !== game) {
      if (gameUtils.validate(gameNameGuess)) {
        saveGame(gameNameGuess) // update game selection in context and localStorage
      }
    }
  })

  const selectGame = name => {
    saveGame(name)
    history.push(routes.home)
  }

  return (
    <Fragment>
      <div className="game-menu-item" onClick={_ => selectGame('pubg')}>
        <div className="game-menu-item__content">
          <div
            className={classnames({
              'game-menu-item__game': true,
              'game-menu-item__game--active': game === 'pubg',
            })}>
            <PepperIcon
              name="card_pubg"
              customSize="4rem"
              noMargin
              className={classnames({ 'game-menu-item__game-icon': true, 'game-menu-item__game-icon--active': game === 'pubg' })}
            />
          </div>
        </div>
      </div>
      <div className="game-menu-item" onClick={_ => selectGame('apex')}>
        <div className="game-menu-item__content">
          <div
            className={classnames({
              'game-menu-item__game': true,
              'game-menu-item__game--active': game === 'apex',
            })}>
              <PepperIcon name="card_apex" customSize="4rem" noMargin className={classnames({ 'game-menu-item__game-icon': true,'game-menu-item__game-icon--active': game === 'apex' })}/>
          </div>
        </div>
      </div>
    </Fragment>
    // <div className="game-menu-item">
    //   {cardsVisible && <GameCards close={_ => setCardsVisible(false)} saveGame={saveGame} />}
    //   <div className="game-menu-item__content" onClick={_ => setCardsVisible(!cardsVisible)}>
    //     <div className="game-menu-item__game">
    //       <PepperIcon name={`card_pubg`} noMargin size="large" />
    //     </div>
    //   </div>
    // </div>
  )
}

export const GameSelection = withRouter(GameSelectionComponent)
