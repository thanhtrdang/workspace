import React from 'react'

import { MainView } from './MainView'

export const Main = ({ children }) => {
  return <MainView>{children}</MainView>
}
