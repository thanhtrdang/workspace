import React from 'react'

const burger = 'menu-toggle__burger'

export const MenuToggle = ({ toggle }) => {
  return (
    <div className="menu-toggle">
      <div className="menu-toggle__button" onClick={toggle}>
        <div className={burger} />
        <div className={burger} />
        <div className={burger} />
      </div>
    </div>
  )
}
