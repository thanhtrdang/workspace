import React, { useContext } from 'react'

import { MenuContext } from '_contexts'

import { MenuToggle } from './MenuToggle'

export const MainView = ({ children }) => {
  const { menuVisible, toggleMenu } = useContext(MenuContext)

  const thisClass =
    menuVisible === false ? 'main' : menuVisible === 'in' ? 'main main--slide-in' : 'main main--slide-out'

  return (
    <div className={thisClass}>
      <MenuToggle toggle={toggleMenu} />
      {children}
    </div>
  )
}
