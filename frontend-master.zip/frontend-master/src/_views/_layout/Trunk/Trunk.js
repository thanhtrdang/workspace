import React, { useContext } from 'react'
import { MenuContext, AuthContext, GameContext } from '_contexts'
import classnames from 'classnames'
import { Banners } from '_containers/Common/Banners'
import { Main } from './Main'

export const Trunk = ({ children }) => {
  const { closeSubs } = useContext(MenuContext)
  const { authed } = useContext(AuthContext)
  const { game } = useContext(GameContext)

  const trunkClass = classnames({
    trunk: true,
    'trunk--full': !authed || !game,
  })
  return (
    <div className={trunkClass} onClick={closeSubs}>
      <Main>
        <Banners />
        {children}
      </Main>
    </div>
  )
}
