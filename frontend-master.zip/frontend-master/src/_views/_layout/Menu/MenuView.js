import React from 'react'
import { Logo } from './Logo'
import { MainNav } from './MainNav'
import { ClientStatus } from './ClientStatus'

export const MenuView = ({ visible, authed, clientVisible }) => {
  const thisClass = visible === false ? 'menu' : visible === 'in' ? 'menu menu--slide-in' : 'menu menu--slide-out'

  return (
    <div className={thisClass}>
      <div className="menu-navigation-left">
        <Logo />
        {authed && clientVisible && <ClientStatus />}
      </div>
      <MainNav />
    </div>
  )
}
