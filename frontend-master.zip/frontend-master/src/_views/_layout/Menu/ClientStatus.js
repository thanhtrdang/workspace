import React, { Fragment } from 'react'
import { Link } from 'react-router-dom'

import { PepperClientIcon } from 'pepper/icons/PepperClientIcon'
import { PepperClientInactiveIcon } from 'pepper/icons/PepperClientInactiveIcon'

import { gamePaths } from 'var'

import { connect } from 'react-redux'
import { is_client_running } from '_ducks/reducers'

const ClientStatusComponent = ({ isClientRunning }) => {
  return (
    <Link to={gamePaths.apex.client}>
      <div className="client-status">
        {isClientRunning ? (
          <Fragment>
            <PepperClientIcon width="2.4rem" height="100%" />
            <span className="client-status__text">Client Online</span>
          </Fragment>
        ) : (
          <Fragment>
            <PepperClientInactiveIcon width="2.4rem" height="100%" />
            <span className="client-status__text client-status__text--offline">Client Offline</span>
          </Fragment>
        )}
      </div>
    </Link>
  )
}

const mapState = state => ({
  isClientRunning: is_client_running(state),
})

export const ClientStatus = connect(mapState)(ClientStatusComponent)
