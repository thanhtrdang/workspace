import React, { Fragment, useContext } from 'react'

import { routes } from 'var'

import { connect } from 'react-redux'
import { is_authed, get_username, get_credit, get_credit_currency } from '_ducks/reducers'

import { ProfileIcon } from 'pepper/icons/ProfileIcon'
import { StarIcon } from 'pepper/icons/StarIcon'
import { QuestionIcon } from 'pepper/icons/QuestionIcon'
import { EllipsisIcon } from 'pepper/icons/EllipsisIcon'

import { MenuItem } from './MenuItem'
import { ProfileSub } from './Sub/ProfileSub'
import { ExtraSub } from './Sub/ExtraSub'

import { MenuContext } from '_contexts'

export const MainNavComponent = ({ authed, username, credit, creditCurrency }) => {
  const { profileSubVisible, toggleProfileSub, extraSubVisible, toggleExtraSub } = useContext(MenuContext)

  return (
    <div className="menu-navigation-right">
      {/* Ellipsis dropdown */}
      <MenuItem icon={<EllipsisIcon />} handleClick={toggleExtraSub} active={extraSubVisible}>
        <ExtraSub visible={extraSubVisible} />
      </MenuItem>
      {authed ? (
        // Profile dropdown
        <MenuItem icon={<ProfileIcon />} text={username} handleClick={toggleProfileSub} active={profileSubVisible}>
          <ProfileSub visible={profileSubVisible} />
        </MenuItem>
      ) : (
        // Login / Sign up
        <Fragment>
          <MenuItem text={'Sign up'} to={routes.signup} />
          <MenuItem text={'Login'} to={routes.login} />
        </Fragment>
      )}
      <MenuItem icon={<QuestionIcon />} to={routes.faqs} />
      {/* Credit */}
      {credit > 0 && (
        <MenuItem
          icon={<StarIcon />}
          text={`${credit} ${creditCurrency}`}
          to={routes.transactionHistory}
          className="menu-item__credits"
        />
      )}
    </div>
  )
}
const mapState = state => ({
  authed: is_authed(state),
  username: get_username(state),
  credit: get_credit(state),
  creditCurrency: get_credit_currency(state),
})

export const MainNav = connect(mapState)(MainNavComponent)
