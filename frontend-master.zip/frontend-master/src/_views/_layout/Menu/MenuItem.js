import React from 'react'
import classnames from 'classnames'
import { NavLink } from 'react-router-dom'

export const MenuItem = ({ icon, text, to, exact, active, children, handleClick, className }) => {
  const iconClass = classnames({
    'menu-item__icon': true,
    mr2: text,
  })

  const itemClass = classnames({
    'menu-item': true,
    [className]: className ? true : false,
  })

  const dropdownItemClass = classnames({
    'menu-item': true,
    'menu-item-plain--active': active,
    [className]: className ? true : false,
  })
  const itemContent = (
    <div className="menu-item__content" onClick={handleClick}>
      {icon && <div className={iconClass}>{icon}</div>}
      {text && <div className="menu-item__text">{text}</div>}
    </div>
  )

  return to ? (
    <NavLink exact={exact} to={to} className={itemClass} activeClassName="menu-item--active">
      {itemContent}
      {children}
    </NavLink>
  ) : (
    <div className={dropdownItemClass}>
      {itemContent}
      {children}
    </div>
  )
}
