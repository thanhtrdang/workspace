import React, { useContext } from 'react'
import { MenuContext } from '_contexts'
import classnames from 'classnames'

import { SubItem } from './SubItem'
import { routes } from 'var'

export const ExtraSub = ({ visible }) => {
  const { toggleExtraSub } = useContext(MenuContext)
  const thisClass = classnames({
    sub: true,
    'sub--hidden': !visible,
  })
  return (
    <div className={thisClass} onClick={toggleExtraSub}>
      <SubItem text="About" to={routes.about} />
      <SubItem text="Terms & Conditions" to="https://www.ludare.com/terms/" external />
      <SubItem text="Privacy Policy" to="https://www.ludare.com/privacy/" external />
      <SubItem text="Support" to="https://peppergg.freshdesk.com/support/home" external />
      <SubItem text="Contact" to={routes.contact} />
    </div>
  )
}
