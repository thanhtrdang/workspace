import React from 'react'
import { NavLink } from 'react-router-dom'

import { ExternalIcon } from 'pepper/icons/ExternalIcon'

export const SubItem = ({ exact, to, text, external }) =>
  external ? (
    <a href={to} target="_blank" className="sub-item">
      <div className="sub-item__content">
        {text && (
          <div className="sub-item__text">
            {text}
            <span className="ml2">
              <ExternalIcon />
            </span>
          </div>
        )}
      </div>
    </a>
  ) : (
    <NavLink exact={exact} to={to} className="sub-item" activeClassName="sub-item--active">
      <div className="sub-item__content">{text && <div className="sub-item__text">{text}</div>}</div>
    </NavLink>
  )
