import React, { useContext } from 'react'
import { MenuContext } from '_contexts'
import classnames from 'classnames'

import { SubItem } from './SubItem'
import { routes } from 'var'

export const ProfileSub = ({ visible }) => {
  const { toggleProfileSub } = useContext(MenuContext)
  const thisClass = classnames({
    sub: true,
    'sub--hidden': !visible,
  })
  return (
    <div className={thisClass} onClick={toggleProfileSub}>
      <SubItem text="Profile" to={routes.profile} />
      <SubItem text="My Balance" to={routes.transactionHistory} />
      <SubItem text="My Matches" to={routes.myMatches} />
      <SubItem text="Logout" to={routes.logout} />
    </div>
  )
}
