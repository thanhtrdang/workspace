import React from 'react'

import { Link, NavLink } from 'react-router-dom'
import { routes } from 'var'

import classNames from 'classnames'
import { PepperIcon } from '_components'

export const Logo = ({ size }) => {
  const logoClass = classNames({
    logo: true,
    'logo--small': size === 'small',
  })
  return (
    <div className={logoClass}>
      <Link to={routes.home}>
        <PepperIcon name="logo" customSize="10rem" />
      </Link>
    </div>
  )
}
