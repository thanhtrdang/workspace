import React, { useContext, useEffect } from 'react'

import { MenuView } from './MenuView'

import { MenuContext, AuthContext, GameContext } from '_contexts'

import { connect } from 'react-redux'
import { profile_actions } from '_ducks/reducers'

const MenuComponent = ({ requestProfile }) => {
  const { menuVisible } = useContext(MenuContext)
  const { game } = useContext(GameContext)
  const { authed } = useContext(AuthContext)

  const isClientRequired = game === 'apex'
  let timer = null

  useEffect(
    _ => {
      if (authed && isClientRequired) {
        timer = setInterval(requestProfile, 30000)
      }
      return _ => clearInterval(timer)
    },
    [authed, isClientRequired],
  )

  return <MenuView visible={menuVisible} authed={authed} clientVisible={isClientRequired} />
}

const mapDispatch = dispatch => ({
  requestProfile: _ => dispatch(profile_actions.requestProfile()),
})

export const Menu = connect(
  null,
  mapDispatch,
)(MenuComponent)
