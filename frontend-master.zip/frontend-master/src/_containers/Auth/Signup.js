import React from 'react'
import { connect } from 'react-redux'
import { Link, withRouter } from 'react-router-dom'
import { withFormik } from 'formik'
import * as Yup from 'yup'
import ReCAPTCHA from 'react-google-recaptcha'
import { Checkbox, Subtitle, Input, Label, Form, Field, Button } from 'pepper'

import { RECAPTCHA_PUBLIC_KEY } from 'var'

import { routes } from 'var'

import { auth_actions } from '_ducks/reducers'

import { ValidationError, PepperIcon } from '_components'
import { withAuth } from '_components/Auth'

import { LoginSignupWrapper } from './LoginSignupWrapper'

const recaptchaRef = React.createRef()

class SignupComponent extends React.Component {
  render = (
    { values, touched, errors, isSubmitting, handleChange, handleSubmit, setFieldValue, status } = this.props,
  ) => (
    <LoginSignupWrapper>
      <div className="signup">
        {status && status.completed ? (
          <div>
            <Subtitle color="green" align="center" margin={7}>
              Thank you for signing up. Please check your email and follow the instructions to verify your account.
            </Subtitle>
            <div className="flex-center mt">
              <Link to={routes.login}>
                <Button primary>Login</Button>
              </Link>
            </div>
          </div>
        ) : (
          <Form onSubmit={handleSubmit} className="vflex-center">
            <Field>
              <Label />
              <Input
                label="Email address"
                placeholder="Enter your email address"
                name="email"
                value={values.email}
                onChange={handleChange}
                size="medium"
              />
              <ValidationError errors={errors} touched={touched} field="email" />
            </Field>

            <Field>
              <Input
                label="Username"
                placeholder="Create a username"
                name="username"
                value={values.username}
                onChange={handleChange}
                size="medium"
                autoCorrect="off"
                autoCapitalize="none"
              />
              <ValidationError errors={errors} touched={touched} field="username" />
            </Field>

            <Field>
              <Input
                label="Password"
                placeholder="Create a password"
                name="password"
                type="password"
                value={values.password}
                onChange={handleChange}
                size="medium"
              />
              <ValidationError errors={errors} touched={touched} field="password" />
            </Field>
            <Field>
              <Input
                label="Confirm new password"
                placeholder="Re-enter your password"
                id="password_confirm"
                type="password"
                value={values.password_confirm || ''}
                onChange={handleChange}
              />
              <ValidationError errors={errors} touched={touched} field="password_confirm" />
            </Field>
            <Field>
              <Input
                label="Referral code (optional)"
                placeholder="Enter your referral code"
                name="referral_code"
                value={values.referral_code}
                onChange={handleChange}
                size="medium"
              />
              <ValidationError errors={errors} touched={touched} field="referral_code" />
            </Field>

            <Field>
              <Checkbox
                text={
                  <span htmlFor="consent">
                    I agree to{' '}
                    <a target="_blank" href="https://www.ludare.com/terms/" rel="noopener noreferrer">
                      Pepper's T&Cs&nbsp;
                    </a>
                    and{' '}
                    <a target="_blank" href="https://www.ludare.com/privacy/" rel="noopener noreferrer">
                      Privacy Policy&nbsp;
                    </a>
                    <PepperIcon name="external" size="atom" />
                  </span>
                }
                id="consent"
                name="consent"
                value={values.consent}
                onChange={handleChange}
              />
              <ValidationError errors={errors} touched={touched} field="consent" />
            </Field>

            <Field>
              {RECAPTCHA_PUBLIC_KEY && (
                <ReCAPTCHA
                  sitekey={RECAPTCHA_PUBLIC_KEY}
                  onChange={response => {
                    setFieldValue('recaptcha', response)
                  }}
                  className="recaptcha"
                  ref={recaptchaRef}
                />
              )}
              <ValidationError errors={errors} touched={touched} field="recaptcha" />
              <ValidationError errors={errors} touched={touched} />
            </Field>

            <Field className="flex-center">
              <Button primary type="submit" disabled={isSubmitting}>
                Sign Up
              </Button>
            </Field>

            <ValidationError errors={errors} touched={touched} />
          </Form>
        )}
      </div>
    </LoginSignupWrapper>
  )
}

const SignupFormik = withFormik({
  mapPropsToValues: props => ({
    username: '',
    password: '',
    password_confirm: '',
    email: '',
    referral_code: props.match.params.referral_code || '',
    consent: false,
    recaptcha: '',
  }),
  validationSchema: Yup.object().shape({
    email: Yup.string()
      .required('Email is required!')
      .email('Invalid email address.'),
    username: Yup.string().required('Username is required.'),
    password: Yup.string()
      .required('Password is required.')
      .min(8, 'Password needs to have at least 8 characters.'),
    password_confirm: Yup.string()
      .required('Password confirmation is required.')
      .oneOf([Yup.ref('password'), null], "Password doesn't match."),
    consent: Yup.bool().is([true], 'You have to agree with our Terms and Conditions.'),
    recaptcha: Yup.string()
      .required('You have to verify reCAPTCHA.')
      .notOneOf([null], 'Your recaptcha is expired, please verify again.'),
  }),
  handleSubmit: (
    { username, password, email, referral_code, recaptcha },
    { props, setErrors, setSubmitting, setStatus },
  ) => {
    if (props.authed) {
      setErrors({ non_field_errors: ['You are already logged in.'] })
    } else {
      props.submit({
        username: username.trim(),
        password,
        email: email.toLowerCase().trim(),
        referral_code,
        recaptcha,
        setErrors,
        setSubmitting,
        setStatus,
        recaptchaRef,
      })
    }
  },
  displayName: 'SignupForm',
})(SignupComponent)

const mapDispatch = dispatch => ({
  submit: ({
    username,
    password,
    email,
    referral_code,
    recaptcha,
    setErrors,
    setSubmitting,
    setStatus,
    recaptchaRef,
  }) =>
    dispatch(
      auth_actions.signup({
        username,
        password,
        email,
        referral_code,
        recaptcha,
        setErrors,
        setSubmitting,
        setStatus,
        recaptchaRef,
      }),
    ),
})

export const Signup = connect(
  null,
  mapDispatch,
)(withRouter(withAuth(SignupFormik)))
