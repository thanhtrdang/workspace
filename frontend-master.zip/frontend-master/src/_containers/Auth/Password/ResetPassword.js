import React from 'react'
import { Button, Title, Container, Segment, Form, Input, Field } from 'pepper'
import { withRouter } from 'react-router-dom'
import { withFormik } from 'formik'
import * as Yup from 'yup'
import * as R from 'ramda'
import { routes } from 'var'

import { ValidationError, withAsync } from '_components'

import { generateAsyncRequest } from 'helpers/invoker'

import { services } from '_ducks/services'

const ResetPasswordComponent = ({ values, touched, errors, isSubmitting, handleChange, handleSubmit }) => (
  <div className="login-signup">
    <Container center className="flex-center">
      <Segment theme="light">
        <Title>New Password</Title>
        <Form onSubmit={handleSubmit}>
          <Field>
            <Input
              label="New password"
              placeholder="Enter your new password..."
              id="new_password"
              type="password"
              value={values.new_password || ''}
              onChange={handleChange}
            />
            <ValidationError errors={errors} touched={touched} field="new_password" />
          </Field>
          <Field>
            <Input
              label="Confirm new password"
              placeholder="Re-enter your new password..."
              id="password_confirm"
              type="password"
              value={values.password_confirm || ''}
              onChange={handleChange}
            />
            <ValidationError errors={errors} touched={touched} field="password_confirm" />
          </Field>
          <ValidationError errors={errors} touched={touched} field="uid" />
          <ValidationError errors={errors} touched={touched} field="token" />
          <ValidationError errors={errors} touched={touched} />
          <div className="mt">
            <Button primary type="submit" disabled={isSubmitting} className="center">
              Reset Password
            </Button>
          </div>
        </Form>
      </Segment>
    </Container>
  </div>
)

export const ResetPassword = withRouter(
  withAsync(
    withFormik({
      mapPropsToValues: props => ({
        new_password: '',
        password_confirm: '',
        uid: '',
        token: '',
      }),
      validationSchema: Yup.object().shape({
        new_password: Yup.string()
          .required('New password is required.')
          .min(8, 'Password needs to have at least 8 characters.'),
        password_confirm: Yup.string()
          .required('New password confirmation is required.')
          .oneOf([Yup.ref('new_password'), null], "Password doesn't match."),
      }),
      handleSubmit: ({ new_password }, { props, setErrors, setSubmitting, resetForm }) => {
        const uid = R.path(['match', 'params', 'uid'], props)
        const token = R.path(['match', 'params', 'token'], props)
        submit(new_password, uid, token, setErrors, setSubmitting, resetForm, props)
      },
      displayName: 'ForgotPasswordForm',
    })(ResetPasswordComponent),
  ),
)

// Async call to API
const submit = async (new_password, uid, token, setErrors, setSubmitting, resetForm, props) => {
  try {
    await generateAsyncRequest({
      service: services.auth.resetPassword,
      data: { new_password, uid, token },
    })
    props.handleSuccess({ message: 'You have requested to reset password successfully.', setSubmitting, resetForm })
    setTimeout(_ => props.history.push(routes.login), 1500)
  } catch (error) {
    props.handleError({ error, name: 'ASYNC_RESET_PASSWORD_REQUEST', setErrors, setSubmitting })
  }
}
