import React from 'react'
import { Form, Field, Input, Divider, Button } from 'pepper'
import { withFormik } from 'formik'
import * as Yup from 'yup'
import { services } from '_ducks/services'
import { generateAsyncRequest } from 'helpers/invoker'

import { ValidationError, withAsync } from '_components'
import { withAuth } from '_components/Auth'

const ChangePasswordComponent = ({ values, touched, errors, isSubmitting, handleChange, handleSubmit }) => (
  <div className="change-password">
    <Form onSubmit={handleSubmit}>
      <Field>
        <Input
          label="Current password"
          placeholder="Enter your current password"
          id="current_password"
          type="password"
          value={values.current_password || ''}
          onChange={handleChange}
        />
        <ValidationError errors={errors} touched={touched} field="current_password" />
      </Field>
      <Field>
        <Input
          label="New password"
          placeholder="Enter your new password"
          id="new_password"
          type="password"
          value={values.new_password || ''}
          onChange={handleChange}
        />
        <ValidationError errors={errors} touched={touched} field="new_password" />
      </Field>
      <Field>
        <Input
          label="Confirm new password"
          placeholder="Re-enter your new password"
          id="password_confirm"
          type="password"
          value={values.password_confirm || ''}
          onChange={handleChange}
        />
        <ValidationError errors={errors} touched={touched} field="password_confirm" />
      </Field>
      <ValidationError errors={errors} touched={touched} />
      <Button primary type="submit" disabled={isSubmitting}>
        Submit
      </Button>
    </Form>
  </div>
)

export const ChangePassword = withAuth(
  withAsync(
    withFormik({
      mapPropsToValues: props => ({
        current_password: '',
        new_password: '',
        password_confirm: '',
      }),
      validationSchema: Yup.object().shape({
        current_password: Yup.string().required('Current password is required.'),
        new_password: Yup.string()
          .required('New password is required.')
          .min(8, 'Password needs to have at least 8 characters.')
          .notOneOf([Yup.ref('current_password')], 'Your new password is the same with the old one.')
          .notOneOf([null, ''], 'New password is required.'),

        password_confirm: Yup.string()
          .required('New password confirmation is required.')
          .oneOf([Yup.ref('new_password'), null], "Password doesn't match."),
      }),
      handleSubmit: async ({ current_password, new_password }, { props, setErrors, setSubmitting, resetForm }) => {
        try {
          await generateAsyncRequest({
            service: services.auth.changePassword,
            token: props.token,
            data: { current_password, new_password },
          })
          props.handleSuccess({ message: 'Your password has been updated successfully.', setSubmitting, resetForm })
        } catch (error) {
          props.handleError({ error, name: 'ASYNC_CHANGE_PASSWORD_REQUEST', setErrors, setSubmitting })
        }
      },
      displayName: 'ChangePasswordForm',
    })(ChangePasswordComponent),
  ),
)
