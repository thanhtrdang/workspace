import React from 'react'
import { Container, Segment, Form, Field, Input, Button } from 'pepper'
import { withFormik } from 'formik'
import * as Yup from 'yup'

import { ValidationError, withAsync } from '_components'

import { generateAsyncRequest } from 'helpers/invoker'

import { Title, Subtitle, Divider } from 'pepper'
import { services } from '_ducks/services'

const ForgotPasswordComponent = ({ values, touched, errors, isSubmitting, handleChange, handleSubmit }) => (
  <div className="login-signup">
    <Container center className="flex-center">
      <Segment theme="dark">
        <Title>Forgot Password?</Title>
        <Subtitle color="green">Please enter your email address to request a password reset.</Subtitle>
        <Form onSubmit={handleSubmit}>
          <Field>
            <Input
              label="Email address"
              placeholder="Enter your email address"
              name="email"
              value={values.email || ''}
              onChange={handleChange}
            />
            <ValidationError errors={errors} touched={touched} field="email" />
          </Field>
          <Divider invisible />
          <Button primary type="submit" disabled={isSubmitting} className="center">
            Submit
          </Button>
        </Form>
      </Segment>
    </Container>
  </div>
)

const ForgotPasswordFormik = withFormik({
  mapPropsToValues: props => ({
    email: '',
  }),
  validationSchema: Yup.object().shape({
    email: Yup.string()
      .required('Email is required.')
      .email('Invalid email address.'),
  }),
  handleSubmit: async ({ email }, { props, setErrors, setSubmitting, resetForm }) => {
    const refinedEmail = email.toLowerCase().trim()
    try {
      await generateAsyncRequest({
        service: services.auth.forgotPassword,
        data: { email: refinedEmail },
      })
      props.handleSuccess({ message: 'You have requested to reset password successfully.', setSubmitting, resetForm })
    } catch (error) {
      props.handleError({ error, name: 'ASYNC_FORGOT_PASSWORD_REQUEST', setErrors, setSubmitting })
    }
  },
  displayName: 'ForgotPasswordForm',
})(ForgotPasswordComponent)

export const ForgotPassword = withAsync(ForgotPasswordFormik)
