import React from 'react'
import { PepperIcon } from '_components'

// -------------------------------- Not in use at the moment ---------------------------------- //
class DELETE_VerifyBarComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      visible: true,
    }
  }

  close = _ => this.setState({ visible: false })

  render = _ =>
    this.state.visible ? (
      <div className="verify-bar bar">
        <div className="verify-bar__text">
          <PepperIcon name="warning" />
          Your account is unverified, please check your email for instructions.
        </div>
        <PepperIcon name="close" className="close-button" onClick={this.close} />
      </div>
    ) : (
      ''
    )
}

export const VerifyBar = VerifyBarComponent
