import React, { useState, useEffect } from 'react'
import { withRouter } from 'react-router-dom'
import { routes } from 'var'

import { generateAsyncRequest } from 'helpers/invoker'
import { services } from '_ducks/services'

import { PepperIcon, withAsync } from '_components'
import { Subtitle, Segment, Container } from 'pepper'

const VerifyComponent = ({ match, handleError, history }) => {
  const [init, setInit] = useState(false)
  const [message, setMessage] = useState(1)
  const [loading, setLoading] = useState(2)
  const [verification, setVerification] = useState(3)

  const setErrors = error =>
    setMessage(
      error.uid ||
        error.token ||
        (error.non_field_errors && error.non_field_errors[0]) ||
        'You might have already verified your account or entered a wrong verification code. Please contact us for more details.',
    )

  const verifyUser = async _ => {
    try {
      await generateAsyncRequest({
        service: services.auth.verify,
        data: { uid: match.params.uid, token: match.params.token },
      })
      setLoading(false)
      setVerification(true)
      setTimeout(_ => history.push(routes.login), 1500)
    } catch (error) {
      setVerification(false)
      setLoading(false)
      setErrors(error)
      handleError({ error, name: 'ASYNC_VERIFY_REQUEST', custom401: _ => setErrors(error) })
    }
  }

  useEffect(_ => {
    if (!init) {
      setInit(true)
      verifyUser()
    }
  })

  return (
    <div className="login-signup">
      <Container center>
        <Segment theme="light">
          {loading ? (
            <div className="vflex-center">
              <PepperIcon name="loading" size="large" className="pa6" noMargin={true} />
              <Subtitle size="large">Your account is being verified. Please wait...</Subtitle>
            </div>
          ) : verification ? (
            <div className="vflex-center">
              <PepperIcon name="alert_success" size="large" className="pa6" noMargin />
              <Subtitle size="large" color="green">
                Thank you. Your account is verified.
              </Subtitle>
            </div>
          ) : (
            <div>
              <Subtitle size="large" color="red">
                {message}
              </Subtitle>
            </div>
          )}
        </Segment>
      </Container>
    </div>
  )
}

export const Verify = withAsync(withRouter(VerifyComponent))
