import React from 'react'
import { ResendForm } from './ResendForm'
import { Title, Subtitle, Divider, Container, Segment } from 'pepper'

export const ResendActivationEmail = _ => (
  <div className="login-signup">
    <Container center>
      <div className="resend-email__inner">
        <Segment theme="dark">
          <div className="resend-email__modal">
            <Title>Resend Activation Email</Title>
            <Subtitle color="green">Please enter your email address.</Subtitle>
            <Divider invisible />
            <ResendForm />
          </div>
        </Segment>
      </div>
    </Container>
  </div>
)
