import React from 'react'
import { Button, Form, Input, Field } from 'pepper'
import { withFormik } from 'formik'
import * as Yup from 'yup'
import ReCAPTCHA from 'react-google-recaptcha'

import { RECAPTCHA_PUBLIC_KEY } from 'var'
import { generateAsyncRequest } from 'helpers/invoker'
import { services } from '_ducks/services'
import { ValidationError, withAsync } from '_components'
import { Subtitle } from 'pepper'

const recaptchaRef = React.createRef()

const ResendFormComponent = ({
  values,
  touched,
  errors,
  isSubmitting,
  handleChange,
  handleSubmit,
  setFieldValue,
  status,
}) =>
  status === 'success' ? (
    <Subtitle color="green">Your email has been sent successfully.</Subtitle>
  ) : (
    <Form className="resend-email__form" onSubmit={handleSubmit}>
      <Field>
        <Input
          className="resend-email__email-input"
          placeholder="Enter your email address"
          id="email"
          name="email"
          value={values.email}
          onChange={handleChange}
        />
        <ValidationError errors={errors} touched={touched} field="email" />
      </Field>
      <Field>
        <ReCAPTCHA
          sitekey={RECAPTCHA_PUBLIC_KEY}
          ref={recaptchaRef}
          onChange={response => {
            setFieldValue('recaptcha', response)
          }}
          className="recaptcha"
        />
      </Field>
      <ValidationError errors={errors} touched={touched} field="recaptcha" />
      <ValidationError errors={errors} touched={touched} />
      <Button primary type="submit" disabled={isSubmitting || status === 'success'}>
        {isSubmitting ? 'Sending' : 'Send Activation Email'}
      </Button>
    </Form>
  )

export const ResendForm = withAsync(
  withFormik({
    mapPropsToValues: props => ({
      email: '',
      recaptcha: '',
    }),
    validationSchema: Yup.object().shape({
      email: Yup.string()
        .required('Email is required!')
        .email('Invalid email address.'),
      recaptcha: Yup.mixed()
        .required('You have to verify reCAPTCHA.')
        .notOneOf([null], 'Your recaptcha is expired, please try again.'),
    }),
    handleSubmit: async ({ email, recaptcha }, { props, setErrors, setSubmitting, resetForm, setStatus }) => {
      try {
        await generateAsyncRequest({
          service: services.auth.resendActivationEmail,
          data: { email, recaptcha },
        })
        resetForm({})
        setStatus('success')
        setSubmitting(false)
      } catch (error) {
        recaptchaRef.current.reset()
        props.handleError({ error, name: 'ASYNC_RESEND_ACTIVATION_EMAIL_REQUEST', setErrors, setSubmitting })
      }
    },
    displayName: 'ResendForm',
  })(ResendFormComponent),
)
