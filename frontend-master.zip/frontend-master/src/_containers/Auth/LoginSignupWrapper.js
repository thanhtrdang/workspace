import React from 'react'
import { NavLink } from 'react-router-dom'
import { Container, Segment } from 'pepper'
import { routes } from 'var'

export const LoginSignupWrapper = ({ children }) => (
  <div className="login-signup">
    <Container center className="flex-center">
      <Segment theme="dark" className="login-signup__segment">
        <div className="login-signup__tabs">
          <NavLink to={routes.signup} className="login-signup__tab" activeClassName="login-signup__tab--active">
            Sign up
          </NavLink>
          <NavLink to={routes.login} className="login-signup__tab" activeClassName="login-signup__tab--active">
            Login
          </NavLink>
        </div>
        {children}
      </Segment>
    </Container>
  </div>
)
