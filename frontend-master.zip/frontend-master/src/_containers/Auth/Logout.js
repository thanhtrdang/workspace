import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import { connect } from 'react-redux'
import { Redirect } from 'react-router'

import { routes } from 'var'

import { auth_actions } from '_ducks/reducers'

class LogoutComponent extends Component {
  componentDidMount() {
    this.props.logout()
  }

  render() {
    return <Redirect to={routes.login} />
  }
}

const mapDispatch = dispatch => ({
  logout: _ => dispatch(auth_actions.logout()),
})

export const Logout = connect(
  null,
  mapDispatch,
)(withRouter(LogoutComponent))
