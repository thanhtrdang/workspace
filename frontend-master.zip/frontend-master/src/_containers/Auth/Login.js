import React from 'react'
import { connect } from 'react-redux'
import { withRouter } from 'react-router-dom'
import { Link } from 'react-router-dom'
import { withFormik } from 'formik'
import * as Yup from 'yup'
import { Input, Field, Title, Form, Button, Subtitle } from 'pepper'

import { routes } from 'var'
import { auth_actions } from '_ducks/reducers'

import { ValidationError } from '_components'
import { withAuth } from '_components/Auth'

import { LoginSignupWrapper } from './LoginSignupWrapper'

class LoginComponent extends React.Component {
  render = ({ values, touched, errors, isSubmitting, handleChange, handleSubmit } = this.props) => (
    <LoginSignupWrapper>
      <div className="login">
        <Form onSubmit={handleSubmit} className="vflex-center">
          <Field>
            <Input
              label="Username"
              placeholder="Enter your username"
              id="username"
              value={values.username}
              onChange={handleChange}
              size="medium"
              autoCorrect="off"
              autoCapitalize="none"
            />
            <ValidationError errors={errors} touched={touched} field="username" />
          </Field>

          <Field>
            <Input
              label="Password"
              placeholder="Enter your password"
              id="password"
              type="password"
              value={values.password}
              onChange={handleChange}
              size="medium"
            />
            <ValidationError errors={errors} touched={touched} field="password" />
          </Field>

          <ValidationError errors={errors} />

          <div className="field mt flex-center">
            <Button primary type="submit" disabled={isSubmitting}>
              Login
            </Button>
          </div>

          <div className="mb">
            <Link to={routes.forgotPassword}>Forgot password?</Link>
          </div>

          <div align="center">
            Didn't receive activation email? <Link to={routes.resendActivationEmail}>Resend email</Link>
          </div>
        </Form>
      </div>
    </LoginSignupWrapper>
  )
}

const LoginFormik = withFormik({
  mapPropsToValues: props => ({
    username: '',
    password: '',
  }),
  validationSchema: Yup.object().shape({
    username: Yup.string().required('Username is required.'),
    password: Yup.string().required('Password is required.'),
  }),
  handleSubmit: ({ username, password }, { props, setErrors, setSubmitting }) => {
    if (props.authed) {
      setErrors({ non_field_errors: ['You are already logged in.'] })
    } else {
      props.submit(username, password, setErrors, setSubmitting)
    }
  },
  displayName: 'LoginForm',
})(LoginComponent)

const mapDispatch = dispatch => ({
  submit: (username, password, setErrors, setSubmitting) =>
    dispatch(auth_actions.login(username.trim(), password, setErrors, setSubmitting)),
})

export const Login = connect(
  null,
  mapDispatch,
)(withRouter(withAuth(LoginFormik)))
