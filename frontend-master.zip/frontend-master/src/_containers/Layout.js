import React from 'react'
import { Route, Switch } from 'react-router-dom'

import { routes } from '../var'
import { gamePaths } from 'var'

import { App } from './App'

import { Login, Logout, Signup, ForgotPassword, ResetPassword, Verify, ResendActivationEmail } from './Auth'
import { MatchInstance } from './Matches'
import { Profile } from './Profile'

import { FAQs } from './Static/FAQs'
import { About } from './Static/About'
import { Contact } from './Static/Contact'

import { UserInstance } from './User/UserInstance'

import { PageNotFound } from './PageNotFound'

// NEW
import { PrivateRoute, GuestRoute, PubgRoute, ApexRoute } from '../_views/_routes'
import { Home, SelectGame } from '../_views/platform'
import {
  ApexHome,
  ApexTournaments,
  ApexTournamentInstance,
  ApexTutorialClient,
  ApexWelcome,
  ApexTutorialTournament,
} from '../_views/games/apex'
import {
  PubgHome,
  PubgTournaments,
  PubgTournamentInstance,
  PubgWelcome,
  PubgVerify,
  PubgTutorialTournament,
} from '../_views/games/pubg'

export const Layout = _ => {
  return (
    <App>
      <Switch>
        {/* GUEST ROUTES */}
        <GuestRoute path={routes.signupWithReferralCode} component={Signup} />
        <GuestRoute path={routes.signup} component={Signup} />
        <GuestRoute path={routes.login} component={Login} />
        {/* PRIVATE ROUTES */}
        <PrivateRoute path={routes.profile} component={Profile} />
        <PrivateRoute path={routes.logout} component={Logout} />
        {/* COMMON ROUTES */}
        <Route path={routes.forgotPassword} component={ForgotPassword} />
        <Route path={routes.resetPassword} component={ResetPassword} />
        <Route path={routes.verify} component={Verify} />
        <Route path={routes.resendActivationEmail} component={ResendActivationEmail} />
        <Route path={routes.faqs} component={FAQs} />
        <Route path={routes.about} component={About} />
        <Route path={routes.contact} component={Contact} />

        <Route path={routes.user} component={UserInstance} />
        <Route path={routes.matchInstance} component={MatchInstance} />

        {/* ----------------------------- NEW ROUTES ------------------------------- */}

        <Route exact path={routes.home} component={Home} />
        <PrivateRoute exact path={routes.selectGame} component={SelectGame} />

        {/* PUBG */}
        <PrivateRoute path={gamePaths.pubg.welcome} component={PubgWelcome} />
        <PrivateRoute path={gamePaths.pubg.tutorial_tournament} component={PubgTutorialTournament} />
        <PrivateRoute path={gamePaths.pubg.tournament_instance} component={PubgTournamentInstance} />

        <PubgRoute path={gamePaths.pubg.verify} component={PubgVerify} />
        <PubgRoute exact path={gamePaths.pubg.home} component={PubgHome} />
        <PubgRoute exact path={gamePaths.pubg.tournaments} component={PubgTournaments} />

        {/* APEX */}
        <PrivateRoute path={gamePaths.apex.welcome} component={ApexWelcome} />
        <PrivateRoute path={gamePaths.apex.tutorial_tournament} component={ApexTutorialTournament} />
        <PrivateRoute path={gamePaths.apex.tournament_instance} component={ApexTournamentInstance} />
        <PrivateRoute path={gamePaths.apex.client} component={ApexTutorialClient} />

        <ApexRoute exact path={gamePaths.apex.home} component={ApexHome} />
        <ApexRoute exact path={gamePaths.apex.tournaments} component={ApexTournaments} />

        <Route render={PageNotFound} />
      </Switch>
    </App>
  )
}
