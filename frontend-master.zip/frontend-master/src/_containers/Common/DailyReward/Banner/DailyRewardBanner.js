import React, { Fragment } from 'react'
import { ClaimButtonBanner } from './ClaimButtonBanner_PS'
import { DailyRewardCT } from '../DailyRewardCT'

export const DailyRewardBanner = _ => (
  <DailyRewardCT>
    <DailyRewardPS />
  </DailyRewardCT>
)

export const DailyRewardPS = ({ canClaim, amount, currency, isCounting, handleClaim }) => (
  <Fragment>
    {(canClaim || isCounting === false) && (
      <ClaimButtonBanner amount={amount} currency={currency} canClaim={canClaim} handleClaim={handleClaim} />
    )}
  </Fragment>
)
