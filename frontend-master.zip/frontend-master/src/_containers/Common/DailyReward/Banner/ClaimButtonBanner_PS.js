import React from 'react'
import { withFormik } from 'formik'
import { Form, Button, Subtitle } from 'pepper'
import { ValidationError, PepperIcon } from '_components'
import * as R from 'ramda'

const ClaimButtonComponent = ({ amount, currency, canClaim, errors, isSubmitting, handleSubmit }) => (
  <React.Fragment>
    {R.isEmpty(errors) ? (
      <Form onSubmit={handleSubmit}>
        <div className="claim-banner">
          <PepperIcon name="token" size="tiny" />{' '}
          <Subtitle margin={0}>
            Your daily reward of {amount} {currency} is ready
          </Subtitle>
          <Button primary type="submit" disabled={!canClaim || isSubmitting} className="claim-banner__button">
            Claim
          </Button>
        </div>
      </Form>
    ) : (
      <ValidationError errors={errors} />
    )}
  </React.Fragment>
)

export const ClaimButtonBanner = withFormik({
  handleSubmit: (_, { props, setErrors, setSubmitting }) => {
    props.handleClaim(setErrors, setSubmitting)
  },
  displayName: 'ClaimButtonHeader',
})(ClaimButtonComponent)
