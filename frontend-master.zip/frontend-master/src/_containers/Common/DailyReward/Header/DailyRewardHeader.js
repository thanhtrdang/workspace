import React from 'react'
import { PepperIcon } from '_components'

export const DailyRewardHeader = ({ credit, currency }) =>
  credit ? (
    <div className="daily-reward-header">
      <div className="daily-reward-header__credit">
        <PepperIcon name="token" size="tiny" />
        <span>
          {credit} {currency}
        </span>
      </div>
    </div>
  ) : (
    ''
  )
