import React from 'react'
import { withFormik } from 'formik'
import { Form, Button } from 'pepper'
import { ValidationError, PepperIcon } from '_components'
import * as R from 'ramda'

const ClaimButtonHeaderComponent = ({
  amount,
  currency,
  canClaim,
  handleClaim,

  values,
  touched,
  errors,
  isSubmitting,
  handleChange,
  handleSubmit,
  setFieldValue,
}) => (
  <div className="claim-button-header">
    {R.isEmpty(errors) ? (
      <Form onSubmit={handleSubmit}>
        <Button primary type="submit" disabled={!canClaim || isSubmitting}>
          <PepperIcon name="token" size="mini" /> Claim {amount} {currency}
        </Button>
      </Form>
    ) : (
      <ValidationError errors={errors} />
    )}
  </div>
)

export const ClaimButtonHeader = withFormik({
  handleSubmit: (_, { props, setErrors, setSubmitting }) => {
    props.handleClaim(setErrors, setSubmitting)
  },
  displayName: 'ClaimButtonHeader',
})(ClaimButtonHeaderComponent)
