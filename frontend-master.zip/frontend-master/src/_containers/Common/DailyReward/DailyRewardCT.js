import React from 'react'
import { connect } from 'react-redux'
import moment from 'moment'

import {
  get_credit,
  isDailyCreditsAvailable,
  getAvailableRewardAmount,
  getNextRewardAmount,
  getNextRewardDate,
  get_credit_currency,
  wallet_actions,
} from '_ducks/reducers'

class DailyRewardCTComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      isCounting: null,
    }
  }
  componentDidMount = async ({ checkDailyReward, nextTime } = this.props) => {
    await checkDailyReward()
    if (moment().isBefore(moment(nextTime))) {
      this.setState({ isCounting: true })
    }
  }

  handleCountingFinish = _ => {
    this.setState({ isCounting: false })
  }

  handleClaim = _ => {
    this.props.claimDailyReward()
    this.setState({ isCounting: true })
  }

  renderChildren = _ => {
    const { credit, canClaim, amount, nextAmount, nextTime, currency, children } = this.props
    const { isCounting } = this.state

    return React.Children.map(children, child =>
      React.cloneElement(child, {
        credit,
        canClaim,
        amount,
        nextAmount,
        nextTime,
        currency,
        isCounting,
        handleCountingFinish: this.handleCountingFinish,
        handleClaim: this.handleClaim,
      }),
    )
  }

  render = _ => {
    return this.renderChildren()
  }
}
const mapState = state => ({
  credit: get_credit(state),
  canClaim: isDailyCreditsAvailable(state),
  amount: getAvailableRewardAmount(state),
  nextAmount: getNextRewardAmount(state),
  nextTime: getNextRewardDate(state),
  currency: get_credit_currency(state),
})

const mapDispatch = dispatch => ({
  checkDailyReward: _ => dispatch(wallet_actions.checkDailyReward()),
  claimDailyReward: (setErrors, setSubmitting) => dispatch(wallet_actions.claimDailyReward(setErrors, setSubmitting)),
})

export const DailyRewardCT = connect(
  mapState,
  mapDispatch,
)(DailyRewardCTComponent)
