import React from 'react'
import { withFormik } from 'formik'
import { Form, Button } from 'pepper'
import { ValidationError } from '_components'
import * as R from 'ramda'

const ClaimButtonProfileComponent = ({
  amount,
  currency,
  canClaim,
  handleClaim,

  values,
  touched,
  errors,
  isSubmitting,
  handleChange,
  handleSubmit,
  setFieldValue,
}) => (
  <div className="claim-button-profile">
    {R.isEmpty(errors) ? (
      <Form onSubmit={handleSubmit} className="flex-center">
        <Button primary type="submit" disabled={!canClaim && isSubmitting}>
          Claim {amount} {currency}
        </Button>
      </Form>
    ) : (
      <ValidationError errors={errors} />
    )}
  </div>
)

export const ClaimButtonProfile = withFormik({
  handleSubmit: (_, { props, setErrors, setSubmitting }) => {
    props.handleClaim(setErrors, setSubmitting)
  },
  displayName: 'ClaimButtonHeader',
})(ClaimButtonProfileComponent)
