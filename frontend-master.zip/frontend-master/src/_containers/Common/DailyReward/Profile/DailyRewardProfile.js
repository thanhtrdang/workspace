import React from 'react'
import { OmniCountdown, PepperIcon } from '_components'
import { ClaimButtonProfile } from './ClaimButtonProfile'
import { DailyRewardCT } from '../DailyRewardCT'

export const DailyRewardProfile = _ => (
  <DailyRewardCT>
    <DailyRewardPS />
  </DailyRewardCT>
)

export const DailyRewardPS = ({
  canClaim,
  amount,
  nextTime,
  nextAmount,
  credit,
  currency,
  isCounting,
  handleCountingFinish,
  handleClaim,
}) => {
  return (
    <div className="daily-reward-profile">
      <div className="daily-reward-profile__credit">
        <PepperIcon name="token" size="small" />
        {credit} {currency}
      </div>
      {canClaim || isCounting === false ? (
        <ClaimButtonProfile amount={amount} currency={currency} canClaim={canClaim} handleClaim={handleClaim} />
      ) : (
        <div>
          <div className="daily-reward-profile__bottom-label">
            <div className="ma">
              Next reward: <span className="daily-reward-countdown-time">{nextAmount}</span> {currency}
            </div>
            <OmniCountdown
              endTime={nextTime}
              beforeText="Available in"
              mode="hour"
              afterText=" hr(s)"
              timeClass="daily-reward-countdown-time"
              onFinish={handleCountingFinish}
              finishText=""
            />
          </div>
        </div>
      )}
    </div>
  )
}
