import React from 'react'
import { connect } from 'react-redux'
import { get_username, getBalance, getBalanceCurrency } from '_ducks/reducers'

import { DailyRewardHeader } from './DailyReward/Header/DailyRewardHeader'

import { Link } from 'react-router-dom'
import { routes } from 'var'
import { Title, Button } from 'pepper'

/**
 * Display on PC only
 */
export const ShortcutComponent = ({ balance, balanceCurrency }) => (
  <div>
    {/* Balance */}
    <div
      style={{
        textAlign: 'center',
      }}
      className="onav-submenu__header__item">
      <div className="shortcut__balance">
        ${balance && balance.toFixed(2)} {balanceCurrency}
      </div>
      <div className="shortcut__buttons vflex-center">
        <BalanceButton />
      </div>
    </div>
  </div>
)

/**
 * Display on Mobile only
 */
export const ShortcutMobileComponent = ({ username, balance, balanceCurrency }) => (
  <div className="shortcut-mobile">
    <Title>
      <Link to={routes.profile}>{username}</Link>
    </Title>
    <div className="shortcut-mobile__info">
      {/* <div className="shortcut-mobile__credit">
        <PepperIcon name="token" /> {credit} {creditCurrency}
      </div> */}
      <div className="shortcut-mobile__balance">
        ${balance && balance.toFixed(2)} {balanceCurrency}
      </div>
    </div>

    <div className="shortcut-mobile__buttons vflex-center">
      <DailyRewardHeader />
      <BalanceButton />
    </div>
  </div>
)

const mapState = state => ({
  username: get_username(state),
  balance: getBalance(state),
  balanceCurrency: getBalanceCurrency(state),
})

export const Shortcut = connect(mapState)(ShortcutComponent)
export const ShortcutMobile = connect(mapState)(ShortcutMobileComponent)

// const AnnouncerButton = ({ toggle_announcers, adminAnnouncersVisible }) => (
//   <Button onClick={toggle_announcers} className="shortcut-mobile__announcer-toggle" >
//     {adminAnnouncersVisible ? 'Announcer ON' : 'Announcer OFF'}
//   </Button>
// )

const BalanceButton = _ => (
  <Link to={routes.transactionHistory}>
    <Button className="shortcut-mobile__balance-button mt">Manage Balance</Button>
  </Link>
)
