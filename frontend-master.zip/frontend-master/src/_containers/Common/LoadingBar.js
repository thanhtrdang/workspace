import React from 'react'
import { connect } from 'react-redux'
import { is_any_loading } from '_ducks/reducers'

const LoadingBarComponent = ({ loading }) =>
  loading && (
    <div className="loading-bar">
      <div className="loading-bar__loader" />
    </div>
  )

const mapState = state => ({
  loading: is_any_loading(state),
})

export const LoadingBar = connect(mapState)(LoadingBarComponent)
