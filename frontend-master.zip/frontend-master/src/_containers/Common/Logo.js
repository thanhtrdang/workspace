import React from 'react'
import classNames from 'classnames'
import { PepperIcon } from '_components'

export const Logo = ({ size }) => {
  const logoClass = classNames({
    logo: true,
    'logo--small': size === 'small',
  })
  return (
    <div className={logoClass}>
      <PepperIcon name="logo" customSize="10rem" />
    </div>
  )
}
