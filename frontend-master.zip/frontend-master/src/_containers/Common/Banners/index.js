import React from 'react'
import { AdminAnnouncers } from './AdminAnnouncers'
import { DailyRewardBanner } from '_containers/Common/DailyReward/Banner/DailyRewardBanner'

import { withAuth } from '_components/Auth'

const BannersComponent = ({ authed }) => (
  <div className="banners">
    {authed && <DailyRewardBanner />}
    <AdminAnnouncers />
  </div>
)

export const Banners = withAuth(BannersComponent)
