import React from 'react'
import { Container } from 'pepper'
import { PepperIcon } from '_components'

export const Banner = ({ displayState, handleClose, className, children, fixed }) =>
  displayState !== 'hidden' ? (
    <div className={`banner ${className}`}>
      <Container>{children}</Container>
      {!fixed && <PepperIcon name="close" className="close-button" onClick={handleClose} />}
    </div>
  ) : (
    ''
  )
