import React from 'react'
import { generate } from 'shortid'

import { PepperIcon } from '_components'
import { Banner } from '../Banner'
import { Subtitle } from 'pepper'

export const AdminAnnouncersPT = ({ announcements, handleClose }) => (
  <div className="admin-announcers">
    {/* <Container style={{ position: 'relative' }}>
      <a onClick={handleClose}>
        <PepperIcon name="close" size="mini" className="admin-announcers__close" />
      </a>
    </Container> */}
    {announcements.map(({ title, details, updated_at }, index) => (
      <Banner
        className={`admin-announcer admin-announcer--${(index % 3) + 1}`}
        fixed={true}
        key={generate()}>
        <div className="admin-announcer__inner">
          <PepperIcon name="announcer" size="tiny" />
          {title && (
            <Subtitle size="small" margin={1} color="green">
              {title}:&nbsp;
            </Subtitle>
          )}
          <span
            className="admin-announcer__details"
            dangerouslySetInnerHTML={{ __html: details }}
          />
        </div>
      </Banner>
    ))}
  </div>
)
