import React from 'react'
import { connect } from 'react-redux'

import Tracker from 'helpers/tracker'
import { generateAsyncRequest } from 'helpers/invoker'
import utils from 'helpers/utils'
import { services } from '_ducks/services'

import { is_admin_announcers_visible, pref_actions } from '_ducks/reducers'
import { actions as alertAction } from '_ducks/alert/alert_reducer'

import { AdminAnnouncersPT } from './AdminAnnouncersPT'

class AdminAnnouncersComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      announcements: [],
    }
  }
  componentDidMount = async ({ alert_error, alert_vanish } = this.props) => {
    try {
      const data = await generateAsyncRequest({ service: services.common.announcements })
      this.setState({ announcements: data })
    } catch (error) {
      alert_error(error)
      setTimeout(_ => alert_vanish(), 2300)
      Tracker.log({ error, action: { type: 'ASYNC_ADMIN_ANNOUNCEMENTS_REQUEST' } })
    }
  }

  render = ({ announcements } = this.state, { adminAnnouncerVisible, hideAnnouncers } = this.props) =>
    utils.is_populated(announcements) && adminAnnouncerVisible ? (
      <AdminAnnouncersPT announcements={announcements} handleClose={hideAnnouncers} />
    ) : (
      ''
    )
}
const mapState = state => ({
  adminAnnouncerVisible: is_admin_announcers_visible(state),
})

const mapDispatch = dispatch => ({
  alert_error: error => dispatch(alertAction.alert_error(error)),
  alert_vanish: _ => dispatch(alertAction.alert_vanish()),
  hideAnnouncers: _ => dispatch(pref_actions.hideAnnouncers()),
})

export const AdminAnnouncers = connect(
  mapState,
  mapDispatch,
)(AdminAnnouncersComponent)
