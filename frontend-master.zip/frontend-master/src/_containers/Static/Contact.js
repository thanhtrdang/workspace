import React from 'react'
import { withFormik } from 'formik'
import * as Yup from 'yup'
import ReCAPTCHA from 'react-google-recaptcha'

import { RECAPTCHA_PUBLIC_KEY } from 'var'
import { generateAsyncRequest } from 'helpers/invoker'
import { services } from '_ducks/services'
import { Title } from 'pepper'

import { Button, Textarea, Container, Segment, Form, Input, Field, Subtitle } from 'pepper'
import { ValidationError, withAsync } from '_components'

const recaptchaRef = React.createRef()

const ContactComponent = ({
  values,
  touched,
  errors,
  isSubmitting,
  handleChange,
  handleSubmit,
  setFieldValue,
  status,
}) => (
  <div className="page">
    <div className="contact">
      <Container center>
        <div className="contact__inner">
          <Segment className="contact__segment">
            <Title>Send us a message</Title>
            {status === 'success' ? (
              <Subtitle color="green">Your email has been sent successfully.</Subtitle>
            ) : (
              <Form onSubmit={handleSubmit}>
                <Field>
                  <Input
                    label="Name"
                    placeholder="Enter your full name..."
                    id="name"
                    value={values.name}
                    onChange={handleChange}
                  />
                </Field>
                <ValidationError errors={errors} touched={touched} field="name" />
                <Field>
                  <Input
                    label="Email"
                    placeholder="Enter your email..."
                    id="email"
                    value={values.email}
                    onChange={handleChange}
                  />
                </Field>
                <ValidationError errors={errors} touched={touched} field="email" />
                <Field>
                  <Textarea
                    label="Message"
                    placeholder="Enter your message in here..."
                    id="message"
                    value={values.message}
                    onChange={handleChange}
                  />
                </Field>
                <ValidationError errors={errors} touched={touched} field="message" />
                <Field>
                  <ReCAPTCHA
                    sitekey={RECAPTCHA_PUBLIC_KEY}
                    onChange={response => {
                      setFieldValue('recaptcha', response)
                    }}
                    className="recaptcha"
                    ref={recaptchaRef}
                  />
                </Field>
                <ValidationError errors={errors} touched={touched} field="recaptcha" />
                <ValidationError errors={errors} touched={touched} />

                <div>
                  <Button primary type="submit" disabled={isSubmitting || status === 'success'}>
                    {isSubmitting ? 'Sending' : 'Send'}
                  </Button>
                </div>
              </Form>
            )}
          </Segment>
        </div>
      </Container>
    </div>
  </div>
)

export const Contact = withAsync(
  withFormik({
    mapPropsToValues: props => ({
      name: '',
      email: '',
      message: '',
      recaptcha: '',
    }),
    validationSchema: Yup.object().shape({
      name: Yup.string().required('Name is required.'),
      email: Yup.string()
        .required('Email is required!')
        .email('Invalid email address.'),
      message: Yup.string().required('Message is required.'),
      recaptcha: Yup.mixed()
        .required('You have to verify reCAPTCHA.')
        .notOneOf([null], 'Your recaptcha is expired, please try again.'),
    }),
    handleSubmit: async ({ name, email, message, recaptcha }, { props, setErrors, setSubmitting, setStatus }) => {
      try {
        await generateAsyncRequest({
          service: services.common.contact,
          data: {
            name,
            email,
            message,
            recaptcha,
          },
        })
        setSubmitting(false)
        setStatus('success')
      } catch (error) {
        recaptchaRef.current.reset()
        props.handleError({ error, name: 'ASYNC_CONTACT_REQUEST', setErrors, setSubmitting })
      }
    },
    displayName: 'ContactForm',
  })(ContactComponent),
)
