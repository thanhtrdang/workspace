import React from 'react'
import { generate } from 'shortid'
import { Title, Subtitle, Container } from 'pepper'
import { GetStarted } from '../../_views/platform/home/guest/GetStarted'

const convert = obj => {
  let result = []
  for (let key in obj) {
    result.push({
      q: key,
      a: obj[key],
    })
  }
  return result
}

const accountSetup = {
  'How do I link my account?': (
    <span>
      In order to link your account, you need to go through a verification system so that we can make sure it’s really
      you! To link your account, navigate to the Link Account page on the top Menu. Enter your PUBG account name. From
      here, you will be given a code. You will need to submit a picture of this code next to a screenshot of the
      homepage of the game showing your account name. After that, we can verify and link your account.
    </span>
  ),
  'Why does account linking say my username is already in use?': (
    <span>
      If account linking notifies you that your username is already in use, then your game account name has already been
      submitted and verified to another account in use. Ensure that any other accounts you may have on the platform are
      not utilizing your in-game ID. If you find that your in-game account has been linked to an account you do not own,
      please submit a support ticket and we will get back to you with instructions on how to proceed.
    </span>
  ),
  'My account linking submission was rejected, how do I proceed?': (
    <span>
      If your account is rejected, you will be provided with the reason why. If the account details you provided were
      wrong, please submit the correct information. If you still have trouble with linking your account, please contact{' '}
      <a href="https://peppergg.freshdesk.com/support/home">Support</a>.
    </span>
  ),
}

const accountList = convert(accountSetup)

const prize = {
  'How can I claim my prize?': (
    <span>
      In order to claim your prize, go to the <a href="/profile/withdraw">withdrawal</a> page and request a withdrawal
      for the desired amount - as easy as that! Keep in mind the minimum withdrawal is $60.
    </span>
  ),
  'Is there a fee associated to me winning a prize?': (
    <span>
      For cash prizes, there are no fees associated with withdrawing funds from the platform aside from Paypal
      transaction fees. For physical prizes, there may be fees associated with shipping and handling.
    </span>
  ),
  'How many credits will I receive on a daily basis?': (
    <span>
      2,000 credits are given out daily to each user. To claim your credits, you must log in and click the 'Claim My
      Reward' button on the popup that appears. You receive an extra 200 credits for every consecutive day you log in
      until you reach a maximum of 3,000 credits. If you miss a day logging in you will receive 2,000 credits the next
      time you log in, and your streak will start over again.
    </span>
  ),
  'How to receive tournament payouts?': (
    <span>
      In order to successfully join a tournament or receive a payout, you must ensure that both your Pepper and PUBG
      accounts have been verified. Additionally, you need to start and play at least one match since joining the
      tournament before its end (‘Closed’ status) in order to receive a prize from it.
    </span>
  ),
  'How long will it take to receive my payout?': (
    <span>
      Payouts are processed at the end of the week. Please get in touch with our{' '}
      <a href="https://peppergg.freshdesk.com/support/home">support</a> team if your payout has not been processed.
    </span>
  ),
}

const prizeList = convert(prize)

const tournaments = {
  'How do I join a tournament?': (
    <span>
      In order to register for a tournament, click the ‘Join’ button on any of the tournaments listed on the{' '}
      <a href="/">tournament</a> page once your email address is verified and you have submitted your account for
      linking. Keep in mind that you cannot receive tournament prizes until your in-game account has been fully
      verified.
    </span>
  ),
  'How do I view tournament progress?': (
    <span>
      In order to view tournament progress, navigate to the <a href="/">tournaments</a> page and click on the desired
      tournament. This will give you a view of its rules, participants, and progression.
    </span>
  ),
  'How do I submit my progress?': (
    <span>
      No need to! Game statistics are imported via an API to the platform and are automatically recorded to the
      platform. In order for this to work, all we require you to do is to link your in-game account.
    </span>
  ),
  'When are scores finalized?': (
    <span>
      Scores are finalized when the tournament ends. A countdown can be found in the tournament details showing you how
      much time there is left until the scores are finalized.
    </span>
  ),
  'Can I create a tournament?': (
    <span>
      Stay tuned - we’re looking to let you do this in a future update! Let us know your level of interest in this
      feature by contacting <a href="https://peppergg.freshdesk.com/support/home">Support</a> so that we can prioritize
      our upcoming features based on your input.{' '}
    </span>
  ),
  'What does the tournament status (active, closed, processed) mean?': (
    <span>
      Tournaments can be in the form of one of three main statuses, ‘Active’, ‘Closed’, or ‘Processed’. ‘Active’
      indicates that you can still join the tournament. ‘Closed’ means that the tournament is now closed to new joiners
      and new matches, however some of the matches it is getting statistics from are still finishing; a tournament can
      be in this state for potentially up to 45 minutes. ‘Processed’ indicates that the tournament is fully ended and
      that prizes have been assigned to players. Please note a tournament with the ‘Paused’ status indicates it is under
      maintenance and you will be able to join it once ‘Active’ again.
    </span>
  ),
}

const tournamentsList = convert(tournaments)

const supports = {
  'I would like to contest the win decision, how do I go about this?': (
    <span>
      If you believe that the received statistics are wrong, or if you believe that another user has cheated in one of
      the matches you were involved in, we would like to know more about that. Please submit proof to our{' '}
      <a href="https://peppergg.freshdesk.com/support/home">Support Team</a>. Examples of proof can be a video or image
      with a written explanation.
    </span>
  ),
  'How do I submit a support ticket?': (
    <span>
      In order to submit a support ticket for any issues or feedback you might have, head to the bottom of the page, and
      click <a href="https://peppergg.freshdesk.com/support/home">’Support’</a>. From here you can type in your support
      request and attach relevant documentation. We will get back to you as soon as possible!
    </span>
  ),
}
const supportsList = convert(supports)

const generateFaqs = (list, title) => (
  <div>
    <Subtitle size="large2" color="green" align="center">
      {title}
    </Subtitle>
    {list.map(faq => {
      const key = generate()
      return (
        <div key={key} computer={12} mobile={16}>
          <div className="smoothie-panel">
            <input id={`smoothie-toggle-${key}`} className="smoothie-toggle" type="checkbox" />
            <label htmlFor={`smoothie-toggle-${key}`} className="smoothie-label">
              {faq.q}
              <i className="gl-down-arrow smoothie-caret" />
            </label>
            <div className="smoothie-collapsible-content">
              <p className="smoothie-collapsible-content__text">{faq.a}</p>
            </div>
          </div>
        </div>
      )
    })}
  </div>
)

export const FAQs = _ => (
  <div className="center">
    <GetStarted />
    <div className="faqs">
      <Title margin={9} size="big" align="center" transform="uppercase">
        Frequently Asked Questions
      </Title>
      <div className="faqs_grid">
        <div>{generateFaqs(tournamentsList, 'Tournaments')}</div>
        <div>{generateFaqs(supportsList, 'Support')}</div>
        <div>{generateFaqs(accountList, 'Account Setup')}</div>
        <div>{generateFaqs(prizeList, 'Prizes')}</div>
      </div>
    </div>
  </div>
)
