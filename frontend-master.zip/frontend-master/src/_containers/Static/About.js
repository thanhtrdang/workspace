import React from 'react'
import { Container } from 'pepper'
import { Title, Subtitle, Button } from 'pepper'
import { Link } from 'react-router-dom'
import { routes } from 'var'
import { PepperIcon } from '_components'

export const About = _ => (
  <div className="about">
    <Title size="huge" align="center" margin={9} transform="uppercase" className="about-title">
      About <span className="text--green">P</span>
      <span className="text--pink">E</span>
      <span className="text--yellow">P</span>
      <span className="text--blue">P</span>
      <span className="text--grey">E</span>
      <span className="text--red">R</span>
    </Title>
    <Container className="center about-container">
      <div className="about__inner">
        <div className="about__logo">
          <PepperIcon name="logo_block" customSize="20rem" />
        </div>
        <div>
          <Subtitle size="big" color="yellow" font="stylish">
            Upping everyday competition
          </Subtitle>

          <p>
            Pepper is an esports platform for casual and serious non-professional players to win real cash and prizes by
            playing their favorite competitive games. Our mission is to create new meaning and more reward for
            competitive gamers, everywhere.
          </p>

          <div className="mt7">
            <Link to={routes.home}>
              <Button primary>Enter a Tournament</Button>
            </Link>
          </div>
        </div>
      </div>
    </Container>
  </div>
)
