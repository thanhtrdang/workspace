import React from 'react'
import { PUBGStats_PS } from './Stats/PUBGStats_PS'

export const UserStats_PS = ({ pubgStats, trophies }) => (
  <div className="stats-overview">
    <PUBGStats_PS pubgStats={pubgStats} />
  </div>
)
