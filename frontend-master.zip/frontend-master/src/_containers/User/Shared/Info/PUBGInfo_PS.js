import React, { Fragment } from 'react'
import { routes } from 'var'
import { gamePaths } from 'var'
import { PepperIcon } from '_components/PepperIcon'
import { Link } from 'react-router-dom'
import { Subtitle, Button } from 'pepper'

export const PUBGInfo_PS = ({ isPubgLinked, pubgName, pubgStatus, notes, self }) => {
  // if (!isPubgLinked) return <Loading />
  if (isPubgLinked === false) return <NoPUBG self={self} />

  return (
    <div className="profile__game-info">
      <PUBGInfo pubgName={pubgName} pubgStatus={pubgStatus} />
      {self ? (
        pubgStatus === 'unverified' ? (
          <ButtonLink link={gamePaths.pubg.verify} text="Verify PUBG" />
        ) : pubgStatus === 'pending' ? (
          <Fragment>
            <Note text="Remember to join a tournament and jump right in!" />
            <ButtonLink link={routes.home} text="Find Tournaments" />
          </Fragment>
        ) : (
          pubgStatus === 'rejected' && (
            <Fragment>
              <Note text={notes} />
              <ButtonLink link={gamePaths.pubg.verify} text="Retry" />
            </Fragment>
          )
        )
      ) : (
        ''
      )}
    </div>
  )
}

const NoPUBG = ({ self }) =>
  self ? (
    <div className="profile__game-info">
      <p className="ma">You have no associated PUBG account.</p>
      <div className="flex-center">
        <Link to={gamePaths.pubg.home}>
          <Button primary>Link Account</Button>
        </Link>
      </div>
    </div>
  ) : (
    <p className="profile__game-info">User has not linked PUBG account.</p>
  )

const colors = {
  verified: 'green',
  pending: 'pink',
  rejected: 'red',
  unverified: 'grey',
}

const PUBGInfo = ({ pubgName, pubgStatus }) => (
  <div className="profile__game-info__pubg">
    <div>
      <PepperIcon name="card_pubg" customSize="4rem" />
    </div>
    <div className="profile__game-info__pubg-text">
      <Subtitle size="large" color="white" margin={2}>
        {pubgName}
      </Subtitle>
      <Subtitle transform="capitalize" color={colors[pubgStatus]}>
        {pubgStatus}
      </Subtitle>
    </div>
  </div>
)

const ButtonLink = ({ link, text }) => (
  <div className="flex-center">
    <Link to={link}>
      <Button primary>{text}</Button>
    </Link>
  </div>
)

const Note = ({ text }) => text && <p className="profile__game-info__pubg-note">{text}</p>
