import React from 'react'
import { PepperIcon } from '_components'
import { Link } from 'react-router-dom'
import { routes } from 'var'
import { Title } from 'pepper'

export const UserInfo_PS = ({ username, balance, balanceCurrency, children }) => (
  <div className="user-info">
    <Link to={`${routes.users}/${username}`}>
      <Title align="center" transform="normalcase" color="white" font="normal">
        {username}
      </Title>
    </Link>

    <div className="user-info__avatar">
      <PepperIcon name="avatar" customSize="9rem" />
    </div>
    {balance !== undefined && (
      <div className="user-info__balance">
        <PepperIcon name="home_prize" /> {`$${balance.toFixed(0)} ${balanceCurrency}`}
      </div>
    )}
  </div>
)
