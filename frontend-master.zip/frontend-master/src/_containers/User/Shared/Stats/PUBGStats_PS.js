import React from 'react'
import { generate } from 'shortid'
import utils from 'helpers/utils'

import { Title, Subtitle } from 'pepper'

export const PUBGStats_PS = ({ pubgStats }) => (
  <div className="stats-overview__pubg">
    {utils.is_populated(pubgStats) &&
      pubgStats.map(stat => (
        <div className="segment tiny light vflex-center text--center" key={generate()}>
          <Subtitle align="center">{stat.title}</Subtitle>
          <Title color="green" align="center" margin={0}>
            {stat.content !== undefined ? stat.content : '-'}
          </Title>
        </div>
      ))}
  </div>
)
