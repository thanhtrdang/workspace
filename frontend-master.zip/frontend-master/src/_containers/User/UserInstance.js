import React from 'react'
import { Switch, Route } from 'react-router-dom'
import { Divider } from 'pepper'
import { routes } from 'var'

import { generateAsyncRequest } from 'helpers/invoker'
import { services } from '_ducks/services'
import { OmniTab, withAsync } from '_components'

import { UserInfo_PS } from './Shared/Info/UserInfo_PS'
import { UserStats_CT } from './Instance/UserStats_CT'
import { UserTournamentHistory } from './Instance/UserTournamentHistory'
import { PUBGInfo_PS } from './Shared/Info/PUBGInfo_PS'

const addTabState = link => ({
  pathname: link,
  state: { tab: true },
})
class UserInstanceComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      loading: true,
      username: undefined,
      pubgName: '',
      pubgStatus: '',
    }
  }

  componentDidMount = async ({ handleError, match } = this.props) => {
    try {
      const username = match && match.params && match.params.username
      const data = await generateAsyncRequest({
        service: services.user.publicProfile(username),
      })
      if (data) {
        this.setState({
          username: data.username || null,
          pubgName: data.name,
          pubgStatus: data.verified_status,
          loading: false,
        })
      }
    } catch (error) {
      this.setState({ username: null, loading: false })
      handleError({ error, name: 'ASYNC_USER_PROFILE_REQUEST' })
    }
  }

  render = ({ username, pubgName, pubgStatus } = this.state, { match } = this.props) => {
    const usernameFromURL = match && match.params && match.params.username

    return username === null ? (
      <div className="segment text--center stylish">
        <p>Sorry, we are unable to find this user's profile. </p>
        <p>Are you sure that the username is correct?</p>
      </div>
    ) : (
      <div className="page-profile main-inner">
        <OmniTab>
          <OmniTab.Bar>
            <OmniTab.Link exact to={addTabState(`${routes.users}/${username}`)}>
              Overview
            </OmniTab.Link>

            <OmniTab.Link to={addTabState(`${routes.users}/${usernameFromURL}/tournament-history`)}>
              Tournament History
            </OmniTab.Link>
          </OmniTab.Bar>

          <OmniTab.Content>
            <div className="profile-inner">
              <div className="segment profile__my-info">
                <UserInfo_PS username={username} />
                <Divider size="big" />
                <PUBGInfo_PS isPubgLinked={pubgName ? true : false} pubgName={pubgName} pubgStatus={pubgStatus} />
              </div>
              <div className="segment">
                <Switch>
                  <Route path={routes.user} exact component={UserStats_CT} />
                  <Route path={routes.userTournamentHistory} component={UserTournamentHistory} />
                </Switch>
              </div>
            </div>
          </OmniTab.Content>
        </OmniTab>
      </div>
    )
  }
}

export const UserInstance = withAsync(UserInstanceComponent)
