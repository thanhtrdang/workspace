import React from 'react'
import { UserStats_PS } from '../Shared'
import { ProfileInnerSection_PS } from '_containers/Profile/Shared'

import { generateAsyncRequest } from 'helpers/invoker'
import { services } from '_ducks/services'
import { withAsync } from '_components'
import { SpinnerIcon } from 'pepper/icons/SpinnerIcon'

class UserStatsComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      pubgStats: [],
      loading: true,
      noPubgFound: false,
    }
  }

  componentDidMount = async ({ handleError, match } = this.props) => {
    try {
      const username = match && match.params && match.params.username
      const { kills, wins, kd_ratio, win_rate, headshot_kills, top_tens } = await generateAsyncRequest({
        service: services.user.stats(username),
      })

      this.setState({
        pubgStats: [
          { title: 'Chicken Dinners', content: wins },
          { title: 'Win Rate', content: win_rate },
          { title: 'Kills', content: kills },
          { title: 'K/D Ratio', content: kd_ratio },
          { title: 'Top 10s', content: top_tens },
          { title: 'Headshots', content: headshot_kills },
        ],
        loading: false,
      })
    } catch (error) {
      if (error.response && error.response.status === 400) {
        this.setState({ loading: false, noPubgFound: true })
      } else {
        handleError({ error, name: 'ASYNC_USER_STATS_REQUEST' })
      }
    }
  }

  render = ({ pubgStats, loading, noPubgFound } = this.state) => (
    <div>
      <ProfileInnerSection_PS title="Stats Overview" />
      {loading ? (
        <SpinnerIcon />
      ) : noPubgFound ? (
        <div>No PUBG account found. Stats are not available yet.</div>
      ) : (
        <UserStats_PS pubgStats={pubgStats} />
      )}
    </div>
  )
}

export const UserStats_CT = withAsync(UserStatsComponent)
