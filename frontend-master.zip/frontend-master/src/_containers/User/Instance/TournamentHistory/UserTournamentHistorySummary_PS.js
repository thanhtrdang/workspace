import React from 'react'
import { Title, Subtitle } from 'pepper'

const makeSegment = (title, content) => (
  <div className="segment tiny light">
    <Subtitle align="center">{title}</Subtitle>
    <Title color="green" align="center" margin={0}>
      {content || '-'}
    </Title>
  </div>
)

export const UserTournamentHistorySummary_PS = ({ noTournaments, tournamentWins, averageScore, averageRank }) => (
  <div className="grid mb9">
    {makeSegment('Tournaments Entered', noTournaments)}
    {makeSegment('Tournaments Won', tournamentWins)}
    {/* {makeSegment('Average Score', averageScore)} */}
    {makeSegment('Average Rank', averageRank && `#${averageRank}`)}
  </div>
)
