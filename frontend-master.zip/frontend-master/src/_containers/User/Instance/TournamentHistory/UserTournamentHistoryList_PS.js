import React from 'react'
import { withRouter } from 'react-router-dom'
import utils from 'helpers/utils'
import { Subtitle, Divider } from 'pepper'
import { PepperIcon } from '_components'
import moment from 'moment'

import { datetimeFormatMD, feGameNames } from 'var'
import { generate } from 'shortid'

import { gamePaths } from 'var'

export const UserTournamentHistoryList_PS = ({ tournaments }) => (
  <div>
    {utils.is_populated(tournaments) &&
      tournaments.map(tournament => <TournamentList tournament={tournament} key={generate()} />)}
  </div>
)

const frame = [
  {
    header: 'Rank',
    content: props => (props.rank ? `#${props.rank}` : '-'),
  },
  {
    header: 'Players',
    content: props => props.num_participants,
  },
  {
    header: 'Prize Pool',
    content: props => props.prize_pool && parseInt(props.prize_pool.amount, 10),
  },
  {
    header: 'Ended at',
    content: props => props.ends_at && moment(props.ends_at).format(datetimeFormatMD),
  },
]

const TournamentList = withRouter(({ tournament, history }) => {
  const game = feGameNames[tournament.game.name]

  return (
    <div
      className="segment tiny light mb clickable"
      onClick={_ => history.push(`${gamePaths[game].tournaments}/${tournament.id}`)}>
      <Subtitle size="large" margin={0}>
        {game === 'pubg' ? (
          <PepperIcon name="card_pubg" customSize="2rem" />
        ) : (
          <PepperIcon name="card_apex" customSize="2rem" />
        )}
        {tournament.rules && tournament.rules.name}
      </Subtitle>
      <Divider size="small" />

      <div className="grid mt">
        {frame.map(({ header, content }) => (
          <div key={generate()}>
            <Subtitle margin={1} size="small">
              {header}
            </Subtitle>
            <p className="text--green">{content(tournament)}</p>
          </div>
        ))}
      </div>
    </div>
  )
})
