import React from 'react'

import { generateAsyncRequest } from 'helpers/invoker'
import { services } from '_ducks/services'

import { OmniLoading, withAsync } from '_components'
import { ProfileInnerSection_PS } from '_containers/Profile/Shared/ProfileInnerSection_PS'
import { UserTournamentHistoryList_PS } from './TournamentHistory/UserTournamentHistoryList_PS'
import { UserTournamentHistorySummary_PS } from './TournamentHistory/UserTournamentHistorySummary_PS'

class UserTournamentHistoryComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      loading: true,
    }
  }
  componentDidMount = async ({ handleError, match } = this.props) => {
    try {
      const username = match && match.params && match.params.username
      const { tournaments, num_tournaments, average_score, average_rank, tournament_wins } = await generateAsyncRequest(
        {
          service: services.tournament.requestHistory(username),
        },
      )
      this.setState({
        tournaments,
        num_tournaments,
        average_score,
        average_rank,
        tournament_wins,
        loading: false,
      })
    } catch (error) {
      this.setState({ loading: false })
      handleError({ error, name: 'ASYNC_TOURNAMENT_HISTORY_REQUEST' })
    }
  }

  render = ({ loading, tournaments, num_tournaments, average_score, average_rank, tournament_wins } = this.state) => {
    return (
      <div>
        <OmniLoading loading={loading}>
          <ProfileInnerSection_PS title="Summary" />
          <UserTournamentHistorySummary_PS
            noTournaments={num_tournaments}
            averageScore={average_score}
            tournamentWins={tournament_wins}
            averageRank={average_rank}
          />
          <ProfileInnerSection_PS title="Tournament History" />
          <UserTournamentHistoryList_PS tournaments={tournaments} />
        </OmniLoading>
      </div>
    )
  }
}

export const UserTournamentHistory = withAsync(UserTournamentHistoryComponent)
