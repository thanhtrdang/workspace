import React from 'react'
import { ChangePassword } from '_containers/Auth/Password/ChangePassword'
import { ProfileInnerSection_PS } from './Shared/ProfileInnerSection_PS'
import { MyInfo } from './MyInfo'

export const Profile_Settings = _ => (
  <div className="profile-inner">
    <MyInfo />
    <div className="segment">
      <ProfileInnerSection_PS title="Change Password" />
      <ChangePassword />
    </div>
  </div>
)
