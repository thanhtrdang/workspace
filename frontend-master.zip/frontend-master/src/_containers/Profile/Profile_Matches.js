import React from 'react'
import { MatchesContainer } from '_containers/Matches'
import { ProfileInnerSection_PS } from './Shared/ProfileInnerSection_PS'


export const Profile_Matches = _ => (
    <div className="segment">
      <ProfileInnerSection_PS title="Matches" />
      <MatchesContainer />
    </div>
)
