import React from 'react'
import { ReferAFriend } from './Referrals/ReferAFriend'
import { ProfileInnerSection_PS } from './Shared/ProfileInnerSection_PS'
import { MyInfo } from './MyInfo'

export const Profile_Referrals = _ => (
  <div className="profile-inner">
    <MyInfo />
    <div className="segment">
      <ProfileInnerSection_PS title="Refer a Friend" />
      <ReferAFriend />
    </div>
  </div>
)
