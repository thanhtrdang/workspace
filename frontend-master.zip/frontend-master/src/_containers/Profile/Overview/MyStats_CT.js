import React from 'react'
import { connect } from 'react-redux'

import { get_username } from '_ducks/reducers'
import { UserStats_PS } from '_containers/User/Shared/UserStats_PS'
import { generateAsyncRequest } from 'helpers/invoker'
import { services } from '_ducks/services'
import { OmniLoading, withAsync } from '_components'

class MyStats extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      pubgStats: [],
      loading: true,
      noPubgFound: false,
    }
  }

  componentDidMount = async ({ handleError, username } = this.props) => {
    try {
      const { kills, wins, kd_ratio, win_rate,headshot_kills, top_tens } = await generateAsyncRequest({
        service: services.user.stats(username),
      })

      this.setState({
        pubgStats: [
          { title: 'Chicken Dinners', content: wins },
          { title: 'Kills', content: kills },
          { title: 'K/D Ratio', content: kd_ratio },
          { title: 'Win Rate', content: win_rate },
          { title: 'Top 10s', content: top_tens },
          { title: 'Headshots', content: headshot_kills },
        ],
        loading: false,
      })
    } catch (error) {
      if (error.response && error.response.status === 400) {
        this.setState({ loading: false, noPubgFound: true })
      } else {
        handleError({ error, name: 'ASYNC_USER_STATS_REQUEST' })
      }
    }
  }

  render = ({ pubgStats, loading, noPubgFound } = this.state) => (
    <OmniLoading loading={loading}>
      {noPubgFound ? (
        <div>No PUBG account found. Stats are not available yet.</div>
      ) : (
        <UserStats_PS pubgStats={pubgStats} />
      )}
    </OmniLoading>
  )
}
const mapState = state => ({
  username: get_username(state),
})

export const MyStats_CT = connect(mapState)(withAsync(MyStats))
