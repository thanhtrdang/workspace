import React from 'react'
import { Subtitle, Divider } from 'pepper'

export const ProfileInnerSection_PS = ({ title, children }) => (
  <div>
    <Subtitle size="big" margin={0}>
      {title}
    </Subtitle>
    <Divider size="tiny" />
    <div className="pt7">{children}</div>
  </div>
)
