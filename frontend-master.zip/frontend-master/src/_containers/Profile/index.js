import React from 'react'
import { connect } from 'react-redux'
import { Switch } from 'react-router-dom'

import { routes } from 'var'
import { PrivateRoute } from '_views/_routes'
import { is_pubg_linked } from '_ducks/reducers'
import { actions } from '_ducks/_profile/profile_reducer'

import { OmniTab } from '_components'

// import { Profile_Overview } from './Profile_Overview'
import { Profile_Settings } from './Profile_Settings'
import { Profile_Transaction } from './Profile_Transaction'
import { Profile_Withdraw } from './Profile_Withdraw'
import { Profile_Matches } from './Profile_Matches'
import { Profile_Referrals } from './Profile_Referrals'

const addTabState = link => ({
  pathname: link,
  state: { tab: true },
})
class ProfileComponent extends React.Component {
  componentDidMount = _ => this.props.requestProfile()

  render = ({ isPubgLinked } = this.props) => {
    return (
      <div className="page-profile main-inner">
        <OmniTab>
          <OmniTab.Bar>
            <OmniTab.Link exact to={addTabState(routes.profile)}>
              Refer a friend
            </OmniTab.Link>
            {/* <OmniTab.Link exact to={addTabState(routes.profile)}>
              Overview
            </OmniTab.Link>
            <OmniTab.Link to={addTabState(routes.referrals)}>Refer a Friend</OmniTab.Link> */}
            <OmniTab.Link to={addTabState(routes.profileSettings)}>Settings</OmniTab.Link>

            <OmniTab.Link to={addTabState(routes.withdraw)}>Withdraw</OmniTab.Link>
            <OmniTab.Link to={addTabState(routes.transactionHistory)}>Transactions</OmniTab.Link>

            {isPubgLinked && <OmniTab.Link to={addTabState(routes.myMatches)}>My Matches</OmniTab.Link>}
          </OmniTab.Bar>

          <OmniTab.Content>
            <Switch>
              <PrivateRoute exact path={routes.profile} component={Profile_Referrals} />
              {/* <PrivateRoute exact path={routes.profile} component={Profile_Overview} />
              <PrivateRoute path={routes.referrals} component={Profile_Referrals} /> */}
              <PrivateRoute path={routes.profileSettings} component={Profile_Settings} />
              <PrivateRoute path={routes.myMatches} component={Profile_Matches} />
              <PrivateRoute path={routes.transactionHistory} component={Profile_Transaction} />
              <PrivateRoute path={routes.withdraw} component={Profile_Withdraw} />
            </Switch>
          </OmniTab.Content>
        </OmniTab>
      </div>
    )
  }
}

const mapState = state => ({
  isPubgLinked: is_pubg_linked(state),
})

const mapDispatch = dispatch => ({
  requestProfile: _ => dispatch(actions.requestProfile()),
})

export const Profile = connect(
  mapState,
  mapDispatch,
)(ProfileComponent)
