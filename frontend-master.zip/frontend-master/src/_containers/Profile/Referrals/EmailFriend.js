import React from 'react'
import { Form, Field, Input, Button } from 'pepper'
import * as Yup from 'yup'
import { withFormik } from 'formik'
import ReCAPTCHA from 'react-google-recaptcha'
import { RECAPTCHA_PUBLIC_KEY } from 'var'

import { ValidationError } from '_components'
import { Subtitle } from 'pepper'

const recaptchaRef = React.createRef()

const EmailFriendComponent = ({
  values,
  touched,
  errors,
  isSubmitting,
  handleChange,
  handleSubmit,
  setFieldValue,
  status,
}) => (
  <div className="refer-friend__email segment light">
    <div className="refer-friend__innner">
      <div className="refer-friend__refer__title center">Send your referral code to a friend</div>
      {status && status.completed ? (
        <Subtitle color="green">Your email has been sent successfully.</Subtitle>
      ) : (
        <Form onSubmit={handleSubmit}>
          <Field>
            <Input
              placeholder="Enter your friend's email..."
              name="email"
              value={values.email}
              onChange={handleChange}
              size="medium"
            />
            <ValidationError errors={errors} touched={touched} field="email" />
          </Field>
          <Field>
            {RECAPTCHA_PUBLIC_KEY && (
              <ReCAPTCHA
                sitekey={RECAPTCHA_PUBLIC_KEY}
                onChange={response => {
                  setFieldValue('recaptcha', response)
                }}
                className="refer-friend__email__recaptcha recaptcha"
                ref={recaptchaRef}
              />
            )}
            <ValidationError errors={errors} touched={touched} field="recaptcha" />
            <ValidationError errors={errors} touched={touched} />
          </Field>
          <div className="refer-friend__email__button">
            <Button primary type="submit" disabled={isSubmitting}>
              Send referral code
            </Button>
          </div>
        </Form>
      )}
    </div>
  </div>
)

export const EmailFriend = withFormik({
  mapPropsToValues: props => ({
    email: '',
    referral_code: props.referralCode,
    recaptcha: '',
  }),
  validationSchema: Yup.object().shape({
    email: Yup.string()
      .required('Email is required!')
      .email('Invalid email address.'),
    recaptcha: Yup.mixed()
      .required('You have to verify reCAPTCHA.')
      .notOneOf([null], 'Your recaptcha is expired, please click on the verify checkbox.'),
  }),
  handleSubmit: ({ email, referral_code, recaptcha }, { props, setErrors, setSubmitting, setStatus, resetForm }) => {
    props.handleSubmit({
      email,
      referral_code,
      recaptcha,
      setErrors,
      setSubmitting,
      setStatus,
      resetForm,
      recaptchaRef,
    })
  },
  displayName: 'ReferralForm',
})(EmailFriendComponent)
