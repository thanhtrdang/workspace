import React from 'react'
import { Button } from 'pepper'

import { ReferAFriendCT } from './ReferAFriendCT'
import { EmailFriend } from './EmailFriend'
import { ReferralList } from './ReferralList'

export const ReferAFriend = _ => (
  <ReferAFriendCT>
    <ReferAFriendPS />
  </ReferAFriendCT>
)

export const ReferAFriendPS = ({ referralCode, handleCopy, handleEmailSend, referralList }) => (
  <div className="refer-friend">
    <div className="refer-friend__title">
      Refer a friend and earn <span className="refer-friend__title__amount">2000 GLG</span>!
    </div>

    <p className="refer-friend__desc">
      For each friend that uses code provided, or email link to sign up, you will receive 2000 GLG, letting you enter in
      more tournament!
    </p>

    <div className="refer-friend__refer">
      <div className="refer-friend__referral-code segment light">
        <div className="refer-friend__referral-code__inner">
          <div className="refer-friend__refer__title">Referral code</div>
          <span className="refer-friend__referral-code__text">{referralCode}</span>
          <Button primary className="refer-friend__referral-code__button" onClick={handleCopy}>
            Copy code
          </Button>
        </div>
      </div>
      <EmailFriend handleSubmit={handleEmailSend} referralCode={referralCode} />
    </div>
    <ReferralList referralList={referralList} />
  </div>
)
