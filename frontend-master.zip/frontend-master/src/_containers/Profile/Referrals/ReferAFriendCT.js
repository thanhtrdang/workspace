import React from 'react'
import { connect } from 'react-redux'
import { get_referral_code, get_referrals } from '_ducks/reducers'

import utils from 'helpers/utils'

import { generateAsyncRequest } from 'helpers/invoker'
import { services } from '_ducks/services'

import { withAsync } from '_components'
import { withAuth } from '_components/Auth'

class ReferAFriendComponent extends React.Component {
  handleCopy = e => {
    e.preventDefault()
    const { referralCodes } = this.props
    if (utils.is_populated(referralCodes)) {
      navigator.clipboard.writeText(referralCodes[0])
    }
  }
  renderChild = ({ referralCodes, referralList, handleEmailSend, children } = this.props, { handleCopy } = this) =>
    React.Children.map(children, child =>
      React.cloneElement(child, {
        referralCode: utils.is_populated(referralCodes) ? referralCodes[0] : '',
        referralList,
        handleEmailSend: this.sendReferralEmail,
        handleCopy,
      }),
    )

  render = _ => this.renderChild()

  sendReferralEmail = async (
    { email, referral_code, recaptcha, setErrors, setSubmitting, setStatus, resetForm, recaptchaRef },
    { handleError, token } = this.props,
  ) => {
    try {
      await generateAsyncRequest({
        service: services.user.sendReferralEmail,
        token,
        data: {
          email,
          referral_code,
          recaptcha,
        },
      })
      resetForm({})
      setSubmitting instanceof Function && setSubmitting(false)
      setStatus({ completed: true })
    } catch (error) {
      recaptchaRef.current.reset()
      handleError({ error, name: 'ASYNC_SEND_REFERRAL_EMAIL', setErrors, setSubmitting })
    }
  }
}

const mapState = state => ({
  referralCodes: get_referral_code(state),
  referralList: get_referrals(state),
})

export const ReferAFriendCT = connect(mapState)(withAuth(withAsync(ReferAFriendComponent)))
