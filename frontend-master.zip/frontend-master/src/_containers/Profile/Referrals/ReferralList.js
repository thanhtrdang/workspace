import React from 'react'
import { OmniTable } from '_components'
import utils from 'helpers/utils'
import { datetimeFormat } from 'var'
import moment from 'moment'

export const ReferralList = ({ referralList }) =>
  utils.is_populated(referralList) ? (
    <OmniTable
      data={referralList}
      frame={frame}
      noResultMessage="You have got no referrals yet."
      rowName="player"
      rowsName="players"
      showRank
      showTotal
    />
  ) : (
    ''
  )

const frame = [
  {
    header: 'Referrals',
    content: props => props.username,
  },
  {
    header: 'Joined Date',
    content: props => moment(props.date_joined).format(datetimeFormat),
  },
]
