import React from 'react'
import { TransactionHistory } from '_containers/Balance/MyBalance/TransactionHistory'
import { ProfileInnerSection_PS } from './Shared/ProfileInnerSection_PS'

export const Profile_Transaction = _ => (
  <div className="segment">
    <ProfileInnerSection_PS title="Transaction History" />
    <TransactionHistory />
  </div>
)
