import React from 'react'
import { MyStats_CT } from './Overview/MyStats_CT'
import { ProfileInnerSection_PS } from './Shared/ProfileInnerSection_PS'

import { MyInfo } from './MyInfo'

export const Profile_Overview = _ => (
  <div className="profile-inner">
    <MyInfo />
    <div className="segment">
      <ProfileInnerSection_PS title="Stats Overview" />
      <MyStats_CT />
    </div>
  </div>
)
