import React from 'react'
import { connect } from 'react-redux'

import { is_pubg_linked, get_username, getBalance, getBalanceCurrency } from '_ducks/reducers'

import { Divider } from 'pepper'

import { UserInfo_PS } from '_containers/User/Shared'
import { DailyRewardProfile } from '_containers/Common/Shared'
import { MyPUBGInfo } from './MyPUBGInfo'

class MyInfoComponent extends React.Component {
  render = ({ username, balance, balanceCurrency } = this.props) => (
    <div className="segment profile__my-info">
      <UserInfo_PS username={username} balance={balance} balanceCurrency={balanceCurrency} />
      <div className="user-info__credit">
        <DailyRewardProfile />
      </div>
      <Divider />
      <MyPUBGInfo />
    </div>
  )
}

const mapState = state => ({
  username: get_username(state),
  balance: parseFloat(getBalance(state)),
  balanceCurrency: getBalanceCurrency(state),
})

export const MyInfo = connect(mapState)(MyInfoComponent)
