import React from 'react'
import { connect } from 'react-redux'
import { generateAsyncRequest } from 'helpers/invoker'
import tracker from 'helpers/tracker'

import { is_pubg_linked, get_pubg_name, get_pubg_verification, get_token } from '_ducks/reducers'

import { services } from '_ducks/services'
import { PUBGInfo_PS } from '_containers/User/Shared/Info/PUBGInfo_PS'

class MyPUBGInfoComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      notes: '',
    }
  }
  componentDidMount = async ({ token, isPubgLinked } = this.props) => {
    if (isPubgLinked) {
      try {
        const data = await generateAsyncRequest({
          service: services.pubg.requestCode,
          token,
        })

        if (data.notes) {
          this.setState({ notes: data.notes })
        }
      } catch (error) {
        tracker.log({ error, action: { type: 'ASYNC_PUBG_NOTES_REQUEST' } })
      }
    }
  }
  render = ({ isPubgLinked, pubgName, pubgStatus } = this.props, { notes } = this.state) => (
    <PUBGInfo_PS isPubgLinked={isPubgLinked} pubgName={pubgName} pubgStatus={pubgStatus} notes={notes} self={true} />
  )
}

const mapState = state => ({
  token: get_token(state),
  pubgName: get_pubg_name(state),
  isPubgLinked: is_pubg_linked(state),
  pubgStatus: get_pubg_verification(state),
})

export const MyPUBGInfo = connect(mapState)(MyPUBGInfoComponent)
