import React from 'react'
import { connect } from 'react-redux'
import { Input, Form, Field, Checkbox, Button, Label } from 'pepper'

import { withFormik } from 'formik'
import * as Yup from 'yup'

import { wallet_actions, getBalance, getBalanceCurrency } from '_ducks/reducers'

import { ValidationError, PepperIcon } from '_components'

const WithdrawComponent = ({
  balance,
  currency,
  values,
  touched,
  errors,
  isSubmitting,
  handleChange,
  handleSubmit,
  setFieldValue,
}) => (
  <div className="balance-withdraw">
    <div className="balance-withdraw-inner">
      {/* <div className="balance-withdraw__balance-text title">
        Your current balance is{' '}
        <span className="balance-withdraw__balance">${balance && balance.toFixed(2)}</span>{' '}
        {currency}
      </div> */}

      <Form onSubmit={handleSubmit}>
        <Field>
          <Input
            label="Paypal address"
            placeholder="Enter your PayPal email address..."
            id="email"
            value={values.email}
            onChange={handleChange}
          />
          <div className="balance-withdraw__paypal-note stylish">
            * Please note that PayPal deposits can take up to 2 days in some cases
          </div>
          <ValidationError errors={errors} touched={touched} field="email" />
        </Field>

        <Field>
          <Label>Withdraw amount (minimum: $25 {currency}) </Label>
          <div className="price-box-holder">
            <div className="price-box">
              <Input
                placeholder={values.amount}
                id="amount"
                value={values.amount}
                onChange={handleChange}
                className="price-box__input"
              />
            </div>
          </div>
          <ValidationError errors={errors} touched={touched} field="amount" />
        </Field>

        <Field>
          <Checkbox
            text={
              <span>
                By ticking this box you agree with Pepper's{' '}
                <a target="_blank" href="https://www.ludare.com/terms/" rel="noopener noreferrer">
                  terms and conditions
                </a>{' '}
                <PepperIcon name="external" size="atom" />
              </span>
            }
            id="agreement"
            name="agreement"
            value={values.agreement}
            onChange={handleChange}
          />
        </Field>
        <ValidationError errors={errors} touched={touched} field="agreement" />

        <div className="mv">
          <Button primary type="submit" disabled={isSubmitting || !(balance > 0)}>
            Request Withdrawal
          </Button>
        </div>
      </Form>
    </div>
  </div>
)

const WithdrawFormik = withFormik({
  mapPropsToValues: props => ({
    email: '',
    amount: '',
    agreement: false,
  }),
  validationSchema: props =>
    Yup.object().shape({
      email: Yup.string()
        .required('Your Paypal email address is required.')
        .email('Invalid email address.'),
      amount: Yup.number()
        .typeError('Please enter a valid number.')
        .positive('Amount must be positive.')
        .required('Withdraw amount is required.')
        .min(25, 'The minimum withdrawal amount is $25.')
        .max(props.balance, `Insufficient funds.`),
      agreement: Yup.bool().is([true], 'You have to agree with our Terms and Conditions.'),
    }),
  handleSubmit: ({ email, amount }, { props, setErrors, setSubmitting, resetForm }) => {
    props.submit(email, parseFloat(amount), setErrors, setSubmitting, resetForm)
  },
  displayName: 'LoginForm',
})(WithdrawComponent)

const mapState = state => ({
  balance: parseFloat(getBalance(state)),
  currency: getBalanceCurrency(state),
})
const mapDispatch = dispatch => ({
  submit: (email, amount, setErrors, setSubmitting, resetForm) =>
    dispatch(wallet_actions.withdraw(email.toLowerCase().trim(), amount, setErrors, setSubmitting, resetForm)),
})

export const Withdraw = connect(
  mapState,
  mapDispatch,
)(WithdrawFormik)
