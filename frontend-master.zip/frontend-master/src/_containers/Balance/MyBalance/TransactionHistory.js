import React from 'react'
import moment from 'moment'

import { dateFormat } from 'var'

import Tracker from 'helpers/tracker'
import { generateAsyncRequest } from 'helpers/invoker'
import { services } from '_ducks/services'

import { actions } from '_ducks/alert/alert_reducer'

import { OmniLoading, OmniTable, withAsync } from '_components'
import { withAuth } from '_components/Auth'

const frame = [
  {
    header: 'Date',
    content: props => props.created_at && moment(props.created_at).format(dateFormat),
  },
  {
    header: 'Transaction ID',
    content: props => props.transaction_id,
  },
  {
    header: 'Type',
    content: props => props.transaction_type,
  },
  {
    header: 'Amount',
    content: props =>
      props.amount &&
      props.amount.amount !== null && (
        <span>
          {parseFloat(props.amount.amount).toFixed(2)} {props.amount.currency}
        </span>
      ),
  },
  {
    header: 'Status',
    content: props => props.status,
    minWidth: '100px',
  },
  // {
  //   header: 'Balance',
  //   content: props => props.balance,
  // },
  {
    header: 'Recipient',
    content: props => props.notes,
    align: 'right',
    minWidth: '130px',
  },
]

class TransactionHistoryComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      transactions: null,
      loading: true,
    }
  }
  componentDidMount = async ({ token, handleError } = this.props) => {
    try {
      const data = await generateAsyncRequest({
        service: services.balance.requestTransactionHistory,
        token,
      })
      this.setState({ transactions: data ? data.transactions : null, loading: false })
    } catch (error) {
      handleError({ error, name: 'ASYNC_TRANSACTION_HISTORY_REQUEST' })
      this.setState({ loading: false })
    }
  }

  render = _ => (
    <OmniLoading loading={this.state.loading}>
      <OmniTable
        data={this.state.transactions}
        frame={frame}
        defaultSorted={[
          {
            key: 'created_at',
            desc: true,
          },
        ]}
        noResultMessage={"You haven't had any transactions."}
      />
    </OmniLoading>
  )
}

export const TransactionHistory = withAuth(withAsync(TransactionHistoryComponent))
