import React from 'react'

export const PageNotFound = _ => (
  <div className="page page-404">
    <div className="container">
      <div className="page-404__content">
        <div className="page-404__title">
          <span className="text--green">4</span>
          <span className="text--pink">.</span>
          <span className="text--yellow">0</span>
          <span className="text--blue">.</span>
          <span className="text--red">4</span>
        </div>
        <div className="page-404__sub-title">
          Despite how hard we tried, we couldn't find your page{' '}
          <span className="text--pink">:(</span>
        </div>
      </div>
    </div>
  </div>
)
