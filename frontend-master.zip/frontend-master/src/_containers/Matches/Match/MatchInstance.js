import React from 'react'
import { MatchSummary } from './MatchSummary'
import { MatchDetails } from './MatchDetails'
import { Title, Container, Divider } from 'pepper'

export const MatchInstance = ({
  match: {
    params: { match_id },
  },
}) => {
  return (
    <div className="page">
      <Container>
        <Title size="large" align="center" margin={8}>
          Match Details
        </Title>

        <MatchSummary match_id={match_id} />
        <Divider invisible size="big" />
        <MatchDetails match_id={match_id} />
      </Container>
    </div>
  )
}
