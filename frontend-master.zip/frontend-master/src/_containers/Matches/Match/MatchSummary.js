import React from 'react'
import { services } from '_ducks/services'
import moment from 'moment'
import { datetimeFormatMDHm } from 'var'
import { generateAsyncRequest } from 'helpers/invoker'

import { OmniLoading, withAsync } from '_components'
import { Subtitle } from 'pepper'

class MatchSummaryComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      meta: null,
      loading: true,
    }
  }
  componentDidMount = async ({ handleError, match_id } = this.props) => {
    try {
      const data = await generateAsyncRequest({
        service: services.matches.requestMatchSummary(match_id),
      })
      this.setState({ meta: data ? data.meta : null, loading: false })
    } catch (error) {
      this.setState({ loading: false })
      handleError({ error, name: 'ASYNC_MATCHES_SUMMARY_REQUEST' })
    }
  }
  render = ({ loading, meta } = this.state) => (
    <div className="match-summary">
      <OmniLoading loading={loading}>
        {meta && (
          <div className="match-summary__table segment light">
            {makeItem('Match ID', meta.match_id)}
            {makeItem('Duration', <span>{Math.floor(parseInt(meta.duration, 10) / 60)} minutes</span>)}
            {makeItem('Created at', moment(meta.created_at).format(datetimeFormatMDHm))}
            {makeItem('Retrieved at', moment(meta.retrieved_at).format(datetimeFormatMDHm))}
            {makeItem('Game Mode', meta.gamemode && meta.gamemode.detail)}
            {makeItem('Map', meta.map && meta.map.name)}
            {makeItem('Participants', meta.num_participants)}
            {makeItem('Status', <span className="capitalize">{meta.status}</span>)}
          </div>
        )}
      </OmniLoading>
    </div>
  )
}

export const MatchSummary = withAsync(MatchSummaryComponent)

const makeItem = (title, content) => (
  <div className="summary-column pa">
    <Subtitle>{title}</Subtitle>
    <p className="text--green">{content}</p>
  </div>
)
