import React from 'react'
import { Link } from 'react-router-dom'
import { routes } from 'var'

import { generateAsyncRequest } from 'helpers/invoker'
import { services } from '_ducks/services'

import { OmniTable, OmniLoading, withAsync } from '_components'

class MatchDetailsComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      participants: null,
      loading: true,
    }
  }
  componentDidMount = async ({ handleError, match_id } = this.props) => {
    try {
      const data = await generateAsyncRequest({
        service: services.matches.requestMatchDetails(match_id),
      })
      this.setState({ participants: data ? data.participants : null, loading: false })
    } catch (error) {
      this.setState({ loading: false })
      handleError({ error, name: 'ASYNC_MATCHES_DETAILS_REQUEST' })
    }
  }
  render = ({ loading, participants } = this.state) => (
    <OmniLoading loading={loading}>
      <OmniTable
        data={participants}
        frame={frame}
        rowName="player"
        rowsName="players"
        pageSize={150}
        noResultMessage={"Couldn't find any player for this match."}
        errorMessage={'There are some errors with loading players for this match.'}
        showTotal
        title="Match details may take up to 45 minutes to update."
      />
    </OmniLoading>
  )
}

export const MatchDetails = withAsync(MatchDetailsComponent)

const frame = [
  {
    header: 'Rank',
    content: props => props.rank,
  },
  {
    header: 'Player',
    content: props => props.name,
  },
  {
    header: 'Pepper account',
    content: props => <Link to={`${routes.users}/${props.username}`}>{props.username}</Link>,
  },
  {
    header: 'Kills',
    content: props => props.kills || 0,
    align: 'center',
  },
  {
    header: 'Assists',
    content: props => props.assists || 0,
    align: 'center',
  },
  {
    header: 'Damage Dealt',
    content: props => parseFloat(props.damage_dealt).toFixed(2) || 0,
    align: 'right',
  },
  {
    header: 'Time Survived',
    content: props => `${Math.ceil(parseFloat(props.time_survived) / 60) || 0} minutes`,
    align: 'center',
  },
]
