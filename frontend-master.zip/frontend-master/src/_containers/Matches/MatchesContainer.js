import React from 'react'
import { generateAsyncRequest } from 'helpers/invoker'
import { services } from '_ducks/services'

import { OmniLoading, withAsync } from '_components'
import { withAuth } from '_components/Auth'

import { MatchTable } from './MatchTable'

class MatchesContainerComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      matches: null,
      loading: true,
      errors: {},
    }
  }

  componentDidMount = async ({ handleError, token } = this.props) => {
    try {
      const data = await generateAsyncRequest({ service: services.matches.requestMyMatches, token })
      this.setState({ matches: data ? data.matches : null, loading: false })
    } catch (error) {
      this.setState({ loading: false })
      handleError({ error, name: 'ASYNC_MATCHES_REQUEST' })
    }
  }

  render = _ => (
    <OmniLoading loading={this.state.loading}>
      <MatchTable
        matches={this.state.matches}
        errorMessage={this.state.errors.non_field_errors instanceof Array && this.state.errors.non_field_errors[0]}
      />
    </OmniLoading>
  )
}

export const MatchesContainer = withAuth(withAsync(MatchesContainerComponent))
