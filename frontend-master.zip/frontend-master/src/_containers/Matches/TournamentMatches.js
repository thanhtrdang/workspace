import React from 'react'

import { generateAsyncRequest } from 'helpers/invoker'
import { services } from '_ducks/services'

import { OmniLoading, withAsync } from '_components'
import { withAuth } from '_components/Auth'

import { MatchTable } from './MatchTable'

class TournamentMatchesComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      matches: null,
      loading: true,
    }
  }

  componentDidMount = async (
    {
      handleError,
      token,
      match: {
        params: { id },
      },
    } = this.props,
  ) => {
    try {
      const data = await generateAsyncRequest({
        service: services.matches.requestMyMatchesInTournament(id),
        token,
      })
      this.setState({ matches: data ? data.matches : null, loading: false })
    } catch (error) {
      this.setState({ loading: false })
      handleError({ error, name: 'ASYNC_TOURNAMENT_MATCHES_REQUEST' })
    }
  }

  render = _ => (
    <OmniLoading loading={this.state.loading}>
      <MatchTable matches={this.state.matches} />
    </OmniLoading>
  )
}
export const TournamentMatches = withAuth(withAsync(TournamentMatchesComponent))
