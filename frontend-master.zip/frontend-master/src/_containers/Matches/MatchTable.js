import React from 'react'
import moment from 'moment'
import { Link } from 'react-router-dom'

import { routes, datetimeFormat } from 'var'

import { OmniTable } from '_components'

const frame = [
  {
    header: 'Match ID',
    content: props => <Link to={`${routes.match}/${props.matchid}`}>{props.matchid}</Link>,
  },
  {
    header: 'Time',
    content: props => props.created_at && moment(props.created_at).format(datetimeFormat),
    align: 'center',
  },
  {
    header: 'Status',
    content: props => <span className="capitalize">{props.status}</span>,
    align: 'center',
  },
  {
    header: 'Map',
    content: props => props.map_name,
    align: 'center',
  },
  {
    header: 'Kills',
    content: props => props.kills,
    align: 'center',
  },
  {
    header: 'Rank',
    content: props => <span>#{props.rank}</span>,
    align: 'right',
  },
]

export const MatchTable = ({ matches, pageSize, noResultMessage, errorMessage }) => (
  <OmniTable
    data={matches}
    frame={frame}
    rowName="match"
    rowsName="matches"
    pageSize={pageSize || 100}
    noResultMessage={noResultMessage || "You haven't played any matches."}
    errorMessage={errorMessage}
    showTotal
    title="Matches may take up to 45 minutes to update."
  />
)
