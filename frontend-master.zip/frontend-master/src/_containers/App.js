import React, { useEffect } from 'react'
import { connect } from 'react-redux'
import { profile_actions, is_authed, is_apex_activated, is_pubg_activated } from '_ducks/reducers'

import { Menu, GameMenu, Trunk } from '../_views/_layout'

import { LoadingBar } from './Common/LoadingBar'
import { AsyncContextWrapper } from '_components'

// Contexts
import { GameContextWrapper, MenuContextWrapper, AuthContextWrapper, VaultContextWrapper } from '_contexts'

const AppComponent = ({ authed, requestProfile, children }) => {
  useEffect(_ => {
    if (authed) {
      requestProfile()
    }
  }, [])

  return (
    <div className="app">
      <LoadingBar />
      <AuthContextWrapper>
        <VaultContextWrapper>
          <GameContextWrapper>
            <MenuContextWrapper>
              <GameMenu />
              <Menu />
              {/* Menu should be outside of the async provider so they don't re-render when local async components reload */}
              <AsyncContextWrapper>
                <Trunk>{children}</Trunk>
              </AsyncContextWrapper>
            </MenuContextWrapper>
          </GameContextWrapper>
        </VaultContextWrapper>
      </AuthContextWrapper>
    </div>
  )
}

const mapState = state => ({
  authed: is_authed(state),
})
const mapDispatch = dispatch => ({
  requestProfile: _ => dispatch(profile_actions.requestProfile()),
})

export const App = connect(
  mapState,
  mapDispatch,
)(AppComponent)
