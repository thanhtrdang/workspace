import React from 'react'
import ReactDOM from 'react-dom'
import { Provider } from 'react-redux'
import { ConnectedRouter as Router } from 'connected-react-router'
import registerServiceWorker from './helpers/registerServiceWorker'
import configureStore, { history } from './helpers/configureStore'
import { Layout } from './_containers/Layout'

import { GA_TRACKING_ID } from 'var'
import ReactGA from 'react-ga'
import Tracker from './helpers/tracker'
import './vogue/all.scss'

// Init error tracker
Tracker.init()

// Init Google Analytics
ReactGA.initialize(GA_TRACKING_ID)
ReactGA.pageview(window.location.pathname + window.location.search)

// Add redux store
const store = configureStore()

// Scroll page to top whenever entering a new route
history.listen((location, action) => {
  if (!location.state || !location.state.tab) {
    window.scrollTo(0, 0)
  }
})

const context = React.createContext({
  store: store,
})

// Render
ReactDOM.render(
  <Provider store={store}>
    <Router history={history} context={context}>
      <Layout />
    </Router>
  </Provider>,
  document.getElementById('root'),
)
registerServiceWorker()
