export const color = {
  orange: '#f98bb5',
  green: '#1bb163',
  red: '#f9401f',
  grey: '#525256',
  skyBlue: '#4bccd5',
  yellow: '#fbe332',
  teal: '#509ebe',
  brightPurple: '#8c66c6',
}
