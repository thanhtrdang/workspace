/*
 * The source of truth for all frontend routes.
 * TODO: Add error handling for missing routes being referenced.
 */

export const routes = {
  base: '/', // default redirection

  home: '/',
  selectGame: '/select-game',

  /* --- AUTH --- */
  login: '/login',
  logout: '/logout',
  signup: '/signup',
  signupWithReferralCode: '/signup/:referral_code', //use for email
  forgotPassword: '/forgot-password',
  resetPassword: '/reset-password/:uid/:token',
  verify: '/activate/:uid/:token',
  resendActivationEmail: '/activate/resend-email',

  /* --- PROFILE --- */
  profile: '/profile',
  myMatches: `/profile/my-matches`,
  transactionHistory: '/profile/transaction-history',
  withdraw: '/profile/withdraw',
  changePassword: '/profile/change-password',
  profileSettings: '/profile/settings',
  referrals: '/profile/referrals',

  /* --- MISC --- */
  faqs: '/faqs',
  about: '/about',
  contact: '/contact',
  pageNotFound: '/404',

  /* --- EXTERNAL --- */
  discord: 'https://discord.gg/XeTWAE2',

  users: '/users',
  user: '/users/:username',
  userTournamentHistory: '/users/:username/tournament-history',

  /* --- MATCHES --- */
  match: '/match',
  matchInstance: '/match/:match_id',
}
