export const games = [
  {
    name: 'pubg',
    is_active: true,
  },
  {
    name: 'apex',
    is_active: true,
  },
]

export const apiGameNames = {
  pubg: 'PUBG',
  apex: 'AL',
}

export const feGameNames = {
  PUBG: 'pubg',
  AL: 'apex',
}

export const gamePaths = {
  pubg: {
    home: '/pubg',
    welcome: '/pubg/welcome',
    tutorial_tournament: '/pubg/tutorial/tournament',
    verify: '/pubg/verify',

    tournaments: '/pubg/tournaments',
    tournament: '/pubg/tournaments',
    tournament_instance: '/pubg/tournaments/:id',
    tournament_rules: '/pubg/tournaments/:id/rules',
    tournament_matches: '/pubg/tournaments/:id/matches',
    my_tournaments: '/pubg/my-tournaments',
  },
  apex: {
    home: '/apex',
    welcome: '/apex/welcome',
    tutorial_tournament: '/apex/tutorial/tournament',
    client: '/apex/client',

    tournaments: '/apex/tournaments',
    tournament: '/apex/tournaments',
    tournament_instance: '/apex/tournaments/:id',
    tournament_rules: '/apex/tournaments/:id/rules',
    tournament_matches: '/apex/tournaments/:id/matches',
    my_tournaments: '/apex/my-tournaments',
  },
}
