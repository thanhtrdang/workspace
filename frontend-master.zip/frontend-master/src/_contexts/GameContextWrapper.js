import React, { useState, useEffect } from 'react'
import { gameUtils } from 'helpers/gameUtils'
import { gamePaths } from 'var'

import { is_pubg_activated, is_apex_activated, apex_actions, pubg_actions } from '_ducks/reducers'
import { connect } from 'react-redux'

export const GameContext = React.createContext()

const GameContextWrapperComponent = ({
  isPubgActivated,
  isApexActivated,
  checkApexActivation,
  checkPubgActivation,
  children,
}) => {
  const defaultGame = localStorage.getItem('game')
  const [game, setGame] = useState(defaultGame)
  const [path, setGamePath] = useState(gamePaths[game])

  useEffect(
    _ => {
      !isApexActivated && checkApexActivation()
      !isPubgActivated && checkPubgActivation()

      if (!game) {
        isPubgActivated && saveGame('pubg')
        isApexActivated && saveGame('apex')
      }
    },
    [isPubgActivated, isApexActivated],
  )

  const saveGame = name => {
    if (gameUtils.validate(name)) {
      setGame(name)
      localStorage.setItem('game', name)
      setGamePath(gamePaths[name])
    } else {
      console.log('%c[Error] Invalid game name:', 'color:#d827ff;background:black;font-size:0.8rem;', name)
    }
  }

  return (
    <GameContext.Provider value={{ game, saveGame, path, isPubgActivated, isApexActivated }}>
      {children}
    </GameContext.Provider>
  )
}

const mapState = state => ({
  isPubgActivated: is_pubg_activated(state),
  isApexActivated: is_apex_activated(state),
})

const mapDispatch = dispatch => ({
  checkApexActivation: _ => dispatch(apex_actions.checkActivation()),
  checkPubgActivation: _ => dispatch(pubg_actions.checkActivation()),
})
export const GameContextWrapper = connect(
  mapState,
  mapDispatch,
)(GameContextWrapperComponent)
