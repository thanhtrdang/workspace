import React, { useState } from 'react'

export const MenuContext = React.createContext()

export const MenuContextWrapper = ({ children }) => {
  const [menuVisible, setMenuVisible] = useState(false)
  const [profileSubVisible, setProfileSubVisible] = useState(false)
  const [extraSubVisible, setExtraSubVisible] = useState(false)

  const toggleMenu = _ => {
    const nextStatus = menuVisible === 'in' ? 'out' : 'in'
    setMenuVisible(nextStatus)
  }

  const toggleProfileSub = _ => {
    setExtraSubVisible(false)
    setProfileSubVisible(!profileSubVisible)
  }

  const toggleExtraSub = _ => {
    setExtraSubVisible(!extraSubVisible)
    setProfileSubVisible(false)
  }

  const closeSubs = _ => {
    profileSubVisible && setProfileSubVisible(false)
    extraSubVisible && setExtraSubVisible(false)
  }

  return (
    <MenuContext.Provider
      value={{
        menuVisible,
        toggleMenu,
        closeSubs,
        profileSubVisible,
        toggleProfileSub,
        extraSubVisible,
        toggleExtraSub,
      }}>
      {children}
    </MenuContext.Provider>
  )
}
