import React from 'react'
import { connect } from 'react-redux'
import { is_authed, get_token } from '_ducks/reducers'

export const AuthContext = React.createContext()

const AuthContextWrapperComponent = ({ authed, token, children }) => (
  <AuthContext.Provider value={{ authed, token }}>{children}</AuthContext.Provider>
)

const mapState = state => ({
  authed: is_authed(state) === true,
  token: get_token(state),
})

export const AuthContextWrapper = connect(mapState)(AuthContextWrapperComponent)
