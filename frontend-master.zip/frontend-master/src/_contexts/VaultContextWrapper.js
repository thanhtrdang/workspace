import React, { useReducer } from 'react'

import { initialState, reducer, selectors, actions } from '../_vault/vault'

export const VaultContext = React.createContext()

export const VaultContextWrapper = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState)

  return <VaultContext.Provider value={{ state, dispatch, selectors, actions }}>{children}</VaultContext.Provider>
}
