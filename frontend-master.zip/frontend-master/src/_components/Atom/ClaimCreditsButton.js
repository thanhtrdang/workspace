import React from 'react'
import { connect } from 'react-redux'
import { withFormik } from 'formik'

import { Button, Form } from 'pepper'

import { isDailyCreditsAvailable, wallet_actions } from '_ducks/reducers'

import { ValidationError } from '_components'

const ClaimCreditsButtonComponent = ({ isDailyCreditsAvailable, errors, isSubmitting, handleSubmit }) => (
  <Form onSubmit={handleSubmit}>
    <Button type="submit" disabled={isSubmitting || !isDailyCreditsAvailable}>
      Claim my reward
    </Button>
    <ValidationError errors={errors} />
  </Form>
)

const ClaimCreditsButtonFormik = withFormik({
  handleSubmit: (_, { props, setErrors, setSubmitting }) => {
    props.claimDailyReward(setErrors, setSubmitting)
  },
  displayName: 'ClaimDailyRewardForm',
})(ClaimCreditsButtonComponent)

const mapState = state => ({
  isDailyCreditsAvailable: isDailyCreditsAvailable(state),
})
const mapDispatch = dispatch => ({
  claimDailyReward: (setErrors, setSubmitting) => dispatch(wallet_actions.claimDailyReward(setErrors, setSubmitting)),
})

export const ClaimCreditsButton = connect(
  mapState,
  mapDispatch,
)(ClaimCreditsButtonFormik)
