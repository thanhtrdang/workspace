import React from 'react'
import tracker from 'helpers/tracker'

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props)
    this.state = { error: false }
  }

  componentDidCatch(error, info) {
    tracker.log({ error, action: { type: 'RENDER_ERROR' } })
    this.setState({ error, info })
  }

  render() {
    if (this.state.error) {
      return <div style={{ textAlign: 'center' }}>Error with data rendering</div>
    }
    return this.props.children
  }
}

export { ErrorBoundary }
