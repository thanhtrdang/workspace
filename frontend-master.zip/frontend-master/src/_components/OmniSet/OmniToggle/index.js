import React from 'react'

export const OmniToggle = ({ label, id = 'omniToggle', reversed, ...props }) => (
  <div className="omni-toggle" style={{ flexDirection: reversed ? 'row-reverse' : 'row' }}>
    <input type="checkbox" id={id} className="omni-toggle__input" {...props} />
    <label htmlFor={id} className="omni-toggle__label-toggle" />
    <span className="omni-toggle__label-gap" />
    <label htmlFor={id} className="omni-toggle__label-text">
      {label}
    </label>
  </div>
)
