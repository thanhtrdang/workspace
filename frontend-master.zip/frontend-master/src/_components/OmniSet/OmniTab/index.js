import React from 'react'
import { Container } from 'pepper'
import { NavLink } from 'react-router-dom'

class OmniTab extends React.Component {
  render = _ => <div className="omni-tab">{this.props.children}</div>
}

OmniTab.Bar = ({ children }) => (
  <div className="omni-tab-bar">
    <div className="omni-tab-bar__inner">{children}</div>
  </div>
)

OmniTab.Link = ({ children, ...props }) => (
  <NavLink className="omni-tab-link flex-focus" activeClassName="omni-tab-link--active" {...props}>
    {children}
  </NavLink>
)

OmniTab.Content = ({ children }) => <div className="omni-tab-content">{children}</div>

export { OmniTab }
