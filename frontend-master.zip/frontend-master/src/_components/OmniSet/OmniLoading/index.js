import React from 'react'

import { PepperIcon } from '_components'

export const OmniLoading = ({ loading, hidden, preview, children }) =>
  loading ? (
    hidden ? (
      ''
    ) : (
      <div>
        {preview && <div style={{ opacity: '0.5' }}>{children}</div>}
      </div>
    )
  ) : (
    <div>{children}</div>
  )
