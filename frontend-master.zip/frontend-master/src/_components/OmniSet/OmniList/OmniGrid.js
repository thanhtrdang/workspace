import React from 'react'
import classnames from 'classnames'

import { OmniList } from './OmniList'
import ListHelper from './listHelper'
import { PaginationMode } from './PaginationMode'

class OmniGrid extends OmniList {
  render = ({ items, center } = this.props, { pageSize, currentPage, mode } = this.state) => {
    const totalPage = ListHelper.calculateTotalPage(items.length, pageSize)
    const loadNextPage = this.loadNextPage
    const goToPage = this.goToPage

    const gridClass = classnames({
      'omni-grid': true,
      'flex-center': center,
    })

    const visibleItems = ListHelper.getVisibleRow({
      data: items,
      mode,
      pageSize,
      currentPage,
    })

    return (
      <div>
        <div className={gridClass}>{visibleItems}</div>
        <PaginationMode
          mode={mode}
          totalPage={totalPage}
          currentPage={currentPage}
          goToPage={goToPage}
          loadNextPage={loadNextPage}
        />
      </div>
    )
  }
}

export { OmniGrid }
