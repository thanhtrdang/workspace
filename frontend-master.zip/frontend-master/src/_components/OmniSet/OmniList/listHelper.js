class ListHelper {
  getVisibleRow = ({ data, mode, pageSize, currentPage }) => {
    if (!data || !(data instanceof Array)) {
      return []
    }
    const firstResult = mode === 'pagination' ? Math.max(0, pageSize * (currentPage - 1)) : 0
    const nextFirstResult = Math.min(data.length, pageSize * currentPage)
    return data.slice(firstResult, nextFirstResult)
  }

  calculateTotalPage = (quantity, pageSize) =>
    quantity % pageSize ? Math.floor(quantity / pageSize) + 1 : Math.floor(quantity / pageSize)

  // *** Naive sorting function, need refactor when in used ***
  // sort = sortRules => data => {
  //   if (!sortRules || !sortRules instanceof Array || !sortRules[0] instanceof Object) {
  //     return data
  //   }

  //   const key = sortRules[0].key
  //   const desc = sortRules[0].desc
  //   const order = (r1, r2) => {
  //     if (r1[key] > r2[key]) {
  //       return desc ? -1 : 1
  //     } else if (r1[key] < r2[key]) {
  //       return desc ? 1 : -1
  //     } else {
  //       if (sortRules[1] instanceof Object) {
  //         const key2 = sortRules[1].key
  //         const desc2 = sortRules[1].desc
  //         if ((r1[key2] < r2[key2] && !desc2) || (r1[key2] > r2[key2] && desc2)) return -1
  //         else return 1
  //       }
  //       return -1
  //     }
  //   }

  //   return R.sort(order, data)
  // }
}

export default new ListHelper()
