import React from 'react'
import { generate } from 'shortid'
import {
  TableTop,
  EmptyTable,
  Previous,
  Next,
  PageNumber,
  LazyScroll,
  LazyButton,
} from './Templates'
import classnames from 'classnames'

class ListConfig {
  generateEmptyTable = (frame, message, title) => (
    <div className="omni-table-segment">
      {this.generateTop({ title })}
      <div className="omni-table">
        {this.generateHeader(frame)}
        <EmptyTable message={message || 'No Result'} />
      </div>
    </div>
  )
  /* Generate total rows */
  generateTop = ({ title, showTotal, input, rowName, rowsName }) => {
    return (
      <TableTop
        title={title}
        showTotal={showTotal}
        total={(input && input.length) || 0}
        name={input && input.length > 1 ? rowsName || 'rows' : rowName || 'row'}
      />
    )
  }

  /* Generate header row */
  generateHeader = (frame, showRank) => {
    const cols = frame.map(col => {
      const headerClass = classnames({
        'omni-table__header-cell': true,
        // 'omni-table__header-cell--left': col.align === 'left',
        // 'omni-table__header-cell--right': col.align === 'right',
        // 'omni-table__header-cell--center': col.align === 'center',
      })
      return (
        <div
          className={headerClass}
          key={generate()}
          style={{ textAlign: col.align || 'left', minWidth: col.minWidth }}>
          {col.header}
        </div>
      )
    })
    const header = showRank
      ? [
          <div className="omni-table__header-cell" key={generate()}>
            #
          </div>,
          ...cols,
        ]
      : cols
    return <div className="omni-table__row omni-table__head">{header}</div>
  }

  addEmptyRows = (list, mode, pageSize) => {
    // Make empty rows if it's pagination table
    if (mode === 'pagination') {
      const dataRowRemainder = list.length % pageSize
      if (dataRowRemainder > 0) {
        let emptyData = {}
        for (let key in list[0]) {
          emptyData[key] = null
        }
        const noEmptyRow = pageSize - dataRowRemainder
        for (let i = 0; i < noEmptyRow; i++) {
          list.push(emptyData)
        }
      }
    }
    return list
  }

  /* Add index column to every row.
   * Lazy Load: continuous index
   * Pagination: first index based on current page, no index on empty rows
   */
  generateIndexCell = ({ showRank, mode, rowIndex, isEmptyRow, pageSize, currentPage }) => {
    let order
    if (showRank) {
      if (mode !== 'pagination') {
        order = rowIndex + 1
      } else {
        if (!isEmptyRow) {
          order = pageSize * (currentPage - 1) + rowIndex + 1
        } else {
          order = <span>&nbsp;</span>
        }
      }
    }
    return order
  }

  generateCell = (col, row, emptyRowClass) => {
    const cellClass = classnames({
      emptyRowClass: true,
      'omni-table__cell': true,
      'omni-table__cell--left': col.align === 'left',
      'omni-table__cell--right': col.align === 'right',
      'omni-table__cell--center': col.align === 'center',
    })
    const content = col.content(row)
    const contentDisplay =
      content !== undefined && content !== null && content !== '' ? content : <span>&nbsp;</span>
    return (
      <div className={cellClass} key={generate()} data-label={col.header}>
        {contentDisplay}
      </div>
    )
  }

  buildRowContent = ({ showRank, cols, indexCell, emptyRowClass }) =>
    showRank
      ? [
          <div className={`omni-table__cell ${emptyRowClass}`} data-label="#" key={generate()}>
            {indexCell}
          </div>,
          ...cols,
        ]
      : cols

  /* Generate data rows */
  generateRows = ({ frame, data, pageSize, currentPage, mode, showRank }) => {
    let newData = [...data]
    this.addEmptyRows(newData, mode, pageSize)

    /* Handle data of each single row  */
    const allRows = newData.map((row, rowIndex) => {
      // Determine if row is empty
      const isEmptyRow = rowIndex >= data.length
      const emptyRowClass = isEmptyRow ? 'omni-table__cell--empty' : ''

      /* Create cells based on frame */
      const cols = frame.map(col => this.generateCell(col, row, emptyRowClass))
      const indexCell = this.generateIndexCell({
        showRank,
        mode,
        rowIndex,
        isEmptyRow,
        pageSize,
        currentPage,
      })

      /* Merge index cell to normal cell */
      const rowContent = this.buildRowContent({ showRank, cols, indexCell, emptyRowClass })

      /* Return a single row */
      return (
        <div className="omni-table__row" key={generate()} style={row._styles}>
          {rowContent}
        </div>
      )
    })

    return allRows
  }

  generateLazyScroll = loadNextPage => <LazyScroll handleClick={loadNextPage} />

  generateLazyButton = loadNextPage => <LazyButton handleClick={loadNextPage} />

  generatePagination = (currentPage, totalPage, goToPage) => {
    let pageNumbers = []
    for (let pageNumber = 1; pageNumber < totalPage + 1; pageNumber++) {
      pageNumbers.push(
        <PageNumber
          key={generate()}
          pageNumber={pageNumber}
          current={pageNumber === currentPage}
          handleClick={_ => goToPage(pageNumber)}>
          />
        </PageNumber>,
      )
    }

    const pagination = [
      <Previous
        hidden={currentPage <= 1}
        handleClick={_ => currentPage > 1 && goToPage(currentPage - 1)}
      />,
      ...pageNumbers,
      <Next
        hidden={currentPage >= totalPage}
        handleClick={_ => currentPage < totalPage && goToPage(currentPage + 1)}
      />,
    ]

    return <div className="omni-table__pagination">{pagination}</div>
  }
}

export default new ListConfig()
