import React from 'react'
import { Button } from 'pepper'

export const EmptyTable = ({ message }) => (
  <div className="omni-table__row omni-table--empty__row">
    <div className="omni-table--empty__row__message">{message}</div>
  </div>
)

export const TableTop = ({ title, showTotal, total, name }) => (
  <div className="omni-table__top">
    <div className="omni-table__title">{title}</div>
    {showTotal && (
      <div className="omni-table__total">
        {total} {name}
      </div>
    )}
  </div>
)

export const Previous = ({ hidden, handleClick }) => (
  <span
    className="omni-table__pagination__page"
    style={{ visibility: hidden ? 'hidden' : 'visible' }}
    onClick={handleClick}>
    {'< Previous'}
  </span>
)

export const Next = ({ hidden, handleClick }) => (
  <span
    className="omni-table__pagination__page"
    style={{ visibility: hidden ? 'hidden' : 'visible' }}
    onClick={handleClick}>
    {'Next >'}
  </span>
)

export const PageNumber = ({ current, pageNumber, handleClick }) => (
  <span
    className={current ? 'omni-table__pagination__page--current' : 'omni-table__pagination__page'}
    onClick={handleClick}>
    {pageNumber}
  </span>
)

export const LazyScroll = ({ handleClick }) => (
  <div className="omni-table__scroll">
    <i className="gl-down-arrow omni-table__scroll__icon" onClick={handleClick} />
  </div>
)

export const LazyButton = ({ handleClick }) => (
  <div className="omni-table__load-more">
    <Button onClick={handleClick}>Load More</Button>
  </div>
)
