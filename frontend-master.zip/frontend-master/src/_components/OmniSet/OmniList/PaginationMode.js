import React from 'react'
import ListConfig from './listConfig'

export const PaginationMode = ({ mode, totalPage, currentPage, goToPage, loadNextPage }) => (
  <div className="pagination-mode">
    {mode === 'pagination' &&
      totalPage > 1 &&
      ListConfig.generatePagination(currentPage, totalPage, goToPage)}

    {mode === 'scroll' && currentPage < totalPage && ListConfig.generateLazyScroll(loadNextPage)}

    {mode === 'load-more' && currentPage < totalPage && ListConfig.generateLazyButton(loadNextPage)}
  </div>
)
