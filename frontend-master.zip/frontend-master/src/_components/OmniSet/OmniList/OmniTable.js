import React from 'react'
import ListConfig from './listConfig'
import ListHelper from './listHelper'
import { PaginationMode } from './PaginationMode'
import { OmniList } from './OmniList'
// import './omni-table.less'

class OmniTable extends OmniList {
  constructor(props) {
    super(props)
    this.state = {
      currentPage: props.currentPage ? parseInt(props.currentPage, 10) : 1,
      pageSize: props.pageSize ? parseInt(props.pageSize, 10) : 100,
      mode: props.mode || 'scroll',
    }
  }

  render = (
    {
      frame,
      data,
      noResultMessage,
      errorMessage,
      rowName,
      rowsName,
      showRank,
      showTotal,
      title,
    } = this.props,
    { pageSize, currentPage, mode } = this.state,
  ) => {
    const goToPage = this.goToPage
    const loadNextPage = this.loadNextPage

    // Validate data input
    if (!(data instanceof Array)) {
      return ListConfig.generateEmptyTable(
        frame,
        errorMessage || 'There is an error with data parsing.',
        title,
      )
    } else if (data.length === 0) {
      return ListConfig.generateEmptyTable(frame, noResultMessage || 'No result found.', title)
    }

    const input = data

    // Row on display
    const visibleRows = ListHelper.getVisibleRow({
      data: input,
      mode,
      pageSize,
      currentPage,
    })
    // Total page
    const totalPage = ListHelper.calculateTotalPage(input.length, pageSize)

    return (
      <div className="omni-table-segment">
        {ListConfig.generateTop({ title, showTotal, input, rowName, rowsName })}
        <div className="omni-table">
          {ListConfig.generateHeader(frame, showRank)}
          {ListConfig.generateRows({
            frame,
            data: visibleRows,
            pageSize,
            currentPage,
            mode,
            showRank,
          })}
        </div>
        <PaginationMode
          mode={mode}
          totalPage={totalPage}
          currentPage={currentPage}
          goToPage={goToPage}
          loadNextPage={loadNextPage}
        />
      </div>
    )
  }
}

export { OmniTable }
