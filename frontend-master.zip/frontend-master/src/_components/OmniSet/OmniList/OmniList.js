import React from 'react'

class OmniList extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      currentPage: props.currentPage ? parseInt(props.currentPage, 10) : 1,
      pageSize: props.pageSize ? parseInt(props.pageSize, 10) : 50,
      mode: props.mode || 'scroll',
    }
  }

  componentDidMount = _ => {
    window.addEventListener('scroll', this.handleScroll)
    this.shouldTriggerLoadMore && this.loadNextPage()
  }

  componentWillUnmount = _ => {
    window.removeEventListener('scroll', this.handleScroll)
  }

  shouldTriggerLoadMore = ({ mode } = this.state) => {
    if (mode === 'scroll') {
      const windowHeight =
        'innerHeight' in window ? window.innerHeight : document.documentElement.offsetHeight
      const body = document.body
      const html = document.documentElement
      const docHeight = Math.max(
        body.scrollHeight,
        body.offsetHeight,
        html.clientHeight,
        html.scrollHeight,
        html.offsetHeight,
      )
      const windowBottom = windowHeight + window.pageYOffset
      if (windowBottom >= docHeight - 200 || windowHeight >= docHeight) {
        return true
      }
    }

    return false
  }

  handleScroll = event => {
    this.shouldTriggerLoadMore && this.loadNextPage()
  }

  loadNextPage = _ => {
    this.setState({ currentPage: this.state.currentPage + 1 })
  }

  goToPage = pageNo => {
    this.setState({ currentPage: pageNo })
  }
}

export { OmniList }
