import React from 'react'
import moment from 'moment'

class OmniCountdown extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      days: 0,
      hours: 0,
      minutes: 0,
      seconds: 0,
      asSeconds: 0,
      expired: undefined,
    }
  }

  componentDidMount = _ => {
    this.countdown()
    this.interval = setInterval(_ => {
      this.countdown()
    }, 1000)
  }

  countdown = ({ endTime, onFinish, onExpired } = this.props) => {
    if (!endTime) {
      return
    }
    // End time
    const doom = moment(endTime)
    // Moment
    const now = moment()

    // Find the difference between end time and moment
    const timeDifference = doom.diff(now)
    // console.log('Counter', timeDifference)
    if (timeDifference >= 1000) {
      const duration = moment.duration(timeDifference)

      const days = Math.floor(duration.asDays())
      const asHours = Math.floor(duration.asHours())
      const asMinutes = Math.floor(duration.asMinutes())
      const asSeconds = Math.floor(duration.asSeconds())
      const hours = Math.floor(duration.asHours() - days * 24)
      const minutes = Math.floor(asMinutes - asHours * 60)
      const seconds = Math.floor(duration.asSeconds() - asMinutes * 60)

      this.setState({
        days,
        hours,
        minutes,
        seconds,
        asSeconds,
        asMinutes,
        asHours,
        expired: false,
      })
    }
    // onFinish
    else if (timeDifference >= 0 && timeDifference < 1000) {
      onFinish instanceof Function && onFinish()
    }
    // onExpired
    else if (timeDifference < 0) {
      onExpired instanceof Function && onExpired()
      this.stop()
    }
  }

  stop = _ => {
    clearInterval(this.interval)
    this.setState({ expired: true })
  }

  componentWillUnmount = _ => {
    clearInterval(this.interval)
  }

  formatTime = time => (parseInt(time, 10) < 10 ? `0${parseInt(time, 10)}` : time)

  render = (
    { endTime, mode, beforeText, afterText, timeClass, finishText, onFinish, onExpired, view, ...props } = this.props,
    { days, hours, minutes, seconds, expired, asSeconds, asMinutes, asHours } = this.state,
  ) => {
    if (expired === undefined) return ''
    return view ? (
      expired === false ? (
        view({ days, hours: this.formatTime(hours), minutes: this.formatTime(minutes), seconds: this.formatTime(seconds) })
      ) : (
        view({ expire: true })
      )
    ) : (
      <span {...props}>
        {expired === false ? (
          <span>
            <span className="omni-countdown__text">
              {beforeText}{' '}
              <span className={timeClass}>
                {mode === 'second' ? (
                  parseInt(this.formatTime(asSeconds), 10)
                ) : mode === 'minute' ? (
                  parseInt(this.formatTime(asMinutes), 10) + 1
                ) : mode === 'hour' ? (
                  parseInt(this.formatTime(asHours), 10) + 1
                ) : (
                  <span className="oc-text">
                    <span className="oc-day">{days}</span> days
                    <span className="oc-minute">{this.formatTime(hours)}</span> hours
                    <span className={days > 0 || hours > 0 ? 'oc-second' : 'oc-second oc-second--ending'}>
                      {this.formatTime(minutes)}
                    </span>{' '}
                    minutes
                  </span>
                )}
              </span>
              {afterText}
            </span>
          </span>
        ) : (
          <span>{finishText !== undefined ? finishText : 0}</span>
        )}
      </span>
    )
  }
}

export { OmniCountdown }
