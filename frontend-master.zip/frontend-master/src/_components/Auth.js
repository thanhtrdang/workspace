import React, { useContext } from 'react'
import { AuthContext } from '_contexts'

export const withAuth = WrappedComponent => {
  const ComponentWithAuth = props => {
    const { authed, token } = useContext(AuthContext)
    return <WrappedComponent authed={authed} token={token} {...props} />
  }
  return ComponentWithAuth
}
