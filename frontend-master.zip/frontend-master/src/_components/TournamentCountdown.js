import React from 'react'
import { OmniCountdown } from './OmniSet'
import moment from 'moment'

import { datetimeFormat } from 'var'

export const TournamentCountdown = ({ endTime, status, onFinish, onExpired, justify = 'flex-start' }) => (
  <div>
    {!status || status === 'active' ? (
      <div style={{ justifyContent: justify, display: 'flex', alignItems: 'center' }}>
        <OmniCountdown endTime={endTime} onFinish={onFinish} onExpired={onExpired} />
      </div>
    ) : (
      <span>{moment(endTime).format(datetimeFormat)}</span>
    )}
  </div>
)
