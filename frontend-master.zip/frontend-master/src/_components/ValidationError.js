import React from 'react'
import { Error } from 'pepper'

const NON_FIELD_ERRORS = 'non_field_errors'

export const ValidationError = ({ field, errors, touched }) => {
  if (!field && errors instanceof Object && errors[NON_FIELD_ERRORS]) {
    return <Error>{errors[NON_FIELD_ERRORS]}</Error>
  } else if (errors instanceof Object && errors[field] && touched instanceof Object && touched[field]) {
    return <Error>{errors[field]}</Error>
  } else {
    return ''
  }
}
