import React from 'react'
import classnames from 'classnames'
/* SVG */

import alert_success from 'styles/images/common/success.svg'
import alert_warning from 'styles/images/common/warning.svg'

import avatar from 'styles/images/menu-profile/Avatar.svg'
import announcer from 'styles/images/menu-profile/announcers/Alert.svg'
import announcer_off from 'styles/images/menu-profile/announcers/Alert-Off.svg'

import card_apex from 'images/menus/ApexLegends_card.svg'
import card_bw_apex from 'images/menus/Apex_inactive.png'
import card_pubg from 'images/menus/PubG_card.svg'
import card_bw_pubg from 'images/menus/Pubg_inactive.png'

import checked from 'styles/images/menu-profile/CheckedGreen.svg'
import circle from 'styles/images/menu-profile/empty.svg'
import clock from 'styles/images/tournaments/clock.svg'

import close from 'styles/images/menu-profile/Close.svg'
import external from 'styles/images/misc/external.svg'
import home_gamepad from 'styles/images/how-to-play/Game.svg'
import home_prize from 'styles/images/how-to-play/Prize.svg'
import home_trophy from 'styles/images/how-to-play/Trophy.svg'
import hourglass from 'styles/images/misc/Hourglass.svg'

import loading from 'styles/images/common/loading.svg'

import logo from 'styles/images/common/Logo.svg'
import logo_block from 'styles/images/common/Logo-Block.png'
import logo_apex from 'images/games/apex/logo.png'
import logo_pubg from 'images/games/pubg/logo.png'
import menu_profile from 'styles/images/menu-profile/Avatar.svg'
import menu_trophy from 'styles/images/menu-profile/TrophyWhite.svg'
import menu_link from 'styles/images/menu-profile/Link.svg'
import menu_gamepad from 'styles/images/menu-profile/GamepadWhite.svg'
import menu_logout from 'styles/images/menu-profile/Logout.svg'

import players from 'styles/images/menu-profile/Players.svg'

import sign_add from 'styles/images/common/signs/AddSign.svg'
import sign_dollar from 'styles/images/common/signs/DollarSign.svg'
import sign_stars from 'styles/images/common/signs/StarsSign.svg'

import tournament_trophy from 'styles/images/tournaments/TrophyTournament.svg'

import unverified from 'styles/images/menu-profile/Unverified.svg'

/* PNG */
import medal_bronze from 'resources/images/tournament/badge-bronze.png'
import medal_gold from 'resources/images/tournament/badge-gold.png'
import medal_silver from 'resources/images/tournament/badge-silver.png'

import token from 'resources/images/common/token.png'

import gift from 'resources/images/common/gift.png'

const icons = {
  alert_success,
  alert_warning,

  avatar,
  announcer,
  announcer_off,

  card_pubg,
  card_bw_pubg,
  card_apex,
  card_bw_apex,

  checked,
  circle,

  clock,
  close,
  external,
  gift,

  home_gamepad,
  home_prize,
  home_trophy,

  hourglass,
  loading,

  logo,
  logo_block,
  logo_apex,
  logo_pubg,

  medal_bronze,
  medal_gold,
  medal_silver,

  menu_profile,
  menu_trophy,
  menu_link,
  menu_gamepad,
  menu_logout,

  players,

  sign_add,
  sign_dollar,
  sign_stars,

  tournament_trophy,
  token,
  unverified,
}

const sizes = {
  atom: '0.75rem',
  mini: '1rem',
  tiny: '1.5rem',
  small: '2rem',
  medium: '2.5rem',
  large: '5rem',
  big: '8rem',
  huge: '12rem',
}

export const PepperIcon = ({ name, customSize, size = 'small', noMargin, className, width, height, style }) => {
  const styleObject = {
    width: width || customSize || sizes[size],
    height: height || 'auto',
    ...style,
  }
  if (noMargin) styleObject['margin'] = 0

  const classObject = {
    'pepper-icon': true,
  }
  if (className) classObject[className] = true

  return <img src={icons[name]} style={styleObject} className={classnames(classObject)} alt="" />
}
