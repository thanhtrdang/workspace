import React from 'react'
import classnames from 'classnames'

export const Container = ({ className, center, children }) => {
  const thisClass = classnames({
    container: true,
    [className]: className ? true : false,
    center,
  })

  return <div className={thisClass}>{children}</div>
}
