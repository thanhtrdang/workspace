import React from 'react'
import classnames from 'classnames'
import { generate } from 'shortid'

export const Checkbox = ({ id, text, className, children, ...props }) => {
  const thisClass = classnames({
    checkbox: true,
    [className]: className ? true : false,
  })

  const checkboxId = id || generate()
  return (
    <div className={thisClass}>
      <input type="checkbox" id={checkboxId} {...props} />
      {text && (
        <label className="label" htmlFor={checkboxId}>
          {text}
        </label>
      )}
    </div>
  )
}
