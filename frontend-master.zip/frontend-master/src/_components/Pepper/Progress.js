import React from 'react'

export const Progress = ({ current, total }) =>
  !total ? (
    ''
  ) : (
    <div className="progress">
      <div className="progress__bar" style={{ width: `${(current * 100) / total}%` }} />
    </div>
  )
