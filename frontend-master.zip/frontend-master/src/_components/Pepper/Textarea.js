import React from 'react'
import classnames from 'classnames'
import { Label } from './Label'

export const Textarea = ({ label, className, children, ...props }) => {
  const thisClass = classnames({
    textarea: true,
    [className]: className ? true : false,
  })

  return (
    <React.Fragment>
      {label && <Label>{label}</Label>}
      <div className={thisClass}>
        <textarea {...props} />
      </div>
      {children}
    </React.Fragment>
  )
}
