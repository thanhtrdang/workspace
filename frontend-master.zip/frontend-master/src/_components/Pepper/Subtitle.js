import React from 'react'
import classnames from 'classnames'

export const Subtitle = ({ margin = 5, align, size, color, transform, font, className, children }) => {
  const thisClass = classnames({
    subtitle: true,
    [`mb${margin}`]: true,
    [size]: size ? true : false,
    [font]: font ? true : false,
    [className]: className ? true : false,
    [transform]: transform ? true : false,
    [`text--${align}`]: align ? true : false,
    [`text--${color}`]: color ? true : false,
  })

  return <div className={thisClass}>{children}</div>
}
