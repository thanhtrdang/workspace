import React from 'react'
import classnames from 'classnames'

export const Error = ({ className, children }) => {
  const thisClass = classnames({
    'field-error': true,
    [className]: true,
  })

  return <div className={thisClass}>{children}</div>
}
