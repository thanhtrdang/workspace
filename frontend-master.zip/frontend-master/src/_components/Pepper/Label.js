import React from 'react'
import classnames from 'classnames'

export const Label = ({ className, children }) => {
  const thisClass = classnames({
    label: true,
    [className]: className ? true : false,
  })

  return <div className={thisClass}>{children}</div>
}
