import React from 'react'

export const StarIcon = ({ width = '1.5rem', height = '1.5rem', color1 = 'white', color2 = '#fbe332' }) => (
  <svg
    style={{ width, height }}
    width={width}
    height={height}
    viewBox="0 0 42 43"
    fill="none"
    xmlns="http://www.w3.org/2000/svg">
    <path d="M41.9794 42.0542H21.0605H0.141602V21.0406V0.0270996H21.0605H41.9794V21.0406V42.0542Z" fill={color2} />
    <path
      d="M20.8582 8.63257L22.8042 12.5933L24.7501 16.5541L29.1014 17.1892L33.4525 17.8243L30.304 20.9073L27.1554 23.9903L27.8986 28.3435L28.642 32.6968L24.7501 30.6414L20.8582 28.5862L16.9664 30.6414L13.0745 32.6968L13.8178 28.3435L14.5611 23.9903L11.4125 20.9073L8.26392 17.8243L12.6152 17.1892L16.9664 16.5541L18.9124 12.5933L20.8582 8.63257Z"
      fill={color1}
    />
  </svg>
)
