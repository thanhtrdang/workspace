import React from 'react'

export const HomeIcon = ({ width = '2rem', height = '2rem', color = 'white' }) => (
  <svg
    style={{ width, height }}
    width={width}
    height={height}
    viewBox="0 0 36 40"
    fill="none"
    xmlns="http://www.w3.org/2000/svg">
    <path
      d="M34.6266 20.9008H30.9205V39.5778H22.5651V28.2342H13.4351V39.5778H5.05253V20.9008H1.25926C0.603112 20.9008 0.195031 20.4239 0.524525 20.0432L8.8627 10.4L17.2081 0.747198C17.5362 0.367796 18.3494 0.367796 18.6774 0.747198L27.0229 10.4L35.361 20.0432C35.6908 20.4239 35.2815 20.9008 34.6266 20.9008Z"
      fill={color}
    />
  </svg>
)
