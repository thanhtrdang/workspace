import React from 'react'

export const PepperClientInactiveIcon = ({ width = '1.5rem', height = '1.5rem', color = 'white' }) => (
  <svg
    style={{ width, height }}
    width={width}
    height={height}
    viewBox="0 0 82 54"
    fill="none"
    xmlns="http://www.w3.org/2000/svg">
    <rect x="0.327637" width="27" height="27" fill="#1BB163" />
    <rect x="27.3276" width="27" height="27" fill="#F98DB7" />
    <rect x="54.3276" width="27" height="27" fill="#FBE233" />
    <rect x="0.327637" y="27" width="27" height="27" fill="#0B21F1" />
    <rect x="27.3276" y="27" width="27" height="27" fill="#B8BABC" />
    <rect x="54.3276" y="27" width="27" height="27" fill="#F93D1D" />
    <rect x="0.327637" width="81" height="54" fill="#C4C4C4" style={{ mixBlendMode: 'saturation' }} />
  </svg>
)
