import React from 'react'

export const PepperClientIcon = ({ width = '1.5rem', height = '1.5rem', color = 'white' }) => (
  <svg
    style={{ width, height }}
    width={width}
    height={height}
    viewBox="0 0 59 40"
    fill="none"
    xmlns="http://www.w3.org/2000/svg">
    <rect width="19.6667" height="19.6667" fill="#1BB163" />
    <rect x="19.667" width="19.6667" height="19.6667" fill="#F98DB7" />
    <rect x="39.333" width="19.6667" height="19.6667" fill="#FBE233" />
    <rect y="19.6667" width="19.6667" height="19.6667" fill="#0B21F1" />
    <rect x="19.667" y="19.6667" width="19.6667" height="19.6667" fill="#B9BBBD" />
    <rect x="39.333" y="19.6667" width="19.6667" height="19.6667" fill="#F93D1D" />
  </svg>
)
