import React from 'react'

export const AddIcon = ({ width = '2rem', height = '2rem', color = 'white' }) => (
  <svg
    style={{ width, height }}
    width={width}
    height={height}
    viewBox="0 0 41 41"
    fill="none"
    xmlns="http://www.w3.org/2000/svg">
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M20.5 41C31.8218 41 41 31.8218 41 20.5C41 9.17816 31.8218 0 20.5 0C9.17816 0 0 9.17816 0 20.5C0 31.8218 9.17816 41 20.5 41ZM18 18V10H23V18H32V23H23V32H18V23H10V18H18Z"
      fill={color}
    />
  </svg>
)
