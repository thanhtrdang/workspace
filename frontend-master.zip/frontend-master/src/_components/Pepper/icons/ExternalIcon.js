import React from 'react'

export const ExternalIcon = ({ width = '0.75rem', height = '0.75rem', color = 'white' }) => (
  <svg
    style={{ width, height }}
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 341.36 341.11"
    width={width}
    height={height}
    fill={color}>
    <polygon
      className="a"
      points="341.36 170.56 341.11 341.11 0 341.11 0 0 170.95 0 170.95 31.86 32.16 31.86 32.16 308.65 308.96 308.65 309.21 170.56 341.36 170.56"
    />
    <polygon className="a" points="341.17 96.19 245.28 0.42 341.17 0.65 341.17 96.19" />
    <rect
      className="a"
      x="138.15"
      y="75.91"
      width="224.79"
      height="31.86"
      transform="translate(8.45 204.06) rotate(-45)"
    />
  </svg>
)
