import React from 'react'

export const StatsIcon = ({ width = '2rem', height = '2rem', color = 'white' }) => (
  <svg
    style={{ width, height }}
    width={width}
    height={height}
    viewBox="0 0 34 40"
    fill="none"
    xmlns="http://www.w3.org/2000/svg">
    <path d="M33.2534 10.4292H26.2529V38.8577H33.2534V10.4292Z" fill={color} />
    <path d="M7.24001 18.9736H0.175781V39.0096H7.24001V18.9736Z" fill={color} />
    <path d="M20.3221 0.908203H13.1714V38.9655H20.3221V0.908203Z" fill={color} />
  </svg>
)
