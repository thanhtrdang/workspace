import React from 'react'

export const WarningIcon = ({ width = '1.5rem', height = '1.5rem', color1 = '#FBE233', color2 = 'black' }) => (
  <svg style={{ width, height }} viewBox="0 0 22 23" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width={width} height={height} fill={color1} />
    <path d="M12.536 4.68H9.458V13.608H12.536V4.68ZM12.536 14.94H9.458V18H12.536V14.94Z" fill={color2} />
  </svg>
)
