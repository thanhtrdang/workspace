import React from 'react'

export const EllipsisIcon = ({ width = '1.5rem', height = '1.5rem', color = '#C4C4C4' }) => (
  <svg
    style={{ width, height }}
    width={width}
    height={height}
    viewBox="0 0 24 6"
    fill="none"
    xmlns="http://www.w3.org/2000/svg">
    <ellipse cx="2.96094" cy="3.02887" rx="2.96094" ry="2.97101" fill={color} />
    <ellipse cx="11.9998" cy="2.97101" rx="2.96094" ry="2.97101" fill={color} />
    <ellipse cx="21.0391" cy="2.97101" rx="2.96095" ry="2.97101" fill={color} />
  </svg>
)
