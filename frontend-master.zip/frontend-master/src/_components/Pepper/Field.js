import React from 'react'
import classnames from 'classnames'

export const Field = ({ className, children, ...props }) => {
  const thisClass = classnames({
    field: true,
    [className]: className ? true : false,
  })

  return (
    <div className={thisClass} {...props}>
      {children}
    </div>
  )
}
