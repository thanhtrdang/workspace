import React from 'react'
import classnames from 'classnames'

export const Form = ({ className, children, ...props }) => {
  const thisClass = classnames({
    form: true,
    [className]: true,
  })

  return (
    <form className={thisClass} {...props}>
      {children}
    </form>
  )
}
