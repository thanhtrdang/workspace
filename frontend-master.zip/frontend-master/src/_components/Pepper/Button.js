import React from 'react'
import classnames from 'classnames'

export const Button = ({ primary, size, className, children, ...props }) => {
  const thisClass = classnames({
    button: true,
    primary,
    [size]: size ? true : false,
    [className]: true,
  })

  return (
    <button className={thisClass} {...props}>
      {children}
    </button>
  )
}
