import React from 'react'
import classnames from 'classnames'

export const Divider = ({ invisible, className, size }) => {
  const thisClass = classnames({
    divider: true,
    invisible,
    [size]: size ? true : false,
    [className]: className ? true : false,
  })

  return <div className={thisClass} />
}
