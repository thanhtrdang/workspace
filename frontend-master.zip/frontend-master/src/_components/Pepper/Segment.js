import React from 'react'
import classnames from 'classnames'

export const Segment = ({ size, theme, className, children }) => {
  const thisClass = classnames({
    segment: true,
    [size]: size ? true : false,
    [theme]: theme ? true : false,
    [className]: true,
  })

  return <div className={thisClass}>{children}</div>
}
