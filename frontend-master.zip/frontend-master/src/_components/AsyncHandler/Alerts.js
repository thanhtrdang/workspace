import React from 'react'
import { PepperIcon } from '_components'
import { generate } from 'shortid'
import utils from 'helpers/utils'

export const Alerts = ({ alerts }) => {
  return (
    <div>
      {utils.is_populated(alerts) &&
        alerts.map(({ state, content, code }) => (
          <div key={generate()}>
            {state.toLowerCase() === 'success' && (
              <div className="alert__bar">
                <PepperIcon name="alert_success" size="tiny" />
                <span className="alert__bar__text">{content || 'Success'}</span>
              </div>
            )}

            {state.toLowerCase() === 'error' && (
              <div className="alert__bar alert__bar--error">
                <PepperIcon name="alert_warning" size="tiny" />
                {code}
                <span className="alert__text">
                  {content instanceof Array
                    ? content.map(text => `${text} `)
                    : content || 'Something is wrong. Please try again. '}
                </span>
              </div>
            )}
          </div>
        ))}
    </div>
  )
}
