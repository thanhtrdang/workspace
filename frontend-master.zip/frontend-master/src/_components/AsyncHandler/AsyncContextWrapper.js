import React from 'react'
import { withRouter } from 'react-router-dom'
import { Alerts } from './Alerts'
import { routes } from 'var'
import Tracker from 'helpers/tracker'

import { connect } from 'react-redux'
import { get_alerts, get_alert_delay, alert_actions } from '_ducks/reducers'

export const AsyncContext = React.createContext()

/**
 * Possible optimization: stop re-rendering if history changes, as it only used for redirection
 */

const AsyncContextWrapperComponent = ({
  alerts,
  delayTime,
  alertError,
  alertSuccess,
  alertVanish,
  history,
  children,
}) => {
  const handleSuccess = ({ message, setSubmitting, resetForm }) => {
    alertSuccess(message)
    setTimeout(_ => alertVanish(), delayTime)
    resetForm instanceof Function && resetForm({})
    setSubmitting instanceof Function && setSubmitting(false)
  }

  const handleError = ({ error, name, setErrors, setSubmitting, custom401 }) => {
    setSubmitting instanceof Function && setSubmitting(false)
    if (!error.response) {
      console.log('%c FAILED REQUEST:', 'color:orange;background:black;font-size:0.8rem;', name, error)
      alertError(error)
      setTimeout(_ => alertVanish(), delayTime)
      Tracker.log({ error, action: { name } })
    } else {
      const { status, data } = error.response
      if (status === 400) {
        setErrors instanceof Function && setErrors(data)
      } else {
        console.log('%c FAILED REQUEST:', 'color:orange;background:black;font-size:0.8rem;', name, error)
        alertError(error)
        setTimeout(_ => alertVanish(), delayTime)
        if (status === 401) {
          if (custom401 instanceof Function) {
            custom401()
          }
          //  else {
          //   history.push({
          //     pathname: routes.logout,
          //     state: { from: history.location },
          //   })
          // }
        }
        Tracker.log({ error, action: { name } })
      }
    }
  }

  const value = { handleSuccess, handleError }

  return (
    <AsyncContext.Provider value={value}>
      {children}
      <div className="alert">
        <Alerts alerts={alerts} />
      </div>
    </AsyncContext.Provider>
  )
}

const mapState = state => ({
  alerts: get_alerts(state),
  delayTime: get_alert_delay(),
})

const mapDispatch = dispatch => ({
  alertSuccess: message => dispatch(alert_actions.alert_success(message)),
  alertError: error => dispatch(alert_actions.alert_error(error)),
  alertVanish: _ => dispatch(alert_actions.alert_vanish()),
})

export const AsyncContextWrapper = connect(
  mapState,
  mapDispatch,
)(withRouter(AsyncContextWrapperComponent))
