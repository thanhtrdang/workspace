import React from 'react'
import { AsyncContext } from './AsyncContextWrapper'

export const withAsync = WrappedComponent => {
  class ComponentWithAsync extends React.Component {
    render = _ => (
      <AsyncContext.Consumer>
        {({ handleError, handleSuccess }) => (
          <WrappedComponent handleError={handleError} handleSuccess={handleSuccess} {...this.props} />
        )}
      </AsyncContext.Consumer>
    )
  }
  return ComponentWithAsync
}
