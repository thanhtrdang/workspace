import { Component, Input } from '@angular/core';

import { MarkerStore } from '../marker.store';
import { Marker, Point } from '../marker.model';
import { isCanvasEvent, isSelectionBigEnough } from '../marker.util';

@Component({
  selector: 'xxx-marker-canvas',
  templateUrl: './marker-canvas.component.html',
  styleUrls: ['./marker-canvas.component.scss'],
})
export class MarkerCanvasComponent {
  @Input() canvasId: string = '';
  @Input() markers: Marker[] = [];

  private startSelectionPoint?: Point;

  constructor(private readonly markerStore: MarkerStore) {}

  onMouseStart(event: MouseEvent): void {
    if (isCanvasEvent(event, this.canvasId)) {
      this.startSelectionPoint = {
        x: event.offsetX,
        y: event.offsetY,
      };

      console.log(`${event.type}: ${JSON.stringify(this.startSelectionPoint)}`);
    } else {
      this.startSelectionPoint = undefined;
    }
  }

  onMouseEnd(event: MouseEvent): void {
    if (isCanvasEvent(event, this.canvasId) && this.startSelectionPoint) {
      const endSelectionPoint: Point = {
        x: event.offsetX,
        y: event.offsetY,
      };

      if (isSelectionBigEnough(this.startSelectionPoint, endSelectionPoint)) {
        const newMarkerBoxRect = {
          origin: {
            x: this.startSelectionPoint.x - 1,
            y: this.startSelectionPoint.y - 1,
          },
          size: {
            width: endSelectionPoint.x - this.startSelectionPoint.x,
            height: endSelectionPoint.y - this.startSelectionPoint.y,
          },
        };

        this.markers = [...this.markers, { name: '', rect: newMarkerBoxRect }];

        console.log(`${event.type}: ${JSON.stringify(newMarkerBoxRect)}`);
      }
    }

    this.startSelectionPoint = undefined;
    this.markerStore.selection$.next(undefined);
  }

  onMouseMove(event: MouseEvent): void {
    if (isCanvasEvent(event, this.canvasId) && this.startSelectionPoint) {
      const rectSelection = {
        origin: this.startSelectionPoint,
        size: {
          width: event.offsetX - this.startSelectionPoint.x,
          height: event.offsetY - this.startSelectionPoint.y,
        },
      };

      // console.log(`${event.type}: ${JSON.stringify(rectSelection)}`);

      this.markerStore.selection$.next(rectSelection);
    }
  }
}
