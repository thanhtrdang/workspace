import { Component, OnInit } from '@angular/core';

import { Rect } from '../marker.model';
import { MarkerStore } from '../marker.store';

@Component({
  selector: 'xxx-marker-selection',
  templateUrl: './marker-selection.component.html',
  styleUrls: ['./marker-selection.component.scss'],
})
export class MarkerSelectionComponent implements OnInit {
  rect?: Rect;

  constructor(private readonly markerStore: MarkerStore) {}

  ngOnInit(): void {
    this.markerStore.selection$.subscribe((rect) => {
      this.rect = rect;
    });
  }
}
