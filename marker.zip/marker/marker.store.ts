import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

import { Rect, Marker, Template, Canvas } from './marker.model';

@Injectable({ providedIn: 'root' })
export class MarkerStore {
  template$ = new BehaviorSubject<Template | undefined>(undefined);
  selection$ = new BehaviorSubject<Rect | undefined>(undefined);

  constructor() {
    this.template$.next(template);
  }
}

const marker_0_0: Marker = {
  name: 'xyz',
  rect: { origin: { x: 20, y: 20 }, size: { width: 70, height: 100 } },
};
const marker_0_1: Marker = {
  name: 'abc',
  rect: { origin: { x: 40, y: 50 }, size: { width: 70, height: 100 } },
};

const canvas_0: Canvas = {
  id: 'canvas-id-0',
  markers: [marker_0_0, marker_0_1],
};

const canvas_1: Canvas = {
  id: 'canvas-id-1',
  markers: [{ ...marker_0_0, name: 'xxx' }],
};

const template: Template = {
  id: 'template-id-x',
  name: 'Tpl XXX',
  canvases: [canvas_0, canvas_1],
};
