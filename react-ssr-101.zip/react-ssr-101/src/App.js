import React from 'react';
import ReactDOMServer from 'react-dom/server';
import { Button } from '@material-ui/core';
import { ServerStyleSheets } from '@material-ui/styles';

function App() {
  return (
    <Button variant="contained" color="primary">
      Hello World
    </Button>
  );
}

const sheets = new ServerStyleSheets();
const html = ReactDOMServer.renderToStaticMarkup(sheets.collect(<App />));
const css = sheets.toString();

function renderFullPage(html, css) {
  return `
    <!DOCTYPE html>
    <html>
      <head>
        <title>My page</title>
        <style id="jss-server-side">${css}</style>
      </head>
      <body>
        <div id="root">${html}</div>
      </body>
    </html>
  `;
}

const fullPage = renderFullPage(html, css);
console.log(fullPage);

export default App;
