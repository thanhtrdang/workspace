import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { WelcomePage, TplPage, DocPage } from '@xxx/page';

const routes: Routes = [
  {
    path: 'welcome',
    component: WelcomePage,
  },

  {
    path: 'tpl',
    component: TplPage,
  },

  {
    path: 'doc',
    component: DocPage,
  },

  {
    path: '',
    pathMatch: 'full',
    redirectTo: '/welcome',
  },

  {
    path: '**',
    redirectTo: '/tpl',
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
