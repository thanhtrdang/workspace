import { APP_INITIALIZER, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { InputTextModule } from 'primeng/inputtext';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { DropdownModule } from 'primeng/dropdown';
import { FileUploadModule } from 'primeng/fileupload';
import { ButtonModule } from 'primeng/button';
import { DataViewModule } from 'primeng/dataview';
import { ProgressBarModule } from 'primeng/progressbar';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { AccordionModule } from 'primeng/accordion';
import { TooltipModule } from 'primeng/tooltip';
import { ToolbarModule } from 'primeng/toolbar';
import { TableModule } from 'primeng/table';
import { NgxDragResizeModule } from 'ngx-drag-resize';
import { GlobalWorkerOptions } from 'pdfjs-dist';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { ApiInterceptorProviders } from '@xxx/api';
import {
  MarkerCanvasComponent,
  MarkerBoxComponent,
  MarkerSelectionComponent,
  PdfPageComponent,
  PdfViewerComponent,
} from '@xxx/lib';
import { WelcomePage, TplPage, DocPage } from '@xxx/page';
import { configRxDb } from '@xxx/store';

@NgModule({
  declarations: [
    AppComponent,

    MarkerCanvasComponent,
    MarkerBoxComponent,
    MarkerSelectionComponent,
    PdfPageComponent,
    PdfViewerComponent,

    WelcomePage,
    TplPage,
    DocPage,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    InputTextModule,
    InputTextareaModule,
    DropdownModule,
    FileUploadModule,
    ButtonModule,
    DataViewModule,
    ProgressBarModule,
    ScrollPanelModule,
    AccordionModule,
    TooltipModule,
    ToolbarModule,
    TableModule,
    NgxDragResizeModule,
    AppRoutingModule,
  ],
  providers: [
    ...ApiInterceptorProviders,
    {
      provide: APP_INITIALIZER,
      useFactory: () => appInit,
      multi: true,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}

const appInit = async () => {
  GlobalWorkerOptions.workerSrc = 'pdf.worker.min.js';
  // LokiJs bugs
  // Object.prototype.toString = function () {
  //   return JSON.stringify(this);
  // };
  await configRxDb();
};
