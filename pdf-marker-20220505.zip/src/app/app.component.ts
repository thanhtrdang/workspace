import { Component, OnInit } from '@angular/core';
import { delay } from 'rxjs';

import { XxxStore } from '@xxx/store';

@Component({
  selector: 'xxx-app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  title = 'ng-marker';
  isRequesting$ = this.xxxStore.isRequesting$.pipe(delay(1));

  constructor(private xxxStore: XxxStore) {}

  ngOnInit(): void {}
}
