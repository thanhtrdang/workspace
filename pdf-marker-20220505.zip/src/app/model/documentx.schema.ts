import { RxJsonSchema, RxDocument, RxCollection } from 'rxdb';
import { DocumentxModel, DocumentxStatus } from './xxx.model';

export const DocumentxSchema: RxJsonSchema<DocumentxModel> = {
  title: 'DocxModel',
  version: 0,
  keyCompression: false,
  primaryKey: 'id',
  type: 'object',
  properties: {
    id: {
      type: 'string',
      default: '',
    },
    templateId: {
      type: 'string',
      default: '',
    },
    name: {
      type: 'string',
      default: '',
    },
    src: {
      type: 'string',
      default: '',
    },
    status: {
      enum: Object.values(DocumentxStatus),
    },
    pages: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          pageIndex: {
            type: 'number',
          },
          width: {
            type: 'number',
          },
          height: {
            type: 'number',
          },
          scale: {
            type: 'number',
          },
        },

        required: ['pageIndex', 'width', 'height', 'scale'],
      },
      default: [],
    },
  },
  attachments: {},

  required: ['id'],
};

export type DocumentxDocument = RxDocument<DocumentxModel>;
export type DocumentxCollection = RxCollection<DocumentxModel>;
