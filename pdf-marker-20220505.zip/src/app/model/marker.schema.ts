import { RxJsonSchema, RxDocument, RxCollection } from 'rxdb';
import { MarkerModel } from './xxx.model';

export const MarkerSchema: RxJsonSchema<MarkerModel> = {
  title: 'MarkerModel',
  version: 0,
  keyCompression: false,
  primaryKey: 'id',
  type: 'object',
  properties: {
    id: {
      type: 'string',
      default: '',
    },
    refId: {
      type: 'string',
      default: '',
    },
    pageIndex: {
      type: 'number',
      default: 0,
    },
    name: {
      type: 'string',
      default: '',
    },
    extracted: {
      type: 'string',
      default: '',
    },
    rect: {
      type: 'object',
      properties: {
        x: {
          type: 'number',
        },
        y: {
          type: 'number',
        },
        width: {
          type: 'number',
        },
        height: {
          type: 'number',
        },
      },

      required: ['x', 'y', 'width', 'height'],
      default: {
        x: 0,
        y: 0,
        width: 0,
        height: 0,
      },
    },
  },

  required: ['id', 'rect'],
};

export type MarkerDocument = RxDocument<MarkerModel>;
export type MarkerCollection = RxCollection<MarkerModel>;
