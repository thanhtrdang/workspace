import { RxJsonSchema, RxDocument, RxCollection } from 'rxdb';
import { TemplateModel } from './xxx.model';

export const TemplateSchema: RxJsonSchema<TemplateModel> = {
  title: 'TemplateModel',
  version: 0,
  keyCompression: false,
  primaryKey: 'id',
  type: 'object',
  properties: {
    id: {
      type: 'string',
      default: '',
    },
    name: {
      type: 'string',
      default: '',
    },
    pages: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          pageIndex: {
            type: 'number',
          },
          width: {
            type: 'number',
          },
          height: {
            type: 'number',
          },
          scale: {
            type: 'number',
          },
        },

        required: ['pageIndex', 'width', 'height', 'scale'],
      },
      default: [],
    },
  },

  required: ['id'],
};

export type TemplateDocument = RxDocument<TemplateModel>;
export type TemplateCollection = RxCollection<TemplateModel>;
