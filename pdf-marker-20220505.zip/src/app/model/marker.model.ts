export interface Point {
  x: number;
  y: number;
}

export interface Size {
  width: number;
  height: number;
}

export interface Rect {
  origin: Point;
  size: Size;
}

export interface Marker {
  id: string;
  pageIndex: number;
  name: string;
  rect: Rect;
}

export enum MarkerStatus {
  Active = 'Active', // hover / drag / resize
  Preview = 'Preview',
  Editing = 'Editing',
}

export type MarkerName = Omit<Marker, 'rect'>;

export interface Page {
  size: Size;
  markers: Marker[];
}

export interface Template {
  id: string;
  name: string;
  pages: Page[];
}

export const defaultRect = (): Rect => ({
  origin: { x: 100, y: 100 },
  size: minBoxSize(),
});
export const minBoxSize = (): Size => ({ width: 20, height: 20 });
export const minSelectionSize = (): Size => ({ width: 10, height: 10 });
export const newTemplate = (): Template => ({
  id: '_',
  name: '',
  pages: [],
});

export const POINT_0: Point = { x: 0, y: 0 };
export const MIN_BOX_SIZE = minBoxSize();
export const EMPTY_SIZE: Size = { width: 0, height: 0 };
export const EMPTY_RECT: Rect = {
  origin: POINT_0,
  size: EMPTY_SIZE,
};

export const PDF_SCROLL_SIZE = 18;
export const MIN_PDF_WIDTH = 768;
export const MAX_PDF_WIDTH = 1024;

export const A4_SIZE: Size = {
  width: MIN_PDF_WIDTH,
  height: Math.floor(MIN_PDF_WIDTH * 1.41),
};
