export enum DocumentxStatus {
  Analysing = 'Analysing',
  Reviewing = 'Reviewing',
  Reviewed = 'Reviewed',
  Exception = 'Exception',
}

// export enum MarkerStatus {
//   Active = 'Active', // hover / drag / resize
//   Preview = 'Preview',
//   Editing = 'Editing',
// }

export interface MarkerModel {
  id: string;
  refId: string;
  pageIndex: number;
  name?: string;
  extracted?: string;
  rect: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

export interface PageModel {
  pageIndex: number;
  width: number;
  height: number;
  scale: number;
}

export interface TemplateModel {
  id: string;
  name: string;
  pages: PageModel[];
}

export interface DocumentxModel {
  id: string;
  templateId: string;
  name: string;
  src?: string;
  status: DocumentxStatus;
  pages: PageModel[];
}

// --
