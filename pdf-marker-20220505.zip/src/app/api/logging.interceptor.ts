import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';

import { timeSpent } from '@xxx/lib';

@Injectable({ providedIn: 'root' })
export class LoggingInterceptor implements HttpInterceptor {
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const startTime = Date.now();

    return next //
      .handle(request)
      .pipe(
        tap({
          error: (_) => {
            log(request, 'NOK', startTime, Date.now());
          },
          complete: () => {
            log(request, 'OK', startTime, Date.now());
          },
        })
      );
  }
}

const log = (
  request: HttpRequest<any>,
  result: 'NOK' | 'OK',
  startTime: number,
  endTime: number
) => {
  const duration = timeSpent(startTime, endTime);

  console.log(
    `${request.method.toUpperCase()} - ${request.url} (${result}, ${duration})`
  );
};
