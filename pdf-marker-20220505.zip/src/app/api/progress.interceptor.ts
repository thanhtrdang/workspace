import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { finalize, Observable } from 'rxjs';

import { XxxStore } from '@xxx/store';

@Injectable({ providedIn: 'root' })
export class ProgressInterceptor implements HttpInterceptor {
  constructor(private xxxStore: XxxStore) {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    this.xxxStore.isRequesting$.next(true);

    return next //
      .handle(request)
      .pipe(
        finalize(() => {
          this.xxxStore.isRequesting$.next(false);
        })
      );
  }
}
