import { Provider } from '@angular/core';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { ProgressInterceptor } from './progress.interceptor';
import { LoggingInterceptor } from './logging.interceptor';

export * from './httpbin.api';
export const ApiInterceptorProviders: Provider[] = [
  { provide: HTTP_INTERCEPTORS, useClass: LoggingInterceptor, multi: true },
  { provide: HTTP_INTERCEPTORS, useClass: ProgressInterceptor, multi: true },
];
