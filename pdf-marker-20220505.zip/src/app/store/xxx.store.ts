import { Injectable } from '@angular/core';
import { BehaviorSubject, distinctUntilChanged, map, Observable } from 'rxjs';
import { isEqual, trim } from 'lodash';

import {
  Marker,
  MarkerName,
  MIN_PDF_WIDTH,
  newTemplate,
  Rect,
  Template,
} from '@xxx/model';

@Injectable({ providedIn: 'root' })
export class XxxStore {
  isRequesting$ = new BehaviorSubject(false);

  template$ = new BehaviorSubject<Template>(newTemplate());

  markerSelection$ = new BehaviorSubject<Rect | undefined>(undefined);
  markerPreview$ = new BehaviorSubject<boolean>(false);
  markerEditingId$ = new BehaviorSubject<string | undefined>(undefined);

  pdfPageWidth$ = new BehaviorSubject<number>(MIN_PDF_WIDTH);

  constructor() {}

  markers$(pageIndex: number): Observable<Marker[]> {
    return this.template$.pipe(map((tpl) => tpl.pages[pageIndex].markers));
  }

  marker$(pageIndex: number, markerId: string): Observable<Marker | undefined> {
    return this.template$.pipe(
      map((tpl) => {
        const markers = tpl.pages[pageIndex].markers;

        return markers.find((marker) => marker.id === markerId);
      }),
      distinctUntilChanged((marker1, marker2) => isEqual(marker1, marker2))
    );
  }

  newMarker(marker: Marker): void {
    const template = this.template$.value;
    const page = template.pages[marker.pageIndex];
    const markers = page.markers;

    template.pages[marker.pageIndex] = {
      ...page,
      markers: [...markers, marker],
    };

    this.template$.next(template);
  }

  renameMarker(newMarker: MarkerName): void {
    const template = this.template$.value;
    const page = template.pages[newMarker.pageIndex];
    const markerIndex = page.markers.findIndex(
      (marker) => marker.id === newMarker.id
    );

    if (markerIndex >= 0) {
      const oldMarker = page.markers[markerIndex];
      const newName = trim(newMarker.name);
      const diff = newName !== oldMarker.name;

      if (diff) {
        page.markers[markerIndex] = {
          ...oldMarker,
          name: newName,
        };
        template.pages[newMarker.pageIndex] = page;

        this.template$.next(template);
      }
    }
  }

  moveMarker(pageIndex: number, markerId: string, rect: Rect): void {
    const template = this.template$.value;
    const page = template.pages[pageIndex];
    const markerIndex = page.markers.findIndex(
      (marker) => marker.id === markerId
    );

    if (markerIndex >= 0) {
      const marker = page.markers[markerIndex];

      page.markers[markerIndex] = {
        ...marker,
        rect,
      };
      template.pages[pageIndex] = page;

      this.template$.next(template);
    }
  }

  removeMarker(pageIndex: number, markerId: string): void {
    const template = this.template$.value;
    const page = template.pages[pageIndex];
    const markers = page.markers.filter((marker) => marker.id !== markerId);

    template.pages[pageIndex] = {
      ...page,
      markers,
    };

    this.template$.next(template);
  }

  toggleMarkerPreview(): void {
    this.markerPreview$.next(!this.markerPreview$.value);
  }
}
