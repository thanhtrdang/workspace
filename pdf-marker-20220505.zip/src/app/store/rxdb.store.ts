import { RxDatabase, createRxDatabase } from 'rxdb';
import { getRxStorageLoki } from 'rxdb/plugins/lokijs';
import ShortUniqueId from 'short-unique-id';

import {
  TemplateSchema,
  TemplateCollection,
  DocumentxSchema,
  DocumentxCollection,
  DocumentxDocument,
  DocumentxStatus,
  MarkerSchema,
  MarkerCollection,
} from '@xxx/model';

const LokiIncrementalIndexedDBAdapter = require('lokijs/src/incremental-indexeddb-adapter');
let _RXDB_INSTANCE_: RxDb;

type RxCollections = {
  marker: MarkerCollection;
  template: TemplateCollection;
  documentx: DocumentxCollection;
};

type RxDb = RxDatabase<RxCollections>;

const CollectionSettings = {
  marker: {
    schema: MarkerSchema,
    sync: true,
  },
  template: {
    schema: TemplateSchema,
    sync: true,
  },
  documentx: {
    schema: DocumentxSchema,
    sync: true,
  },
};

const createRxDb = async (): Promise<RxDb> => {
  const db = await createRxDatabase<RxCollections>({
    name: 'rxdb-xxx',
    storage: getRxStorageLoki({
      adapter: new LokiIncrementalIndexedDBAdapter(),
    }),
  });

  await db.addCollections(CollectionSettings);

  return db;
};

export const resetNewTemplate = async (): Promise<DocumentxDocument> => {
  const newDocumentx: DocumentxDocument = await rxDb().documentx.upsert({
    id: NEW_DOCUMENTX_ID,
    templateId: NEW_TEMPLATE_ID,
    name: '',
    src: undefined,
    pages: [],
    status: DocumentxStatus.Analysing,
  });

  return newDocumentx;
};

export const configRxDb = async () => {
  if (!_RXDB_INSTANCE_) {
    console.log('RxDB start up.');
    _RXDB_INSTANCE_ = await createRxDb();
  }
};

export const rxDb = () => _RXDB_INSTANCE_;

export const NEW_TEMPLATE_ID = '_NEW_TEMPLATE_ID_';
export const NEW_DOCUMENTX_ID = '_NEW_DOCUMENTX_ID_';
export const generateId = new ShortUniqueId({ length: 13 });
