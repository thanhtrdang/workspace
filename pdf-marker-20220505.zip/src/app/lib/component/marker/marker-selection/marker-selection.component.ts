import { Component, OnInit } from '@angular/core';

import { Rect } from '@xxx/model';
import { XxxStore } from '@xxx/store';

@Component({
  selector: 'xxx-marker-selection',
  templateUrl: './marker-selection.component.html',
  styleUrls: ['./marker-selection.component.scss'],
})
export class MarkerSelectionComponent implements OnInit {
  rect?: Rect;

  constructor(private readonly xxxStore: XxxStore) {}

  ngOnInit(): void {
    this.xxxStore.markerSelection$.subscribe((rect) => {
      this.rect = rect;
    });
  }
}
