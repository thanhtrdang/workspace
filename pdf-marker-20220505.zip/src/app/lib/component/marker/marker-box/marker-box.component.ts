import {
  Component,
  ElementRef,
  Input,
  OnDestroy,
  OnInit,
  ViewChild,
} from '@angular/core';
import { combineLatest, debounceTime, skip, Subject, Subscription } from 'rxjs';
import { NgxResizeHandleType } from 'ngx-drag-resize';
import { isEmpty } from 'lodash';

import { EMPTY_RECT, MarkerStatus, MIN_BOX_SIZE, Rect } from '@xxx/model';
import { XxxStore } from '@xxx/store';
import { calculateRectElement } from '@xxx/lib/util';

@Component({
  selector: 'xxx-marker-box',
  templateUrl: './marker-box.component.html',
  styleUrls: ['./marker-box.component.scss'],
})
export class MarkerBoxComponent implements OnInit, OnDestroy {
  readonly ResizeHandleType = NgxResizeHandleType;
  readonly MinSize = MIN_BOX_SIZE;
  readonly ResizeWheelDisabled = true;

  @ViewChild('markerBox') _markerBoxRef!: ElementRef<HTMLElement>;

  @Input() boundary: string = '.marker-boundary';
  @Input() pageIndex: number = 0;
  @Input() markerId: string = '';

  name: string = '';
  rect: Rect = EMPTY_RECT;

  status?: MarkerStatus = undefined;

  private rectChanged$ = new Subject<Rect>();

  constructor(private xxxStore: XxxStore) {}

  private subscriptions: Subscription[] = [];

  ngOnInit(): void {
    const markerSubscription = this.xxxStore //
      .marker$(this.pageIndex, this.markerId)
      .subscribe((marker) => {
        if (marker) {
          this.name = marker.name;
          this.rect = marker.rect;

          console.log(`ngOnInit: subscribed ${this.markerId}`);
        }
      });

    const statusSubscription = combineLatest([
      this.xxxStore.markerEditingId$,
      this.xxxStore.markerPreview$,
    ]).subscribe(([editingId, isPreview]) => {
      if (this.markerId === editingId) {
        this.status = MarkerStatus.Editing;
      } else {
        const newStatus = isPreview ? MarkerStatus.Preview : undefined;
        if (newStatus != this.status) {
          this.status = newStatus;
        }
      }
    });

    const rectSubscription = this.rectChanged$
      .pipe(skip(1), debounceTime(500))
      .subscribe((rect) => {
        this.xxxStore.moveMarker(this.pageIndex, this.markerId, rect);
      });

    this.subscriptions = [
      markerSubscription,
      statusSubscription,
      rectSubscription,
    ];
  }

  get showName(): boolean {
    return Boolean(this.status) && !isEmpty(this.name);
  }

  ngOnDestroy(): void {
    console.log(`ngOnDestroy: unsubscribed ${this.markerId}`);

    this.subscriptions.forEach((sub) => sub.unsubscribe());
  }

  onMarkerActive(): void {
    this.status = MarkerStatus.Active;
  }
  onMarkerInactive(): void {
    if (this.xxxStore.markerEditingId$.value === this.markerId) {
      this.status = MarkerStatus.Editing;
    } else if (this.xxxStore.markerPreview$.value) {
      this.status = MarkerStatus.Preview;
    } else {
      this.status = undefined;
    }
  }

  onMarkerDragged(): void {
    this.rectChanged$.next(
      calculateRectElement(this._markerBoxRef.nativeElement)
    );
  }
  onMarkerResized(): void {
    this.rectChanged$.next(
      calculateRectElement(this._markerBoxRef.nativeElement)
    );
  }

  onMarkerRemoved(): void {
    this.xxxStore.removeMarker(this.pageIndex, this.markerId);
  }
}
