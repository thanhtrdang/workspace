import { Component, Input, OnInit } from '@angular/core';
import { EMPTY, Observable } from 'rxjs';

import {
  isCanvasEvent,
  isSelectionBigEnough,
  calculateRectSelection,
} from '@xxx/lib';
import { EMPTY_SIZE, Marker, Point, Size } from '@xxx/model';
import { generateId, XxxStore } from '@xxx/store';

@Component({
  selector: 'xxx-marker-canvas',
  templateUrl: './marker-canvas.component.html',
  styleUrls: ['./marker-canvas.component.scss'],
})
export class MarkerCanvasComponent implements OnInit {
  @Input() pageIndex: number = 0;
  @Input() size: Size = EMPTY_SIZE;

  markers$: Observable<Marker[]> = EMPTY;

  private selectionOffset1?: Point;
  private selectionClient1?: Point;

  constructor(private readonly xxxStore: XxxStore) {}

  ngOnInit(): void {
    this.markers$ = this.xxxStore.markers$(this.pageIndex);
  }

  get canvasId(): string {
    return `marker-canvas-id-${this.pageIndex}`;
  }

  onMouseStart(event: MouseEvent): void {
    // event.preventDefault();
    // event.stopImmediatePropagation();

    if (isCanvasEvent(event, this.canvasId)) {
      this.selectionOffset1 = {
        x: event.offsetX,
        y: event.offsetY,
      };
      this.selectionClient1 = {
        x: event.clientX,
        y: event.clientY,
      };

      console.log(
        `${event.type}: ${this.selectionOffset1} / ${this.selectionClient1}`
      );
    } else {
      this.removeMarkerSelection();
    }
  }

  onMouseEnd(event: MouseEvent): void {
    // event.preventDefault();
    // event.stopImmediatePropagation();

    if (this.selectionOffset1 && this.selectionClient1) {
      const rectSelection = calculateRectSelection(
        this.selectionOffset1,
        this.selectionClient1,
        { x: event.clientX, y: event.clientY }
      );

      if (isSelectionBigEnough(rectSelection.size)) {
        const origin = {
          x: rectSelection.origin.x - 1,
          y: rectSelection.origin.y - 1,
        };

        const newMarkerBoxRect = {
          origin,
          size: rectSelection.size,
        };

        const newMarkerId = generateId();
        this.xxxStore.newMarker({
          id: newMarkerId,
          pageIndex: this.pageIndex,
          name: '',
          rect: newMarkerBoxRect,
        });

        console.log(
          `${event.type}: ${newMarkerId} - ${JSON.stringify(newMarkerBoxRect)}`
        );
      } else {
        console.log(`${event.type}: ${rectSelection} TOO SMALL !!!`);
      }
    }

    this.removeMarkerSelection();
  }

  onMouseMove(event: MouseEvent): void {
    if (this.selectionOffset1 && this.selectionClient1) {
      // event.preventDefault();
      // event.stopImmediatePropagation();

      const rectSelection = calculateRectSelection(
        this.selectionOffset1,
        this.selectionClient1,
        { x: event.clientX, y: event.clientY }
      );

      this.xxxStore.markerSelection$.next(rectSelection);
    }
  }

  private removeMarkerSelection(): void {
    this.selectionOffset1 = undefined;
    this.selectionClient1 = undefined;
    this.xxxStore.markerSelection$.next(undefined);
  }
}
