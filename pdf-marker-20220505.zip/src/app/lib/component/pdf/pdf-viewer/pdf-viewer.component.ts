import { Component, Input, OnInit } from '@angular/core';
import { getDocument, PDFDocumentProxy } from 'pdfjs-dist';
import { get } from 'idb-keyval';
import { range } from 'lodash';

import { rxDb } from '@xxx/store';

@Component({
  selector: 'xxx-pdf-viewer',
  templateUrl: './pdf-viewer.component.html',
  styleUrls: ['./pdf-viewer.component.scss'],
})
export class PdfViewerComponent implements OnInit {
  @Input() documentxId!: string;

  pdf?: PDFDocumentProxy;
  pageNumbers: number[] = [];

  constructor() {}

  async ngOnInit(): Promise<void> {
    const documentx = await rxDb().documentx.findOne(this.documentxId).exec();
    if (documentx) {
      const pdfFile = await get<File>(this.documentxId);
      if (pdfFile) {
        const pdfData = await pdfFile.arrayBuffer();
        this.pdf = await getDocument(new Uint8Array(pdfData)).promise;
        this.pageNumbers = range(1, this.pdf.numPages + 1);
      }
    }
  }
}
