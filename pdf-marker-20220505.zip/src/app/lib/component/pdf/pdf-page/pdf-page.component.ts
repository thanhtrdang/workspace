import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { PDFDocumentProxy } from 'pdfjs-dist';

import { Size } from '@xxx/model';
import { XxxStore } from '@xxx/store';

@Component({
  selector: 'xxx-pdf-page',
  templateUrl: './pdf-page.component.html',
  styleUrls: ['./pdf-page.component.scss'],
})
export class PdfPageComponent implements OnInit {
  @Input() pageNumber!: number;
  @Input() pdf!: PDFDocumentProxy;

  @ViewChild('pdfCanvas') _pdfCanvasRef!: ElementRef<HTMLCanvasElement>;
  size?: Size;

  constructor(private xxxStore: XxxStore) {}

  get pageIndex(): number {
    return this.pageNumber - 1;
  }

  async ngOnInit(): Promise<void> {
    // Support HiDPI-screens.
    const outputScale = window.devicePixelRatio || 1;
    // e.g 1 or 2.5..

    const pdfPage = await this.pdf.getPage(this.pageNumber);

    const viewport = pdfPage.getViewport({ scale: PDF_SCALE });
    const viewportRatio = viewport.height / viewport.width;
    const pdfPageWidth = this.xxxStore.pdfPageWidth$.value;

    const canvasSize = {
      width: Math.floor(viewport.width * outputScale),
      height: Math.floor(viewport.height * outputScale),
    };

    const pdfPageSize = {
      width: Math.min(pdfPageWidth, canvasSize.width),
      height: Math.min(
        Math.floor(pdfPageWidth * viewportRatio),
        canvasSize.height
      ),
    };

    const canvas = this._pdfCanvasRef.nativeElement;
    const context = canvas.getContext('2d')!;

    canvas.width = canvasSize.width;
    canvas.height = canvasSize.height;

    canvas.style.width = `${pdfPageSize.width}px`;
    canvas.style.height = `${pdfPageSize.height}px`;

    const transform =
      outputScale !== 1 ? [outputScale, 0, 0, outputScale, 0, 0] : undefined;

    const renderContext = {
      canvasContext: context,
      transform: transform,
      viewport: viewport,
    };

    pdfPage //
      .render(renderContext)
      .promise.finally(() => {
        this.size = pdfPageSize;

        if (this.pageNumber === this.pdf.numPages) {
          console.log(`Pdf: Rendered all pages.`);
        }
      });
  }
}

const PDF_ZOOM = 1;
const PDF_SCALE = PDF_ZOOM * (96 / 72); // 1.3..3
