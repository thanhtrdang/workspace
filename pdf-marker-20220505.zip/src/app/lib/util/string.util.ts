export const randomAlphanumeric = (
  length: number = 10,
  prefix: string = ''
): string => {
  return _randomString(length, prefix);
};

const _randomString = (length: number, accumulated: string): string => {
  if (accumulated.length <= length) {
    const randomString = Math.random().toString(36).slice(2);

    return _randomString(length, accumulated.concat(randomString));
  } else {
    return accumulated.slice(0, length);
  }
};
