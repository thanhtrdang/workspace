import { ElementRef } from '@angular/core';
import { clamp } from 'lodash';
import {
  MAX_PDF_WIDTH,
  MIN_BOX_SIZE,
  MIN_PDF_WIDTH,
  PDF_SCROLL_SIZE,
  Point,
  Rect,
  Size,
} from '@xxx/model';

export const isCanvasEvent = (event: MouseEvent, canvasId: string): boolean => {
  const target = event.target as HTMLElement;

  return target.id === canvasId;
};

export const isSelectionBigEnough = (
  size: Size,
  delta: Size = MIN_BOX_SIZE
): boolean => {
  return size.width >= delta.width && size.height > delta.height;
};

export const calculateRectSelection = (
  offset1: Point,
  client1: Point,
  client2: Point
): Rect => {
  let origin = {
    ...offset1,
  };

  const width = client2.x - client1.x;
  const height = client2.y - client1.y;

  if (width < 0) {
    origin.x = origin.x + width;
  }
  if (height < 0) {
    origin.y = origin.y + height;
  }

  return {
    origin,
    size: {
      width: Math.abs(width),
      height: Math.abs(height),
    },
  };
};

export const calculateRectElement = (el: HTMLElement): Rect => {
  const styles = el.style;

  return {
    origin: {
      x: parseInt(styles.left, 10) - 1,
      y: parseInt(styles.top, 10) - 1,
    },
    size: {
      width: parseInt(styles.width, 10),
      height: parseInt(styles.height, 10),
    },
  };
};

export const calculatePdfPagesSize = (
  pdfPagesRef: ElementRef<HTMLElement>
): Size => {
  const pdfPagesEl = pdfPagesRef.nativeElement;
  const pdfPagesRect = pdfPagesEl.getBoundingClientRect();

  return {
    width: pdfPagesRect.width - PDF_SCROLL_SIZE * 2,
    height: pdfPagesRect.height - PDF_SCROLL_SIZE,
  };
};

export const calculateLabelsScrollHeight = (
  labelsRef: ElementRef<HTMLElement>
): number => {
  const labelsEl = labelsRef.nativeElement;
  const headerEl = labelsEl.querySelector('.p-datatable-header')!;

  const labelsHeight = labelsEl.getBoundingClientRect().height;
  const headerHeight = headerEl.getBoundingClientRect().height;

  return labelsHeight - headerHeight;
};
