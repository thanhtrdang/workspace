export const logMouseEvent = (event: MouseEvent): void => {
  const xy = {
    x: event.x,
    y: event.y,
  };

  const movement = {
    x: event.movementX,
    y: event.movementY,
  };

  const offset = {
    x: event.offsetX,
    y: event.offsetY,
  };

  const client = {
    x: event.clientX,
    y: event.clientY,
  };

  const page = {
    x: event.pageX,
    y: event.pageY,
  };

  const screen = {
    x: event.screenX,
    y: event.screenY,
  };

  console.log(`=>> xy: ${xy}`);
  console.log(`client: ${client}`);
  console.log(`page: ${page}`);
  console.log(
    `screen: ${screen} 
    - inner ${window.innerWidth} / ${window.innerHeight} 
    - outer ${window.outerWidth} / ${window.outerHeight}`
  );
  console.log(`offset: ${offset}`);
  console.log(`movement: ${movement}`);
};
