export const timeSpent = (startMs: number, endMs: number): string => {
  const duration = endMs - startMs;
  const seconds = (duration / 1000) >> 0;
  const millseconds = duration % 1000;

  const s = seconds > 0 ? `${seconds}s` : '';
  const ms = `${millseconds}ms`;

  return [s, ms].filter((v) => v !== '').join(' ');
};
