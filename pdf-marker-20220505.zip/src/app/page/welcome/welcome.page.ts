import { Component, OnInit } from '@angular/core';
import { random } from 'lodash';

import { TemplateModel } from '@xxx/model';
import { generateId, rxDb } from '@xxx/store';

@Component({
  selector: 'xxx-welcome-page',
  templateUrl: './welcome.page.html',
  styleUrls: ['./welcome.page.scss'],
})
export class WelcomePage implements OnInit {
  templates: TemplateModel[] = [];

  constructor() {}

  ngOnInit(): void {
    rxDb()
      .template //
      .find()
      .$.subscribe((result) => {
        this.templates = result;

        // console.log(`Tpl: ${JSON.stringify(result)}`);
      });
  }

  onNewTemplate(): void {
    // const tpl = rxDb().template.newDocument();
    // console.log(`NEW ${JSON.stringify(tpl.toJSON())}}`);
    // rxDb()
    //   .template //
    //   .insert({
    //     id: generateTemplateId(),
    //     name: `tpl-x-${random(1, 101)}`,
    //     pages: [
    //       {
    //         pageIndex: 0,
    //         width: 800,
    //         height: 500,
    //         scale: 1,
    //       },
    //       {
    //         pageIndex: 1,
    //         width: 800,
    //         height: 500,
    //         scale: 1,
    //       },
    //     ],
    //   })
    //   .then((tpl) => {
    //     console.log(`NEW ${JSON.stringify(tpl.toJSON())}}`);
    //   });
  }
}
