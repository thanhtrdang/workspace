import {
  AfterViewInit,
  Component,
  ElementRef,
  OnInit,
  ViewChild,
} from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { FileUpload } from 'primeng/fileupload';
import { set } from 'idb-keyval';
import { defer, head } from 'lodash';

import { resetNewTemplate } from '@xxx/store';
import { DocumentxDocument, Marker, MarkerName } from '@xxx/model';
import { calculateLabelsScrollHeight, calculatePdfPagesSize } from '@xxx/lib';

@Component({
  selector: 'xxx-doc-page',
  templateUrl: './doc.page.html',
  styleUrls: ['./doc.page.scss'],
})
export class DocPage implements OnInit, AfterViewInit {
  @ViewChild('pdfPages') _pdfPagesRef!: ElementRef<HTMLElement>;
  @ViewChild('labels') _labelsRef!: ElementRef<HTMLElement>;

  templateName: string = '';
  documentxName: string = '';
  documentxId?: string = undefined;

  markers: MarkerName[] = [];

  pdfPagesScrollHeight: number = 0;
  labelsScrollHeight: number = 0;

  isPreview$ = new BehaviorSubject(false);

  private documentx!: DocumentxDocument;

  constructor() {}

  async ngOnInit(): Promise<void> {
    this.documentx = await resetNewTemplate();
  }

  ngAfterViewInit(): void {
    defer(() => {
      this.labelsScrollHeight = calculateLabelsScrollHeight(this._labelsRef);

      const pdfPagesSize = calculatePdfPagesSize(this._pdfPagesRef);
      this.pdfPagesScrollHeight = pdfPagesSize.height;

      // this.xxxStore.pdfPageWidth$.next(
      //   clamp(pdfPagesSize.width, MIN_PDF_WIDTH, MAX_PDF_WIDTH)
      // );
    });
  }

  onSelectDocumentx(event: { files: File[] }, fileUpload: FileUpload): void {
    this.documentxId = undefined;

    const file0 = head(event.files);
    if (file0) {
      this.documentxName = file0.name;
      set(this.documentx.id, file0).then(() => {
        this.documentxId = this.documentx.id;
      });
    }

    fileUpload.clear();
  }

  onStartRenaming(event: { data: MarkerName }): void {}

  onRenameMarker(event: { data: MarkerName }): void {}

  onRemoveMarker(marker: Marker): void {}

  onTogglePreview(): void {}

  onSaveTemplate(): void {}
}
