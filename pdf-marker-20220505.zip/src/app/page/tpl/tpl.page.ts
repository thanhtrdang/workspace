import {
  AfterViewInit,
  Component,
  ElementRef,
  OnInit,
  ViewChild,
} from '@angular/core';
import { clamp, defer } from 'lodash';

import { XxxStore } from '@xxx/store';
import { Marker, MarkerName, MAX_PDF_WIDTH, MIN_PDF_WIDTH } from '@xxx/model';
import { calculateLabelsScrollHeight, calculatePdfPagesSize } from '@xxx/lib';

@Component({
  selector: 'xxx-tpl-page',
  templateUrl: './tpl.page.html',
  styleUrls: ['./tpl.page.scss'],
})
export class TplPage implements OnInit, AfterViewInit {
  @ViewChild('pdfPages') _pdfPagesRef!: ElementRef<HTMLElement>;
  @ViewChild('labels') _labelsRef!: ElementRef<HTMLElement>;

  pdfFiles = [
    {
      name: 'Test 1',
      url: '/assets/test-1.pdf',
    },
    {
      name: 'Test 0',
      url: '/assets/test-0.pdf',
    },
    {
      name: 'Test 2',
      url: '/assets/test-2.pdf',
    },
    {
      name: 'ng2-pdf-viewer - PDF test file',
      url: 'https://vadimdez.github.io/ng2-pdf-viewer/assets/pdf-test.pdf',
    },
  ];
  pdfFileSelected = this.pdfFiles[2];

  pdfSrc?: string = undefined;

  markers: MarkerName[] = [];

  pdfPagesScrollHeight: number = 0;
  labelsScrollHeight: number = 0;

  isPreview$ = this.xxxStore.markerPreview$;

  constructor(private xxxStore: XxxStore) {}

  ngOnInit(): void {
    this.pdfSrc = this.pdfFileSelected.url;

    this.xxxStore.template$.subscribe((tpl) => {
      this.markers = tpl.pages
        .flatMap((page) => page.markers)
        .map((marker) => ({ ...marker }));
    });
  }

  ngAfterViewInit(): void {
    defer(() => {
      this.labelsScrollHeight = calculateLabelsScrollHeight(this._labelsRef);

      const pdfPagesSize = calculatePdfPagesSize(this._pdfPagesRef);
      this.pdfPagesScrollHeight = pdfPagesSize.height;

      this.xxxStore.pdfPageWidth$.next(
        clamp(pdfPagesSize.width, MIN_PDF_WIDTH, MAX_PDF_WIDTH)
      );
    });
  }

  onPdfFileChange(): void {
    this.pdfSrc = undefined;

    defer(() => {
      this.pdfSrc = this.pdfFileSelected.url;
    });
  }

  onStartRenaming(event: { data: MarkerName }): void {
    this.xxxStore.markerEditingId$.next(event.data.id);
  }

  onRenameMarker(event: { data: MarkerName }): void {
    this.xxxStore.renameMarker(event.data);
    this.xxxStore.markerEditingId$.next(undefined);
  }

  onRemoveMarker(marker: Marker): void {
    this.xxxStore.removeMarker(marker.pageIndex, marker.id);
  }

  onTogglePreview(): void {
    this.xxxStore.toggleMarkerPreview();
  }
}
