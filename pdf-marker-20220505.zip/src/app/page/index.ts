export * from './welcome/welcome.page';
export * from './tpl/tpl.page';
export * from './doc/doc.page';
