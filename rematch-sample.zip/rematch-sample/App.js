import React from 'react'
import { connect } from 'react-redux'

// Make a presentational component.
// It knows nothing about redux or rematch.
const App = ({ count, xxx, asyncIncrement, increment, blahbloh }) => (
	<div>
		<h2>
			count is <b style={{ backgroundColor: '#ccc' }}>{count}</b>
		</h2>

		<h2>
			<button onClick={() => increment(1)}>Increment count</button>{' '}
			<em style={{ backgroundColor: 'yellow' }}>(normal dispatch)</em>
		</h2>

		<h2>
			<button onClick={() => asyncIncrement(count)}>
				Increment count (delayed 1 second)
			</button>{' '}
			<em style={{ backgroundColor: 'yellow' }}>(an async effect!!!)</em>
		</h2>
		<h2>
			<button onClick={() => blahbloh(count)}>
				XXX
			</button>
			{JSON.stringify(xxx)}
		</h2>
	</div>
)

const mapState = state => ({
	count: state.count,
	xxx: state.xxx
})

const mapDispatch = dispatch => ({
	increment: dispatch.count.increment,
	asyncIncrement: dispatch.count.asyncIncrement,
	blahbloh: dispatch.xxx.blahbloh
})

// Use react-redux's connect
export default connect(
	mapState,
	mapDispatch
)(App)
