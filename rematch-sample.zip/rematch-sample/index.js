import React from 'react'
import ReactDOM from 'react-dom'
import { Provider } from 'react-redux'
import { init } from '@rematch/core'
import createRematchPersist, { getPersistor } from '@rematch/persist'
import { PersistGate } from 'redux-persist/lib/integration/react'
import localForage from 'localforage';

import App from './App'
import * as models from './models'

localForage.config({
	name: 'MINV'
});

const persistPlugin = createRematchPersist({
  // whitelist: ['modelName1'],
  throttle: 5000,
	version: 1,
	storage: localForage
})

const store = init({
	models,
	plugins: [persistPlugin]
})

const persistor = getPersistor()

// Use react-redux's <Provider /> and pass it the store.
ReactDOM.render(
	<Provider store={store}>
		<PersistGate persistor={persistor}>
				<App />
		</PersistGate>
	</Provider>,
	document.getElementById('root')
)
