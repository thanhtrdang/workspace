import axios from 'axios';

export const count = {
	state: 0,
	reducers: {
		increment: (state, payload) => {
			return state + payload;
		},
	},
	effects: dispatch => ({
		asyncIncrement: async (payload, rootState) => {
			dispatch.count.increment(payload)
		},
	}),
}

export const xxx = {
	state: {},
	reducers: {
		blahblohSuccess(state, data) {
			console.log(data)
			return data
		},
		blahblohFailure(state, error) {
			console.log(error)
			return error
		},
		blahblohCanceled(state, payload) {

		}
	},
	effects: ({xxx}) => ({
		async blahbloh(payload, rootState) {
			console.log(`request ${JSON.stringify(rootState)}`)
			axios
				.get(`http://localhost:3003/users/${payload}`)
				.then(response => {
					xxx.blahblohSuccess(response.data)
				})
				.catch(error => {
					xxx.blahblohFailure(error)
				})
				.then(() => {
					console.log("END!!!")
				})
		}
	})
}
