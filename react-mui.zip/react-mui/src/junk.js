import React from 'react';
import Typography from '@material-ui/core/Typography';

const Junk = () => (
  <Typography>
    In a tweet Wednesday, U.S. Rep. Alexandria Ocasio-Cortez, D-N.Y., suggested that House Democrats won't be taking no for an answer in seeking access to President Trump's tax returns.

The freshman congresswoman boiled her view of the situation down to the following mock conversation between Congress and the president:

"Congress: 'We’re going to need a copy of the President’s tax returns from 2013-2018.'

"45: 'No, I’m ‘under audit.'

"Congress: 'We didn’t ask you.' "

JASON CHAFFETZ: TRUMP'S TAX RETURNS AND WHY DEMOCRATS ARE OBSESSED WITH THEM

After Special Counsel Robert Mueller's report on his Russia investigation found no evidence of collusion between the Trump campaign and Russia, some Democrats have been continuing efforts to investigate the president's business dealings and other actions.

Ocasio-Cortez's tweet referred to the House Ways and Means Committee’s request to the IRS for six years of the president's tax records.

HOUSE DEMS RAMP UP EFFORTS TO GET TRUMP’S TAX RETURNS, WILL ‘TAKE ALL NECESSARY STEPS’

During the election, Trump broke the long-standing tradition of presidential candidates releasing their tax returns, saying they were under audit. He has continued to dodge the issue as president.

Congressional Republicans claim with their IRS request Democrats have "weaponized" the tax law.

The president recently took note of the impact Ocasio-Cortez has made on the Democratic Party since taking office in January.

CLICK HERE TO GET THE FOX NEWS APP

"The Green New Deal, done by a young bartender, 29 years old," Trump told a crowd of House Republicans at a dinner in Washington on Tuesday, referring to Ocasio-Cortez and her package of proposals for U.S. efforts to combat climate change. "A young bartender, wonderful young woman.”

The president then claimed that longtime Democrats had become "petrified of her."

In a tweet Wednesday, U.S. Rep. Alexandria Ocasio-Cortez, D-N.Y., suggested that House Democrats won't be taking no for an answer in seeking access to President Trump's tax returns.

The freshman congresswoman boiled her view of the situation down to the following mock conversation between Congress and the president:

"Congress: 'We’re going to need a copy of the President’s tax returns from 2013-2018.'

"45: 'No, I’m ‘under audit.'

"Congress: 'We didn’t ask you.' "

JASON CHAFFETZ: TRUMP'S TAX RETURNS AND WHY DEMOCRATS ARE OBSESSED WITH THEM

After Special Counsel Robert Mueller's report on his Russia investigation found no evidence of collusion between the Trump campaign and Russia, some Democrats have been continuing efforts to investigate the president's business dealings and other actions.

Ocasio-Cortez's tweet referred to the House Ways and Means Committee’s request to the IRS for six years of the president's tax records.

HOUSE DEMS RAMP UP EFFORTS TO GET TRUMP’S TAX RETURNS, WILL ‘TAKE ALL NECESSARY STEPS’

During the election, Trump broke the long-standing tradition of presidential candidates releasing their tax returns, saying they were under audit. He has continued to dodge the issue as president.

Congressional Republicans claim with their IRS request Democrats have "weaponized" the tax law.

The president recently took note of the impact Ocasio-Cortez has made on the Democratic Party since taking office in January.

CLICK HERE TO GET THE FOX NEWS APP

"The Green New Deal, done by a young bartender, 29 years old," Trump told a crowd of House Republicans at a dinner in Washington on Tuesday, referring to Ocasio-Cortez and her package of proposals for U.S. efforts to combat climate change. "A young bartender, wonderful young woman.”

The president then claimed that longtime Democrats had become "petrified of her."
In a tweet Wednesday, U.S. Rep. Alexandria Ocasio-Cortez, D-N.Y., suggested that House Democrats won't be taking no for an answer in seeking access to President Trump's tax returns.

The freshman congresswoman boiled her view of the situation down to the following mock conversation between Congress and the president:

"Congress: 'We’re going to need a copy of the President’s tax returns from 2013-2018.'

"45: 'No, I’m ‘under audit.'

"Congress: 'We didn’t ask you.' "

JASON CHAFFETZ: TRUMP'S TAX RETURNS AND WHY DEMOCRATS ARE OBSESSED WITH THEM

After Special Counsel Robert Mueller's report on his Russia investigation found no evidence of collusion between the Trump campaign and Russia, some Democrats have been continuing efforts to investigate the president's business dealings and other actions.

Ocasio-Cortez's tweet referred to the House Ways and Means Committee’s request to the IRS for six years of the president's tax records.

HOUSE DEMS RAMP UP EFFORTS TO GET TRUMP’S TAX RETURNS, WILL ‘TAKE ALL NECESSARY STEPS’

During the election, Trump broke the long-standing tradition of presidential candidates releasing their tax returns, saying they were under audit. He has continued to dodge the issue as president.

Congressional Republicans claim with their IRS request Democrats have "weaponized" the tax law.

The president recently took note of the impact Ocasio-Cortez has made on the Democratic Party since taking office in January.

CLICK HERE TO GET THE FOX NEWS APP

"The Green New Deal, done by a young bartender, 29 years old," Trump told a crowd of House Republicans at a dinner in Washington on Tuesday, referring to Ocasio-Cortez and her package of proposals for U.S. efforts to combat climate change. "A young bartender, wonderful young woman.”

The president then claimed that longtime Democrats had become "petrified of her."
In a tweet Wednesday, U.S. Rep. Alexandria Ocasio-Cortez, D-N.Y., suggested that House Democrats won't be taking no for an answer in seeking access to President Trump's tax returns.

The freshman congresswoman boiled her view of the situation down to the following mock conversation between Congress and the president:

"Congress: 'We’re going to need a copy of the President’s tax returns from 2013-2018.'

"45: 'No, I’m ‘under audit.'

"Congress: 'We didn’t ask you.' "

JASON CHAFFETZ: TRUMP'S TAX RETURNS AND WHY DEMOCRATS ARE OBSESSED WITH THEM

After Special Counsel Robert Mueller's report on his Russia investigation found no evidence of collusion between the Trump campaign and Russia, some Democrats have been continuing efforts to investigate the president's business dealings and other actions.

Ocasio-Cortez's tweet referred to the House Ways and Means Committee’s request to the IRS for six years of the president's tax records.

HOUSE DEMS RAMP UP EFFORTS TO GET TRUMP’S TAX RETURNS, WILL ‘TAKE ALL NECESSARY STEPS’

During the election, Trump broke the long-standing tradition of presidential candidates releasing their tax returns, saying they were under audit. He has continued to dodge the issue as president.

Congressional Republicans claim with their IRS request Democrats have "weaponized" the tax law.

The president recently took note of the impact Ocasio-Cortez has made on the Democratic Party since taking office in January.

CLICK HERE TO GET THE FOX NEWS APP

"The Green New Deal, done by a young bartender, 29 years old," Trump told a crowd of House Republicans at a dinner in Washington on Tuesday, referring to Ocasio-Cortez and her package of proposals for U.S. efforts to combat climate change. "A young bartender, wonderful young woman.”

The president then claimed that longtime Democrats had become "petrified of her."
  </Typography>
);

export default Junk;