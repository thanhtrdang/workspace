import React from 'react';
import { CssBaseline } from '@material-ui/core';
import Layout from './Layout'
// import Layout101 from './Layout-101'

const App = () => {
  return (
    <React.Fragment>
      <CssBaseline />
      <Layout />
    </React.Fragment>
  );
};

export default App;
